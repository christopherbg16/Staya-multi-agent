# Staya – multi-agent assistant

Staya is one assistant made of specialist agents behind one chat widget. This document says what each agent
does, how a message flows, and what is deliberately **not** automated.

## Setup
1. Run `stayora/05_staya_agents_migration.sql` in the Supabase SQL editor (creates `favorites`, `conversations`,
   `messages`, `offers`, `agent_actions`, a one-review-per-guest index and a 1–5 rating check).
2. In `stayora/.env` set `SECRET_KEY` (**at least 32 characters**; the app refuses to start otherwise) and
   `SUPABASE_SERVICE_ROLE_KEY` (the new tables have RLS enabled with no policies, so only the server can use them).
   Optional: `GEMINI_API_KEY` (natural-language mode; without it the rule router still answers), `GOOGLE_MAPS_API_KEY`
   (address verification), Stripe keys (card payments). See `.env.example`.
3. `pip install -r stayora/requirements.txt`, then `python stayora/run.py`.
4. Tests: `python -m unittest discover -s tests -t .` (the Staya suite uses an in-memory database, no network).

## Agents (package `stayora/staya/`)
| Agent | Tools | What it does |
|---|---|---|
| Availability | `check_availability`, `search_available`, `check_saved_properties` | Real calendar check (rooms or whole property), cheapest free unit, nearby free dates when booked, availability of the guest's saved (liked) properties |
| Pricing | `get_price_quote`, `compare_price`, `search_by_price` | Exact totals (Decimal), comparison against similar listings in the same city/country, search by real prices incl. room-priced hotels |
| Verification | `verify_property`, `check_offer` | What Staya checked (content + Google Places address) and what it does *not* prove (ownership, photo location); dry-run validation of a price offer |
| Reservation | `prepare_booking`, `list_my_bookings`, `prepare_cancellation` | Re-checks availability and price, then asks for a human click; cash or card; cancellation with refund rules (free up to 48 h) |
| Offer | `prepare_offer`, `list_my_offers` | Guest price offers with floor (60 % of list), duplicate and open-offer limits, 48 h expiry, owner accept / decline / counter |
| Review | `get_reviews`, `prepare_review` | Only guests with a finished stay, one review each, rating 1–5, contact details/links blocked |
| Messaging | `prepare_message_to_owner`, `get_my_messages` + `/messages` pages | Guest ↔ owner chat per property, offers appear as cards with action buttons, unread badge in the navbar |

## Page awareness
The widget sends `{path, search}` of the page you are on. `staya/context.py` turns it into a hint (property id,
dates, guests, offer). On `/user/hotel/<id>?check_in=…&check_out=…` you can just ask "is it available?", "how much?",
"is this legit?", "make an offer of 85 €" or "book it". Hints never grant permission: ids are re-validated and every
action re-checks the account.

## Safety rules
* The model can only call `prepare_*` tools. Booking, offers, reviews, messages and cancellations run only when the
  person presses **Confirm** (`POST /api/staya/confirm`) with a signed, single-use, 15-minute token bound to the user.
* Availability and price are re-checked at confirm time; the database exclusion constraints remain the last line of defence.
* Owners cannot book, review or offer on their own property. Accepted offers can only be used by the guest who made them.
* Card numbers and IBANs are blocked in all text; emails, links, phone numbers and abuse are blocked in public reviews.
* Every tool call is logged to `agent_actions` (free text such as messages is not stored there).

## Known limits
* "Verified" means Staya's automated content and address checks passed – not that the owner was verified.
* Session memory and single-use token tracking are in process memory; with several workers use sticky sessions or a shared store.
* New interface strings are English/Bulgarian in the assistant; page templates use `_()` but the `.po` files were not regenerated.
