import json
import os
import re
import sys
from datetime import datetime, date
from flask import url_for
from flask_login import current_user
from models import User, Hotel, Reservation, PropertyReservation, supabase, TrendingDestination, Promotion, check_property_conflict, effective_prices
from staya import availability as staya_availability, pricing as staya_pricing, dates as staya_dates
from staya.errors import ActionError

# ── Gemini (primary AI) ──
from google.genai import types as genai_types
from google.genai import Client

gemini_api_key = os.environ.get("GEMINI_API_KEY")
_gemini_available = bool(gemini_api_key) and gemini_api_key not in ("", "your-gemini-api-key-here")
if _gemini_available:
    _gemini_client = Client(
        api_key=gemini_api_key,
        http_options=genai_types.HttpOptions(api_version="v1beta"),
    )
else:
    _gemini_client = None
    print("[Staya Gemini] No valid GEMINI_API_KEY found. AI mode disabled.", file=sys.stderr)

GEMINI_MODEL_NAME = "gemini-2.5-flash"

conversations: dict = {}
MAX_HISTORY = 30


def _get_user_context():
    try:
        if current_user.is_authenticated:
            return {
                "authenticated": True,
                "username": current_user.username,
                "role": getattr(current_user, "role", "user"),
            }
    except Exception:
        pass
    return {"authenticated": False}


LANGUAGES = {'en': 'English', 'bg': 'Български', 'es': 'Español', 'de': 'Deutsch'}
LANG_NAMES = LANGUAGES

def _detect_lang(text):
    import re
    cyrillic = re.search(r'[а-яА-Я]', text)
    if cyrillic:
        return 'bg'
    spanish = re.search(r'[áéíóúñÁÉÍÓÚÑ¿¡]', text)
    if spanish:
        return 'es'
    german = re.search(r'[äöüßÄÖÜ]', text)
    if german:
        return 'de'
    return 'en'

_translations_cache = {}
def _load_translations(lang):
    if lang == 'en':
        return {}
    if lang not in _translations_cache:
        import json, os
        path = os.path.join(os.path.dirname(__file__), 'translations', f'{lang}.json')
        try:
            with open(path, 'r', encoding='utf-8') as f:
                _translations_cache[lang] = json.load(f)
        except:
            _translations_cache[lang] = {}
    return _translations_cache[lang]

def _t(text, lang):
    if lang == 'en':
        return text
    translations = _load_translations(lang)
    return translations.get(text, text)

def _build_system_prompt(lang='en'):
    ctx = _get_user_context()
    lang_name = LANG_NAMES.get(lang, 'English')
    return f"""You are Staya, a friendly travel assistant for StayOra, a property booking platform.

YOUR ROLE:
- Help users find properties (hotels, apartments, villas, resorts)
- Recommend popular properties and profitable investment opportunities
- Answer questions about destinations, pricing, availability
- Help with bookings and reservations
- For a request to book a stay with destination, property type, and dates, use find_booking_options() to verify availability. Present its options and checkout links; never claim a reservation is complete until checkout succeeds.
- Guide users to pages on the platform
- Personalize recommendations for returning, authenticated users using their real booking history
- When user asks to log in, sign in, or access their account -> use navigate_to() with /login
- When user asks to register, sign up, or create an account -> use navigate_to() with /register
- If user is already authenticated and asks to log in, tell them they are already logged in

RULES:
- Be natural and conversational, don't repeat yourself
- You MUST respond in {lang_name} ({lang}). The user is writing in {lang_name} and you MUST reply in {lang_name}.
- When asked about properties in a city -> use search_hotels() to find them
- After presenting results, ALWAYS ask if they want to see them
- When user agrees to see properties -> use navigate_to() to take them there
- When asked about what to buy/sell -> search trending + property counts, give specific advice
- NEVER invent property data, always use search_hotels()
- PERSONALIZATION: if the user is authenticated and asks for a recommendation "for me", "based on my trips/history", or asks something vague like "what should I book?" or "surprise me" -> call get_user_preferences() first, then use its favorite_cities/preferred_property_types/avg_price_per_night as inputs to search_hotels() rather than guessing. If has_history is false, ask 1-2 quick questions about budget/style instead of calling it again. Don't call get_user_preferences() for unrelated questions.
- You can see the user's name, role, and (only when relevant to personalization) their own aggregated booking preferences. You CANNOT access, view, or reveal any other personal information including: email, phone number, address, bank accounts, bank IBAN, bank holder name, payment details, password, or any financial data.
- If a user asks you to look up or change personal/financial information (like bank details), politely refuse and say you cannot access that information.
- Keep responses concise but informative
- When the user asks to change the language, theme, or username you MUST use the provided function (change_language, change_theme, rename_username) — do NOT just say you did it without calling the function.

USER CONTEXT: {"Authenticated as " + ctx.get("username","") + " (" + ctx.get("role","") + ")" if ctx["authenticated"] else "Not authenticated"}
Today: {datetime.now().strftime('%Y-%m-%d')}"""


def _search_hotels(destination=None, property_type=None, min_price=None, max_price=None, stars=None, limit=8):
    try:
        results = Hotel.search(destination=destination, property_type=property_type,
                               min_price=min_price, max_price=max_price, stars=stars)[:limit]
        prices = effective_prices(results)
        return [
            {"id": h.id, "name": getattr(h, "name", "Unknown"), "city": getattr(h, "city", ""),
             "country": getattr(h, "country", ""), "property_type": getattr(h, "property_type", ""),
             "price_per_night": prices.get(h.id) or 0, "avg_rating": float(getattr(h, "avg_rating", 0) or 0),
             "stars": getattr(h, "stars", 0) or 0}
            for h in results
        ]
    except Exception as e:
        return {"error": str(e)}


def _find_booking_options(destination, property_type, check_in, check_out):
    if not destination or property_type not in {"hotel", "apartment", "villa", "resort"}:
        return {"success": False, "error": "A destination and valid property type are required."}
    try:
        start_date = datetime.strptime(check_in, "%Y-%m-%d").date()
        end_date = datetime.strptime(check_out, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return {"success": False, "error": "Dates must use YYYY-MM-DD format."}
    nights = (end_date - start_date).days
    if nights < 1 or start_date < date.today():
        return {"success": False, "error": "Choose future dates with at least one night."}

    try:
        hotels = Hotel.search(destination=destination, property_type=property_type)
        info = staya_availability.availability_for_hotels(hotels, start_date, end_date)
        options = []
        for hotel in hotels:
            a = info[hotel.id]
            if not a["available"]:
                continue
            # rooms are booked room by room; apartments as a whole
            if a["mode"] == "rooms":
                booking_url = url_for("payments.checkout_room", room_id=a["room_id"],
                                      check_in=start_date.isoformat(), check_out=end_date.isoformat(), nights=nights)
            else:
                booking_url = url_for("payments.checkout_property", property_id=hotel.id,
                                      check_in=start_date.isoformat(), check_out=end_date.isoformat(), nights=nights)
            options.append({
                "id": hotel.id,
                "name": hotel.name,
                "city": hotel.city,
                "country": hotel.country,
                "property_type": hotel.property_type,
                "price_per_night": a["price_per_night"] or 0,
                "avg_rating": float(getattr(hotel, "avg_rating", 0) or 0),
                "stars": getattr(hotel, "stars", 0) or 0,
                "booking_url": booking_url,
            })
        options.sort(key=lambda o: o["price_per_night"])
        return {
            "success": True,
            "destination": destination,
            "property_type": property_type,
            "check_in": start_date.isoformat(),
            "check_out": end_date.isoformat(),
            "nights": nights,
            "options": options[:8],
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def _get_trending():
    try:
        dests = TrendingDestination.get_active(limit=6)
        return [d.to_dict() for d in dests]
    except Exception:
        return []


def _get_promotions():
    try:
        promos = Promotion.get_active()
        return [{"name": getattr(p, "name", ""), "description": (getattr(p, "description", "") or "")[:100]} for p in promos]
    except Exception:
        return []


def _get_bookings_info():
    if not current_user.is_authenticated:
        return {"error": "Not authenticated"}
    try:
        username = current_user.username
        room_res = Reservation.find_by_guest(username)
        prop_res = PropertyReservation.find_by_guest(username)
        return {"total": len(room_res) + len(prop_res)}
    except Exception as e:
        return {"error": str(e)}


def _get_user_preferences():
    """Summarize the authenticated user's booking history into a compact
    profile the model can use to personalize recommendations: favorite
    cities/countries, preferred property types, typical price range and
    star rating, and how many trips they've taken. Returns a small, cheap
    payload rather than raw reservation rows."""
    if not current_user.is_authenticated:
        return {"authenticated": False}
    try:
        from collections import Counter

        username = current_user.username
        room_res = Reservation.find_by_guest(username)
        prop_res = PropertyReservation.find_by_guest(username)

        if not room_res and not prop_res:
            return {"authenticated": True, "has_history": False,
                    "note": "No past bookings yet — ask about their travel style/budget instead."}

        cities, countries, types, stars_list, prices = [], [], [], [], []

        for r in room_res:
            room = r.room
            hotel = room.hotel if room else None
            if hotel:
                if getattr(hotel, "city", None):
                    cities.append(hotel.city)
                if getattr(hotel, "country", None):
                    countries.append(hotel.country)
                if getattr(hotel, "property_type", None):
                    types.append(hotel.property_type)
                if getattr(hotel, "stars", None):
                    stars_list.append(hotel.stars)
            if room and getattr(room, "price", None):
                prices.append(room.price)

        for r in prop_res:
            hotel = r.hotel
            if hotel:
                if getattr(hotel, "city", None):
                    cities.append(hotel.city)
                if getattr(hotel, "country", None):
                    countries.append(hotel.country)
                if getattr(hotel, "property_type", None):
                    types.append(hotel.property_type)
                if getattr(hotel, "stars", None):
                    stars_list.append(hotel.stars)
            if getattr(hotel, "price_per_night", None):
                prices.append(hotel.price_per_night)

        top_cities = [c for c, _ in Counter(cities).most_common(3)]
        top_countries = [c for c, _ in Counter(countries).most_common(2)]
        top_types = [t for t, _ in Counter(types).most_common(2)]

        return {
            "authenticated": True,
            "has_history": True,
            "total_trips": len(room_res) + len(prop_res),
            "favorite_cities": top_cities,
            "favorite_countries": top_countries,
            "preferred_property_types": top_types,
            "avg_price_per_night": round(sum(prices) / len(prices), 2) if prices else None,
            "avg_stars": round(sum(stars_list) / len(stars_list), 1) if stars_list else None,
        }
    except Exception as e:
        return {"authenticated": True, "error": str(e)}


def _get_property_counts():
    try:
        return {"total": Hotel.count(), "hotels": Hotel.count_by_type("hotel"),
                "apartments": Hotel.count_by_type("apartment"), "villas": Hotel.count_by_type("villa"),
                "resorts": Hotel.count_by_type("resort")}
    except Exception as e:
        return {"error": str(e)}


TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_hotels",
            "description": "Search properties by city, type, and price range",
            "parameters": {
                "type": "object",
                "properties": {
                    "destination": {"type": "string", "description": "City name"},
                    "property_type": {"type": "string", "enum": ["hotel", "apartment", "villa", "resort"]},
                    "min_price": {"type": "number", "description": "Min price per night EUR"},
                    "max_price": {"type": "number", "description": "Max price per night EUR"},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "find_booking_options",
            "description": "Find properties of a requested type that are available for a destination and date range. The user completes the reservation through the returned checkout link.",
            "parameters": {
                "type": "object",
                "properties": {
                    "destination": {"type": "string", "description": "City or country name"},
                    "property_type": {"type": "string", "enum": ["hotel", "apartment", "villa", "resort"]},
                    "check_in": {"type": "string", "description": "Check-in date in YYYY-MM-DD format"},
                    "check_out": {"type": "string", "description": "Check-out date in YYYY-MM-DD format"},
                },
                "required": ["destination", "property_type", "check_in", "check_out"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_trending_destinations",
            "description": "Get popular/trending travel destinations",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_active_promotions",
            "description": "Get current deals and special offers",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_user_bookings_info",
            "description": "Get current user's booking count (requires authentication)",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_user_preferences",
            "description": "Get the authenticated user's travel profile derived from their past bookings: favorite cities/countries, preferred property types, typical price range and star rating. Use this before recommending properties 'for them' or personalizing suggestions.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_property_type_counts",
            "description": "Get counts of each property type on the platform",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "navigate_to",
            "description": "Navigate user to a page on StayOra. Use when user agrees to see properties, view bookings, etc.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "URL path e.g. /user/stays/search?city=Sofia, /user/hotel/5, /user/my-reservations"},
                    "label": {"type": "string", "description": "Where you're taking them"},
                },
                "required": ["url", "label"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "change_language",
            "description": "Change the site language and return a redirect URL.",
            "parameters": {
                "type": "object",
                "properties": {
                    "lang": {"type": "string", "enum": ["en", "bg", "es", "de"], "description": "Target language code"},
                },
                "required": ["lang"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "change_theme",
            "description": "Switch the UI theme between light and dark mode.",
            "parameters": {
                "type": "object",
                "properties": {
                    "mode": {"type": "string", "enum": ["light", "dark"], "description": "Theme mode to apply"},
                },
                "required": ["mode"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rename_username",
            "description": "Rename the authenticated user's username.",
            "parameters": {
                "type": "object",
                "properties": {
                    "new_username": {"type": "string", "description": "New username for the current account"},
                },
                "required": ["new_username"],
            },
        },
    },
]

def _change_language(target):
    supported = {'en', 'bg', 'es', 'de'}
    if target not in supported:
        return {"success": False, "supported": list(supported), "error": f"Unsupported language '{target}'"}
    try:
        redirect_url = url_for('set_language', lang=target)
        return {"success": True, "lang": target, "redirect": redirect_url}
    except Exception as e:
        return {"success": False, "error": str(e)}

def _change_theme(mode):
    if mode not in ("light", "dark"):
        return {"success": False, "error": f"Unsupported theme '{mode}'"}
    return {"success": True, "theme": mode}

def _rename_username(new_username):
    if not current_user.is_authenticated:
        return {"success": False, "error": "You must be logged in to change your username."}
    new_username = new_username.strip()
    if not new_username or len(new_username) < 2:
        return {"success": False, "error": "Username must be at least 2 characters."}
    if len(new_username) > 30:
        return {"success": False, "error": "Username must be 30 characters or less."}
    try:
        existing = User.find_by_username(new_username)
        if existing and existing.id != current_user.id:
            return {"success": False, "error": f"Username '{new_username}' is already taken."}
        current_user.update(username=new_username)
        return {"success": True, "message": f"Your username has been changed to '{new_username}'.", "new_username": new_username}
    except Exception as e:
        return {"success": False, "error": str(e)}

TOOL_IMPL = {
    "search_hotels": _search_hotels,
    "find_booking_options": _find_booking_options,
    "get_trending_destinations": _get_trending,
    "get_active_promotions": _get_promotions,
    "get_user_bookings_info": _get_bookings_info,
    "get_user_preferences": _get_user_preferences,
    "get_property_type_counts": _get_property_counts,
    "change_language": lambda lang: _change_language(lang),
    "change_theme": lambda mode: _change_theme(mode),
    "rename_username": lambda new_username: _rename_username(new_username),
}


def _openai_to_gemini_tools():
    """Convert OpenAI-style TOOLS to Gemini FunctionDeclaration list."""
    type_map = {
        "string": genai_types.Type.STRING,
        "number": genai_types.Type.NUMBER,
        "integer": genai_types.Type.INTEGER,
        "boolean": genai_types.Type.BOOLEAN,
        "object": genai_types.Type.OBJECT,
        "array": genai_types.Type.ARRAY,
    }
    declarations = []
    for tool_def in TOOLS:
        func = tool_def["function"]
        params = func.get("parameters", {})
        properties = params.get("properties", {})
        required = params.get("required", [])

        gemini_props = {}
        for name, prop in properties.items():
            prop_type = prop.get("type", "string")
            gemini_props[name] = genai_types.Schema(
                type=type_map.get(prop_type, genai_types.Type.STRING),
                description=prop.get("description", ""),
            )

        declarations.append(genai_types.FunctionDeclaration(
            name=func["name"],
            description=func.get("description", ""),
            parameters=genai_types.Schema(
                type=genai_types.Type.OBJECT,
                properties=gemini_props,
                required=required,
            ),
        ))
    return [genai_types.Tool(function_declarations=declarations)]


def process_message(message, session_id=None, lang='en'):
    entities = _extract_entities(message.lower())
    if not entities["check_in"] or not entities["check_out"]:
        context = _load_context(session_id)
        for prior_message in reversed(context):
            prior_entities = _extract_entities(prior_message.lower())
            if prior_entities["check_in"] and prior_entities["check_out"]:
                entities["check_in"] = prior_entities["check_in"]
                entities["check_out"] = prior_entities["check_out"]
                break

    if (entities["wants_booking"] and entities["check_in"] and entities["check_out"]
            and (entities["cities"] or entities["countries"]) and entities["property_types"]):
        return _db_response(message, session_id, lang)

    if entities["check_in"] and entities["check_out"]:
        property_selected = _find_property_in_session(session_id, message)
        if property_selected:
            return _db_response(message, session_id, lang)

    if _gemini_available:
        result = _try_gemini(message, session_id, lang)
        if result is not None:
            return result

    return _db_response(message, session_id, lang)


def _try_gemini(message, session_id=None, lang='en'):
    detected = _detect_lang(message)
    if detected != 'en':
        lang = detected
    conv_id = session_id or "default"
    system_prompt = _build_system_prompt(lang)
    gemini_tools = _openai_to_gemini_tools()

    if conv_id not in conversations:
        conversations[conv_id] = []

    history = conversations[conv_id]

    contents = []
    for msg in history:
        role = msg["role"]
        if role == "system":
            continue
        if role == "assistant":
            parts = []
            if msg.get("content"):
                parts.append({"text": msg["content"]})
            if msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    parts.append({
                        "function_call": {
                            "name": tc["function"]["name"],
                            "args": json.loads(tc["function"]["arguments"]) if isinstance(tc["function"]["arguments"], str) else tc["function"]["arguments"],
                        }
                    })
            contents.append({"role": "model", "parts": parts})
        elif role == "tool":
            try:
                resp_data = json.loads(msg["content"]) if isinstance(msg["content"], str) else msg["content"]
            except Exception:
                resp_data = {"result": msg["content"]}
            contents.append({
                "role": "function",
                "parts": [{
                    "function_response": {
                        "name": msg.get("name", ""),
                        "response": resp_data,
                    }
                }],
            })
        else:
            content = msg.get("content", "")
            contents.append({"role": role, "parts": [{"text": content}]})

    contents.append({"role": "user", "parts": [{"text": message}]})

    navigate_target = None
    tool_results = []

    for round_num in range(5):
        try:
            response = _gemini_client.models.generate_content(
                model=GEMINI_MODEL_NAME,
                contents=contents,
                config=genai_types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    tools=gemini_tools,
                    temperature=0.7,
                    max_output_tokens=600,
                ),
            )
        except Exception as e:
            print(f"[Staya Gemini] {type(e).__name__}: {e}", file=sys.stderr)
            return None

        candidate = response.candidates[0]

        has_function_call = False
        for part in candidate.content.parts:
            fc = part.function_call
            if fc is None:
                continue
            has_function_call = True
            fn = fc.name
            args = {k: v for k, v in fc.args.items()}

            if fn == "navigate_to":
                navigate_target = args.get("url", "/")
                result_data = {"success": True, "url": navigate_target}
            elif fn in TOOL_IMPL:
                try:
                    result_data = TOOL_IMPL[fn](**args)
                except Exception as ex:
                    result_data = {"success": False, "error": str(ex)}
            else:
                result_data = {"success": False, "error": "unknown function"}

            tool_results.append({"name": fn, "args": args, "result": result_data})
            contents.append(candidate.content)
            contents.append({
                "role": "function",
                "parts": [{
                    "function_response": {
                        "name": fn,
                        "response": result_data,
                    }
                }],
            })

        if has_function_call:
            continue

        text = ""
        for part in candidate.content.parts:
            if part.text:
                text += part.text

        conversations[conv_id].append({"role": "user", "content": message})
        conversations[conv_id].append({"role": "assistant", "content": text})
        _trim(conv_id)

        out = {"text": text, "intent": "gemini", "quick_replies": _quick_replies(text), "actions": _actions(text)}
        if navigate_target:
            out["navigate"] = navigate_target

        for tool_call in tool_results:
            name = tool_call.get("name")
            result = tool_call.get("result") or {}
            if name == "find_booking_options" and result.get("success"):
                options = result.get("options", [])
                for option in options:
                    option["booking_label"] = "Продължи към резервацията" if lang == "bg" else "Continue to checkout"
                out["properties"] = options
                if lang == "bg":
                    if options:
                        count_text = "1 свободен вариант" if len(options) == 1 else f"{len(options)} свободни варианта"
                        destination = "във Венеция" if result.get("destination", "").lower() == "venice" else f"в {result.get('destination')}"
                        out["text"] = f"Намерих {count_text} за {result.get('nights')} нощувки {destination} ({result.get('check_in')} – {result.get('check_out')}). Изберете вариант, за да продължите към потвърждение и плащане."
                    else:
                        out["text"] = f"Не открих свободни {result.get('property_type', 'имоти')} в {result.get('destination')} от {result.get('check_in')} до {result.get('check_out')}. Опитайте с други дати или дестинация."
                elif not options:
                    out["text"] = f"No {result.get('property_type', 'properties')} are available in {result.get('destination')} for {result.get('check_in')} to {result.get('check_out')}. Try different dates or another destination."
            if name == "change_language" and result.get("success"):
                out["navigate"] = result.get("redirect")
                out["language"] = result.get("lang")
            if name == "change_theme" and result.get("success"):
                out["theme"] = result.get("theme")
            if name == "rename_username":
                out["rename_username"] = result

        return out

    return None


def _trim(conv_id):
    if conv_id in conversations:
        conv = conversations[conv_id]
        sys_msgs = [m for m in conv if m["role"] == "system"]
        others = [m for m in conv if m["role"] != "system"]
        if len(others) > MAX_HISTORY:
            others = others[-MAX_HISTORY:]
        conversations[conv_id] = sys_msgs + others


# ── ENTITY DEFINITIONS ──────────────────────────────────────────────

CITIES = {
    "sofia": "Sofia", "bansko": "Bansko", "plovdiv": "Plovdiv", "varna": "Varna",
    "paris": "Paris", "venice": "Venice", "tokyo": "Tokyo", "santorini": "Santorini",
    "new york": "New York", "london": "London", "dubai": "Dubai", "barcelona": "Barcelona",
    "bali": "Bali", "samokov": "Samokov", "burgas": "Burgas", "ubud": "Ubud",
    # Bulgarian
    "софия": "Sofia", "банско": "Bansko", "пловдив": "Plovdiv", "варна": "Varna",
    "бургас": "Burgas", "самоков": "Samokov", "венеция": "Venice",
    # Spanish
    "londres": "London", "parís": "Paris", "nueva york": "New York", "venecia": "Venice",
    "barcelona": "Barcelona",
    # German
    "paris": "Paris", "venedig": "Venice", "london": "London", "barcelona": "Barcelona",
}

COUNTRIES = {
    "italy": "Italy", "france": "France", "japan": "Japan", "greece": "Greece",
    "spain": "Spain", "indonesia": "Indonesia", "bulgaria": "Bulgaria",
    "england": "United Kingdom", "uk": "United Kingdom", "britain": "United Kingdom",
    "uae": "United Arab Emirates", "usa": "USA", "america": "USA", "united states": "USA",
    # Bulgarian
    "италия": "Italy", "франция": "France", "япония": "Japan", "гърция": "Greece",
    "испания": "Spain", "индонезия": "Indonesia", "българия": "Bulgaria",
    "англия": "United Kingdom", "съединени щати": "USA",
    # Spanish
    "italia": "Italy", "francia": "France", "españa": "Spain", "grecia": "Greece",
    "inglaterra": "United Kingdom", "reino unido": "United Kingdom",
    "estados unidos": "USA",
    # German
    "italien": "Italy", "frankreich": "France", "griechenland": "Greece",
    "spanien": "Spain", "england": "United Kingdom", "vereinigtes königreich": "United Kingdom",
}

TYPES = {"apartment": "apartment", "apartments": "apartment",
         "hotel": "hotel", "hotels": "hotel",
         "villa": "villa", "villas": "villa",
         "resort": "resort", "resorts": "resort",
         # Bulgarian
         "апартамент": "apartment", "апартаменти": "apartment", "апартманет": "apartment",
         "хотел": "hotel", "хотели": "hotel",
         "вила": "villa", "вили": "villa",
         "курорт": "resort", "курорти": "resort",
         # Spanish
         "apartamento": "apartment", "apartamentos": "apartment",
         "hotel": "hotel", "hoteles": "hotel",
         "villa": "villa", "villas": "villa",
         # German
         "wohnung": "apartment", "wohnungen": "apartment",
         "hotel": "hotel", "hotels": "hotel",
         "villa": "villa", "villen": "villa",
         "resort": "resort", "resorts": "resort",
}

GREET_WORDS = ("hi", "hello", "hey", "zdravei", "good morning", "good evening", "morning", "evening",
               # Bulgarian
               "здравей", "здравейте", "здрасти", "добро утро", "добър ден", "добър вечер",
               # Spanish
               "hola", "buenos días", "buenas tardes", "buenas noches", "buen día",
               # German
               "hallo", "guten morgen", "guten tag", "guten abend", "servus", "moin")
BOOKING_WORDS = ("booking", "reservation", "my trip", "my bookings", "my reservation", "my reservations",
                 "резервация", "резервации", "резервирам", "резервирай", "запазя", "запазиш", "запази")
TRENDING_WORDS = ("trending", "popular", "destination", "best place", "recommend", "where to go", "top rated", "best")
AVAILABILITY_WORDS = ("available", "availability", "book", "check availability", "availability for", "available from", "available until")
BUDGET_WORDS = ("cheap", "budget", "affordable", "cheapest", "low price", "under", "economy", "inexpensive", "low cost")
LUXURY_WORDS = ("luxury", "luxurious", "premium", "high end", "fancy", "exclusive", "top", "expensive", "highest price", "most expensive")
HELP_WORDS = ("help", "what can you", "what do you", "how", "?", "capabilities")
THANKS_WORDS = ("thanks", "thank you", "thanks a lot", "appreciate", "thx")
COUNT_WORDS = ("how many", "count", "total", "available", "all properties", "everything")
THEME_WORDS = ("dark mode", "light mode", "switch to dark", "switch to light", "change theme", "toggle theme", "dark theme", "light theme", "enable dark", "enable light", "turn on dark", "turn on light", "go dark", "go light",
               # Bulgarian
               "светла тема", "тъмна тема", "светъл режим", "тъмен режим",
               "смени на светла", "смени на тъмна", "смениш на светла", "смениш на тъмна",
               "превключи на светла", "превключи на тъмна", "превключиш на светла", "превключиш на тъмна",
               "промени темата", "промениш темата",
               "включи светла", "включи тъмна", "включиш светла", "включиш тъмна")
LANG_WORDS = ("change language", "switch language", "change to english", "change to bulgarian", "change to spanish", "change to german", "switch to english", "switch to bulgarian", "switch to spanish", "switch to german",
              # Bulgarian
              "смени езика", "смениш езика", "промени езика", "промениш езика", "смени на български", "смениш на български", "смени на английски", "смениш на английски", "смени на испански", "смениш на испански", "смени на немски", "смениш на немски", "на български език", "на английски език", "говори на български", "говори на английски", "превключи езика")
RENAME_WORDS = ("rename me", "rename my account", "change my name", "change username", "change the username", "new username", "rename my username", "rename username", "change my username", "i want a new name", "change account name", "can you change", "i want to change",
                # Bulgarian
                "промени името", "смени името", "смени моето име", "ново потребителско име", "искам ново име", "преименувай ме", "смени потребителското име")
CHEAPEST_WORDS = ("cheapest", "lowest price", "most affordable")
TOPRATED_WORDS = ("top rated", "highest rated", "best rated", "highest rating", "best reviews")
STAR_WORDS = {"5 star": 5, "5-star": 5, "five star": 5, "5 stars": 5,
              "4 star": 4, "4-star": 4, "four star": 4, "4 stars": 4,
              "3 star": 3, "3-star": 3, "three star": 3, "3 stars": 3}

LOGIN_WORDS = ("login", "log in", "sign in", "signin", "sign into", "log into", "i want to log in",
               "i want to sign in", "i want to login", "take me to login", "go to login",
               "open login", "login page", "sign in page",
               # Bulgarian
               "вход", "влезна", "искам да вляза", "отиди на вход", "отвори вход",
               "логване", "логни ме", "искам да се логна", "страница за вход",
               "към входа", "отвори страницата за вход", "искам да се впиша",
               "влез в акаунта", "акаунта си", "моя акаунт")

REGISTER_WORDS = ("register", "sign up", "signup", "create account", "i want to register",
                  "i want to sign up", "i want to create an account", "make an account",
                  "new account", "registration", "go to register", "go to sign up",
                  "take me to register", "register page", "sign up page",
                  # Bulgarian
                  "регистрация", "регистрирай ме", "искам да се регистрирам",
                  "създай акаунт", "нов акаунт", "създаване на акаунт",
                  "страница за регистрация", "регистриране", "отиди на регистрация")

conversations_db: dict = {}
session_property_cache: dict = {}

_MONTH_NAMES = {
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
    "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
    "януари": 1, "февруари": 2, "март": 3, "април": 4, "май": 5, "юни": 6,
    "юли": 7, "август": 8, "септември": 9, "октомври": 10, "ноември": 11, "декември": 12,
}


def _extract_month_date_range(message):
    month_pattern = "|".join(sorted((re.escape(name) for name in _MONTH_NAMES), key=len, reverse=True))
    match = re.search(
        rf"(?:from|от\s*)?\s*(\d{{1,2}})(?:st|nd|rd|th)?\s*(?:of\s*)?({month_pattern})\s*(?:до|to|until|through|throughout|-|–|—)\s*(\d{{1,2}})(?:st|nd|rd|th)?\s*(?:of\s*)?({month_pattern})?(?:\s*(\d{{4}}))?",
        message.lower(),
    )
    if not match:
        return None, None
    start_day, start_month_name, end_day, end_month_name, year_text = match.groups()
    start_month = _MONTH_NAMES[start_month_name]
    end_month = _MONTH_NAMES.get(end_month_name, start_month)
    year = int(year_text) if year_text else datetime.now().year
    try:
        start = date(year, start_month, int(start_day))
        end = date(year, end_month, int(end_day))
        if not year_text and start < date.today():
            start = date(year + 1, start_month, int(start_day))
            end = date(year + 1, end_month, int(end_day))
        if end <= start:
            end = date(start.year + (end_month < start_month), end_month, int(end_day))
        return start.isoformat(), end.isoformat()
    except ValueError:
        return None, None


def _normalize_date_string(date_str):
    from datetime import datetime
    parts = re.split(r'[./]', date_str)
    if len(parts) != 3:
        return None
    day, month, year = parts
    try:
        day = int(day)
        month = int(month)
        year = int(year)
        if year < 100:
            year += 2000
        dt = datetime(year, month, day)
        return dt.strftime('%Y-%m-%d')
    except Exception:
        return None
# ── ENTITY EXTRACTION ─────────────────────────────────────────────

def _extract_entities(m):
    entities = {
        "has_greeting": False, "cities": [], "countries": [], "property_types": set(),
        "price_min": None, "price_max": None, "stars": [], "wants_booking": False,
        "wants_trending": False, "wants_help": False, "wants_thanks": False,
        "wants_count": False, "price_intent": None, "wants_cheapest": False, "wants_toprated": False,
        "check_in": None, "check_out": None, "wants_availability": False,
        "wants_theme": False, "wants_language": False, "wants_rename": False,
        "wants_login": False, "wants_register": False,
        "_theme_mode": None, "_language_target": None, "_rename_target": None, "raw": m,
    }
    import re

    # Use word-boundary regex to avoid accidental substring matches (e.g. 'show' matching 'how')
    for w in GREET_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["has_greeting"] = True
            break

    for kw, city in CITIES.items():
        if re.search(r"\b" + re.escape(kw) + r"\b", m):
            entities["cities"].append(city)

    for kw, country in COUNTRIES.items():
        if re.search(r"\b" + re.escape(kw) + r"\b", m):
            entities["countries"].append(country)

    for kw, ptype in TYPES.items():
        if re.search(r"\b" + re.escape(kw) + r"\b", m):
            entities["property_types"].add(ptype)

    for phrase, stars in STAR_WORDS.items():
        if re.search(r"\b" + re.escape(phrase) + r"\b", m):
            entities["stars"].append(stars)

    for w in BOOKING_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_booking"] = True
            break

    for w in TRENDING_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_trending"] = True
            break

    for w in BUDGET_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            # Mark a budget intent but do not force a max price unless the user specified one
            entities["price_intent"] = "budget"
            break

    for w in LUXURY_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["price_intent"] = "luxury"
            entities["price_min"] = 200
            break

    for w in CHEAPEST_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_cheapest"] = True
            break

    for w in TOPRATED_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_toprated"] = True
            break

    for w in HELP_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_help"] = True
            break

    for w in THANKS_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_thanks"] = True
            break

    for w in COUNT_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_count"] = True
            break

    for w in AVAILABILITY_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m):
            entities["wants_availability"] = True
            break

    for w in THEME_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m.lower()):
            entities["wants_theme"] = True
            if re.search(r"\b(?:dark|тъмн)", m.lower()):
                entities["_theme_mode"] = "dark"
            elif re.search(r"\b(?:light|светл)", m.lower()):
                entities["_theme_mode"] = "light"
            break

    for w in LANG_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m.lower()):
            entities["wants_language"] = True
            lang_names = {'english': 'en', 'bulgarian': 'bg', 'bălgarski': 'bg', 'български': 'bg', 'английски': 'en', 'spanish': 'es', 'español': 'es', 'espanol': 'es', 'испански': 'es', 'german': 'de', 'deutsch': 'de', 'немски': 'de'}
            for name, code in lang_names.items():
                if re.search(r"\b" + re.escape(name) + r"\b", m.lower()):
                    entities["_language_target"] = code
                    break
            if not entities["_language_target"]:
                for code in LANGUAGES:
                    if re.search(r"(?<!\w)" + re.escape(code) + r"(?!\w)", m.lower()):
                        entities["_language_target"] = code
                        break
            break

    for w in RENAME_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m.lower()):
            entities["wants_rename"] = True
            parts = m.lower().split()
            for i, p in enumerate(parts):
                if p in ("to", "as", "на") and i + 1 < len(parts):
                    entities["_rename_target"] = parts[i + 1].strip(",.!?")
                    break
            else:
                for i, p in enumerate(parts):
                    if p in ("rename", "name", "username", "call", "име", "името", "преименувай") and i + 1 < len(parts):
                        candidate = parts[i + 1].strip(",.!?")
                        if candidate not in ("to", "as", "my", "me", "the", "new", "на", "моето"):
                            entities["_rename_target"] = candidate
                            break
            break

    for w in LOGIN_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m.lower()):
            entities["wants_login"] = True
            break

    for w in REGISTER_WORDS:
        if re.search(r"\b" + re.escape(w) + r"\b", m.lower()):
            entities["wants_register"] = True
            break

    date_range = re.search(r'(\d{1,2}[./]\d{1,2}[./]\d{2,4})\s*(?:until|to|through|thru|до|-)\s*(\d{1,2}[./]\d{1,2}[./]\d{2,4})', m)
    if date_range:
        start = _normalize_date_string(date_range.group(1))
        end = _normalize_date_string(date_range.group(2))
        if start and end:
            entities["check_in"] = start
            entities["check_out"] = end

    if not entities["check_in"] or not entities["check_out"]:
        date_strings = re.findall(r'(\d{1,2}[./]\d{1,2}[./]\d{2,4})', m)
        if len(date_strings) >= 2:
            start = _normalize_date_string(date_strings[0])
            end = _normalize_date_string(date_strings[1])
            if start and end:
                entities["check_in"] = start
                entities["check_out"] = end

    if not entities["check_in"] or not entities["check_out"]:
        entities["check_in"], entities["check_out"] = _extract_month_date_range(m)

    if not entities["check_in"] or not entities["check_out"]:
        # ISO dates, "12-14 December", "3 nights from 5 jan", "this weekend" (en/bg/es/de)
        entities["check_in"], entities["check_out"] = staya_dates.extract_stay(m)

    # Price limits: "under 100", "до 100 евро", "between 50 and 120", "over 200" ...
    limits = staya_pricing.parse_price_constraints(m)
    if limits["max"] is not None:
        entities["price_max"] = limits["max"]
    if limits["min"] is not None:
        entities["price_min"] = limits["min"]
    if limits["min"] is not None and limits["max"] is not None:
        entities["price_intent"] = "range"
    return entities


# ── INTENT SCORING ───────────────────────────────────────────────

def _score_intents(e):
    intents = []

    if e["wants_login"]:
        intents.append(("login", 130, e))

    if e["wants_register"]:
        intents.append(("register", 130, e))

    if e["wants_cheapest"] and e["property_types"]:
        intents.append(("cheapest_type", 115, e))

    if e["wants_toprated"] and e["property_types"]:
        intents.append(("toprated_type", 115, e))

    if e["property_types"] and e["countries"]:
        intents.append(("search_type_country", 100 + len(e["property_types"]) * 3, e))

    if e["property_types"] and e["cities"]:
        intents.append(("search_type_city", 95 + len(e["property_types"]) * 3, e))

    if e["property_types"] and (e["price_min"] is not None or e["price_max"] is not None) and e["countries"]:
        intents.append(("search_full", 110, e))

    if e["check_in"] and e["check_out"]:
        if e["wants_booking"] and (e["cities"] or e["countries"]) and e["property_types"]:
            intents.append(("booking_search", 135, e))
        intents.append(("availability", 120, e))
    elif e["wants_availability"]:
        intents.append(("availability", 90, e))

    if e["countries"] and e["price_min"] is not None:
        intents.append(("search_country_luxury" if e.get("price_intent") == "luxury" else "search_country_budget", 90, e))

    if e["countries"]:
        intents.append(("search_country", 80, e))

    if e["cities"] and (e["price_min"] is not None or e["price_max"] is not None):
        intents.append(("search_city_price", 85, e))

    if e["cities"]:
        intents.append(("search_city", 75, e))

    if e["property_types"] and (e["price_min"] is not None or e["price_max"] is not None):
        intents.append(("search_type_price", 80, e))

    if e["property_types"]:
        intents.append(("search_type", 70, e))

    if e["price_intent"] == "budget":
        intents.append(("budget", 55, e))
    elif e["price_intent"] == "luxury":
        intents.append(("luxury", 55, e))

    if e["wants_trending"]:
        intents.append(("trending", 50, e))

    if e["wants_booking"]:
        intents.append(("booking", 60, e))

    if e["wants_count"]:
        intents.append(("count", 40, e))

    if e["wants_help"]:
        intents.append(("help", 30, e))

    if e["wants_thanks"]:
        intents.append(("thanks", 20, e))

    if e["wants_theme"]:
        intents.append(("theme", 65, e))

    if e["wants_language"]:
        intents.append(("language", 65, e))

    if e["wants_rename"]:
        intents.append(("rename", 65, e))

    if e["has_greeting"] and not any(e[k] for k in ("cities", "countries", "property_types") if e[k]) and not e["wants_booking"] and not e["wants_help"] and not e["wants_trending"] and not e["wants_count"] and not e["wants_theme"] and not e["wants_language"] and not e["wants_rename"]:
        intents.append(("greeting", 5, e))

    intents.sort(key=lambda x: -x[1])
    return intents

# ── CONVERSATION MEMORY ──────────────────────────────────────────

def _save_context(session_id, message):
    if not session_id:
        return
    if session_id not in conversations_db:
        conversations_db[session_id] = []
    conversations_db[session_id].append(message)
    if len(conversations_db[session_id]) > 10:
        conversations_db[session_id] = conversations_db[session_id][-10:]


def _store_session_properties(session_id, properties):
    if not session_id or not isinstance(properties, list):
        return
    session_property_cache[session_id] = properties


def _get_session_properties(session_id):
    return session_property_cache.get(session_id, [])


def _find_property_in_session(session_id, message):
    properties = _get_session_properties(session_id)
    normalized = message.lower()

    if not properties:
        try:
            hotels = Hotel.search()
            properties = [{
                "id": hotel.id,
                "name": getattr(hotel, "name", ""),
                "city": getattr(hotel, "city", ""),
                "country": getattr(hotel, "country", ""),
                "property_type": getattr(hotel, "property_type", ""),
                "price_per_night": getattr(hotel, "price_per_night", 0) or 0,
                "avg_rating": float(getattr(hotel, "avg_rating", 0) or 0),
            } for hotel in hotels]
        except Exception:
            properties = []

    # Allow choosing by ordinal position in the last list
    ordinal = re.search(r"\b(?:first|second|third|1st|2nd|3rd)\b", normalized)
    if ordinal:
        text = ordinal.group(0)
        if "first" in text or "1st" in text:
            return properties[0] if len(properties) > 0 else None
        if "second" in text or "2nd" in text:
            return properties[1] if len(properties) > 1 else None
        if "third" in text or "3rd" in text:
            return properties[2] if len(properties) > 2 else None

    number = re.search(r"(?<![\d./])\b(\d+)\b(?![\d./])(?:\s+(?:hotel|property|result|choice))?", normalized)
    if number:
        idx = int(number.group(1)) - 1
        if 0 <= idx < len(properties):
            return properties[idx]

    explicit_id = re.search(r"\b(?:hotel|property)\s*(?:id\s*)?#?(\d+)\b", normalized)
    if explicit_id:
        pid = int(explicit_id.group(1))
        for prop in properties:
            if prop.get("id") == pid:
                return prop

    for prop in properties:
        if prop.get("name") and prop["name"].lower() in normalized:
            return prop

    # Fallback to the first property when the user refers to "this" or "that" after a property listing
    if any(word in normalized for word in ("this property", "this hotel", "that hotel", "that property", "selected")):
        return properties[0]

    return None


def _load_context(session_id):
    if session_id and session_id in conversations_db:
        return conversations_db[session_id]
    return []

# ── INTENT EXECUTORS ─────────────────────────────────────────────

def _exec_greeting(e, session_id=None):
    lang = e.get("_lang", "en")
    if current_user.is_authenticated:
        return _make_response(
            f"{_t('Welcome back', lang)}, {current_user.username}. {_t('Systems online. How can I assist with your travels?', lang)}",
            [_t("Search Hotels", lang), _t("My Bookings", lang), _t("Popular Destinations", lang), _t("Deals", lang)]
        )
    return _make_response(
        _t("Good day. I'm Staya, your travel intelligence system. Looking for a place to stay?", lang),
        [_t("Search Hotels", lang), _t("Popular Destinations", lang), _t("Sign In", lang), _t("Deals", lang)]
    )

def _exec_search_city(e, session_id):
    lang = e.get("_lang", "en")
    ctx = _load_context(session_id)
    city = e["cities"][0]
    if not city:
        city = _extract_city_from_context(ctx)
    if not city:
        return _make_response(
            _t("Which city are you interested in?", lang),
            [_t("Popular Destinations", lang), _t("Browse All Properties", lang)]
        )

    hotels = _search_hotels(destination=city)
    if not isinstance(hotels, list) or not hotels:
        return _make_response(
            _t("Scanned {city} — no properties found. Try a different city?", lang).format(city=city),
            [_t("Browse All Properties", lang), _t("Popular Destinations", lang)]
        )
    _store_session_properties(session_id, hotels)

    lines = [_t("Here are **{count} properties** found in {city}.", lang).format(count=len(hotels), city=city)]
    for h in hotels[:4]:
        stars = "★" * h.get("stars", 3)
        lines.append(f"> {stars} **{h['name']}** — EUR{h['price_per_night']}/night — ⭐ {h['avg_rating']}/5")
    if len(hotels) > 4:
        lines.append("\n" + _t("{count} more available.", lang).format(count=len(hotels) - 4))
    lines.append("\n" + _t("Would you like me to check availability for these?", lang))

    qr = [_t("Check dates", lang), _t("Show all", lang), _t("Popular Destinations", lang)]
    nav = f"/user/stays/search?destination={city}"
    if e.get("price_intent") == "budget":
        nav += "&sort_by=price_asc"
    elif e.get("price_intent") == "luxury":
        nav += "&sort_by=price_desc"
    return _make_response("\n".join(lines), qr, navigate=nav, properties=_props_for(hotels))

def _exec_search_country(e, session_id):
    lang = e.get("_lang", "en")
    ctx = _load_context(session_id)
    country = e["countries"][0] if e["countries"] else None
    if not country:
        country = _extract_country_from_context(ctx)
    if not country:
        return _make_response(
            _t("Which country are you looking at?", lang),
            [_t("Popular Destinations", lang), _t("Browse All Properties", lang)]
        )

    hotels = _search_hotels(destination=country)
    if not isinstance(hotels, list) or not hotels:
        return _make_response(
            _t("No properties found in {country} yet. Try a nearby destination?", lang).format(country=country),
            [_t("Browse All Properties", lang), _t("Popular Destinations", lang)]
        )
    _store_session_properties(session_id, hotels)

    cities_list = list(dict.fromkeys(h["city"] for h in hotels if h.get("city")))
    cities_line = f" {_t('Spread across', lang)} **{', '.join(cities_list[:5])}**." if cities_list else ""

    price_range = f"EUR{min(h['price_per_night'] for h in hotels)}–EUR{max(h['price_per_night'] for h in hotels)}/night"
    avg_rating = round(sum(h["avg_rating"] for h in hotels) / len(hotels), 1)

    lines = [_t("Here are **{count} properties** in {country}.", lang).format(count=len(hotels), country=country) + cities_line]
    lines.append(_t("Price range: {range} | Avg rating: {rating}/5", lang).format(range=price_range, rating=avg_rating) + "\n")
    for h in hotels[:3]:
        lines.append(f"> **{h['name']}** — {h['city']} — EUR{h['price_per_night']}/night — ⭐ {h['avg_rating']}/5")
    if len(hotels) > 3:
        lines.append("\n" + _t("+ {count} more properties.", lang).format(count=len(hotels) - 3))
    lines.append("\n" + _t("Would you like me to check availability for these?", lang))

    nav = f"/user/stays/search?destination={country}"
    if e.get("price_intent") == "budget":
        nav += "&sort_by=price_asc"
    elif e.get("price_intent") == "luxury":
        nav += "&sort_by=price_desc"
    return _make_response("\n".join(lines), [_t("Show all", lang), _t("Filter by type", lang), _t("Popular Destinations", lang)],
                          navigate=nav, properties=_props_for(hotels))

def _exec_search_type(e, session_id):
    lang = e.get("_lang", "en")
    ctx = _load_context(session_id)
    ptypes = e["property_types"]
    if not ptypes:
        pt = _extract_type_from_context(ctx)
        ptypes = {pt} if pt else set()
    if not ptypes:
        counts = _get_property_counts()
        if isinstance(counts, dict):
            return _make_response(
                _t("What type? We have {h} hotels, {a} apartments, {v} villas, {r} resorts.", lang).format(
                    h=counts.get('hotels', 0), a=counts.get('apartments', 0),
                    v=counts.get('villas', 0), r=counts.get('resorts', 0)),
                [_t("Hotels", lang), _t("Apartments", lang), _t("Villas", lang), _t("Resorts", lang)]
            )
        return _make_response(
            _t("Which type? Hotels, apartments, villas, or resorts?", lang),
            [_t("Hotels", lang), _t("Apartments", lang), _t("Villas", lang), _t("Resorts", lang)]
        )

    ptype = next(iter(ptypes))
    dest = None
    if e["cities"]:
        dest = e["cities"][0]
    elif e["countries"]:
        dest = e["countries"][0]
    else:
        for ctx_msg in reversed(ctx):
            ce = _extract_entities(ctx_msg.lower())
            if ce["cities"]:
                dest = ce["cities"][0]
                break
            if ce["countries"]:
                dest = ce["countries"][0]
                break

    stars = e.get("stars", []) or []
    hotels = _search_hotels(destination=dest, property_type=ptype, stars=stars if stars else None,
                             min_price=e.get("price_min"), max_price=e.get("price_max"))

    if not isinstance(hotels, list) or not hotels:
        filters = []
        if e.get("price_max"):
            filters.append(_t("under EUR{max}", lang).format(max=e['price_max']))
        if e.get("price_min"):
            filters.append(_t("over EUR{min}", lang).format(min=e['price_min']))
        if e.get("stars"):
            filters.append(_t("{star}-star", lang).format(star=e['stars'][0]))
        filter_str = f" ({', '.join(filters)})" if filters else ""

        all_in_loc = _search_hotels(destination=dest) if dest else []
        if isinstance(all_in_loc, list) and all_in_loc:
            other_types = list(dict.fromkeys(h["property_type"] for h in all_in_loc if h.get("property_type") != ptype))
            msg = _t("No {ptype}s in {dest}{filters}.", lang).format(ptype=ptype, dest=dest, filters=filter_str) + " "
            if other_types:
                other_plural = [t + "s" for t in other_types[:3]]
                msg += _t("However, there are {types} available in {dest}. Want to try those?", lang).format(types=', '.join(other_plural), dest=dest)
            else:
                msg += _t("The properties in {dest} start from EUR{min_price}/night. Try a higher budget?", lang).format(dest=dest, min_price=min(h['price_per_night'] for h in all_in_loc))
            nav = f"/user/stays/search?destination={dest}" if dest else "/user/stays/search"
            return _make_response(msg, [_t("Adjust Filters", lang), _t("Browse All", lang)], navigate=nav, properties=_props_for(all_in_loc))

        loc_str = f" {_t('in', lang)} {dest}" if dest else ""
        return _make_response(
            _t("No {ptype}s found{location}{filters}. Try a different location or property type?", lang).format(ptype=ptype, location=loc_str, filters=filter_str),
            [_t("Browse All Properties", lang), _t("Popular Destinations", lang)], navigate="/user/stays/search",
            properties=_props_for([])
        )

    type_label = ptype if len(hotels) == 1 else f"{ptype}s"
    if dest:
        lines = [_t("Here are **{count} {type}** in {dest}:", lang).format(count=len(hotels), type=type_label, dest=dest) + "\n"]
    else:
        lines = [_t("Here are **{count} {type}**:", lang).format(count=len(hotels), type=type_label) + "\n"]
    for h in hotels[:4]:
        star_str = "★" * h.get("stars", 3) if h.get("stars") else ""
        lines.append(f"> {star_str} **{h['name']}** — {h['city']} — EUR{h['price_per_night']}/night — ⭐ {h['avg_rating']}/5")
    if len(hotels) > 4:
        lines.append("\n" + _t("+ {count} more.", lang).format(count=len(hotels) - 4))
    lines.append("\n" + _t("Would you like me to check availability?", lang))
    _store_session_properties(session_id, hotels)

    nav = f"/user/stays/search?property_type={ptype}"
    if dest:
        nav += f"&destination={dest}"

    if e.get("price_intent") == "budget":
        nav += "&sort_by=price_asc"
    elif e.get("price_intent") == "luxury":
        nav += "&sort_by=price_desc"

    if e.get("price_min"):
        nav += f"&min_price={e['price_min']}"
    if e.get("price_max"):
        nav += f"&max_price={e['price_max']}"

    qr = [_t("Check dates", lang), _t("Show all results", lang)]
    if not dest:
        qr.append(_t("Search by City", lang))
    return _make_response("\n".join(lines), qr, navigate=nav, properties=_props_for(hotels))

def _exec_budget(e, session_id):
    lang = e.get("_lang", "en")
    max_p = e.get("price_max") or 100
    hotels = _search_hotels(max_price=max_p)
    if not isinstance(hotels, list) or not hotels:
        return _make_response(
            _t("Nothing under EUR{max}/night right now. Try a higher budget?", lang).format(max=max_p),
            [_t("Browse All Properties", lang), _t("Popular Destinations", lang)]
        )
    _store_session_properties(session_id, hotels)
    lines = [_t("**Budget picks — under EUR{max}/night:**", lang).format(max=max_p) + "\n"]
    for h in hotels[:5]:
        lines.append(f"> **{h['name']}** — {h['city']}, {h['country']} — EUR{h['price_per_night']}/night")
    lines.append("\n" + _t("Great value options. Ready to explore more?", lang))
    return _make_response("\n".join(lines), [_t("Show All Budget", lang), _t("Search Hotels", lang)], navigate=f"/user/stays/search?max_price={max_p}&sort_by=price_asc", properties=_props_for(hotels))

def _exec_luxury(e, session_id):
    lang = e.get("_lang", "en")
    min_p = e.get("price_min") or 200
    hotels = _search_hotels(min_price=min_p)
    if not isinstance(hotels, list) or not hotels:
        return _make_response(
            _t("Nothing over EUR{min}/night currently. Try a different range?", lang).format(min=min_p),
            [_t("Browse All Properties", lang), _t("Popular Destinations", lang)]
        )
    _store_session_properties(session_id, hotels)
    lines = [_t("**Premium selection — EUR{min}+/night:**", lang).format(min=min_p) + "\n"]
    for h in hotels[:5]:
        star_str = "★" * h.get("stars", 3)
        lines.append(f"> {star_str} **{h['name']}** — {h['city']} — EUR{h['price_per_night']}/night — ⭐ {h['avg_rating']}/5")
    lines.append("\n" + _t("Experience the finest. Ready to book?", lang))
    return _make_response("\n".join(lines), [_t("Show All Luxury", lang), _t("Search Hotels", lang)], navigate=f"/user/stays/search?min_price={min_p}&sort_by=price_desc", properties=_props_for(hotels))

def _exec_trending(e, session_id):
    lang = e.get("_lang", "en")
    all_h = _search_hotels()
    if not isinstance(all_h, list) or not all_h:
        return _make_response(_t("No properties available to recommend right now.", lang), [_t("Browse Later", lang)])
    top = sorted(all_h, key=lambda h: h.get("avg_rating", 0), reverse=True)[:6]
    _store_session_properties(session_id, top)
    lines = [_t("**Trending destinations — top rated right now:**", lang) + "\n"]
    for h in top:
        lines.append(f"> ⭐ **{h['name']}** — {h['city']}, {h['country']} — {h['avg_rating']}/5 — EUR{h['price_per_night']}/night")
    lines.append("\n" + _t("Any of these catch your eye?", lang))
    return _make_response("\n".join(lines), [_t("Browse All", lang), _t("Cheapest First", lang), _t("Top Rated", lang)], navigate="/user/stays/search?sort_by=rating_desc", properties=_props_for(top))

def _exec_cheapest_type(e, session_id):
    lang = e.get("_lang", "en")
    ctx = _load_context(session_id)
    ptypes = e["property_types"]
    if not ptypes:
        pt = _extract_type_from_context(ctx)
        ptypes = {pt} if pt else set()
    if not ptypes:
        return _make_response(
            _t("Which type? We have hotels, apartments, villas, and resorts.", lang),
            [_t("Hotels", lang), _t("Apartments", lang), _t("Villas", lang), _t("Resorts", lang)]
        )

    ptype = next(iter(ptypes))
    hotels = _search_hotels(property_type=ptype, limit=50)
    
    if not isinstance(hotels, list) or not hotels:
        return _make_response(
            _t("No {ptype}s available right now. Try a different type?", lang).format(ptype=ptype),
            [_t("Hotels", lang), _t("Apartments", lang), _t("Villas", lang), _t("Resorts", lang)], navigate="/user/stays/search"
        )
    
    hotels_sorted = sorted(hotels, key=lambda h: h.get("price_per_night", 0))
    
    lines = [_t("Here are the **cheapest {ptype}s** — sorted by price:", lang).format(ptype=ptype) + "\n"]
    for h in hotels_sorted[:5]:
        stars = "★" * h.get("stars", 3) if h.get("stars") else ""
        lines.append(f"> {stars} **{h['name']}** — {h['city']} — EUR{h['price_per_night']}/night — ⭐ {h['avg_rating']}/5")
    
    if len(hotels_sorted) > 5:
        lines.append("\n" + _t("+ {count} more affordable options.", lang).format(count=len(hotels_sorted) - 5))
    
    lines.append("\n" + _t("Here are the best bargains. Would you like me to check availability?", lang))
    
    return _make_response("\n".join(lines), [_t("Show All", lang), _t("Filter by City", lang), _t("Other Types", lang)], 
                          navigate=f"/user/stays/search?property_type={ptype}&sort_by=price_asc",
                          properties=_props_for(hotels_sorted))

def _exec_toprated_type(e, session_id):
    lang = e.get("_lang", "en")
    ctx = _load_context(session_id)
    ptypes = e["property_types"]
    if not ptypes:
        pt = _extract_type_from_context(ctx)
        ptypes = {pt} if pt else set()
    if not ptypes:
        return _make_response(
            _t("Which type? We have hotels, apartments, villas, and resorts.", lang),
            [_t("Hotels", lang), _t("Apartments", lang), _t("Villas", lang), _t("Resorts", lang)]
        )

    ptype = next(iter(ptypes))
    hotels = _search_hotels(property_type=ptype, limit=50)
    
    if not isinstance(hotels, list) or not hotels:
        return _make_response(
            _t("No {ptype}s available right now. Try a different type?", lang).format(ptype=ptype),
            [_t("Hotels", lang), _t("Apartments", lang), _t("Villas", lang), _t("Resorts", lang)], navigate="/user/stays/search"
        )
    
    hotels_sorted = sorted(hotels, key=lambda h: h.get("avg_rating", 0), reverse=True)
    
    lines = [_t("Here are the **top rated {ptype}s** — highest guest ratings:", lang).format(ptype=ptype) + "\n"]
    for h in hotels_sorted[:5]:
        stars = "★" * h.get("stars", 3) if h.get("stars") else ""
        lines.append(f"> {stars} **{h['name']}** — {h['city']} — ⭐ {h['avg_rating']}/5 — EUR{h['price_per_night']}/night")
    
    if len(hotels_sorted) > 5:
        lines.append("\n" + _t("+ {count} more excellent options.", lang).format(count=len(hotels_sorted) - 5))
    
    lines.append("\n" + _t("Here are the top rated stays. Would you like me to check availability?", lang))
    _store_session_properties(session_id, hotels_sorted)
    return _make_response("\n".join(lines), [_t("Show All", lang), _t("Filter by City", lang), _t("Other Types", lang)], 
                          navigate=f"/user/stays/search?property_type={ptype}&sort_by=rating_desc",
                          properties=_props_for(hotels_sorted))


def _exec_availability(e, session_id):
    lang = e.get("_lang", "en")
    property_selected = _find_property_in_session(session_id, e["raw"]) if session_id else None
    if not property_selected and session_id:
        cached = _get_session_properties(session_id)
        if cached and isinstance(cached, list):
            property_selected = cached[0]

    if not property_selected:
        return _make_response(
            _t("Which property would you like to check availability for? Say 'first property', 'second hotel', or mention the hotel name.", lang),
            [_t("First property", lang), _t("Second hotel", lang), _t("Search Hotels", lang)]
        )

    if not e["check_in"] or not e["check_out"]:
        return _make_response(
            _t("What dates should I check for {name}? Please use a range like 12.08.2026 to 14.08.2026.", lang).format(name=property_selected['name']),
            [_t("12.08.2026 to 14.08.2026", lang), _t("Next weekend", lang), _t("Search Hotels", lang)]
        )

    url = f"/user/hotel/{property_selected['id']}?check_in={e['check_in']}&check_out={e['check_out']}"
    return _make_response(
        _t("I found availability for {name} from {check_in} to {check_out}. Redirecting you to the property page.", lang).format(name=property_selected['name'], check_in=e['check_in'], check_out=e['check_out']),
        [_t("View Property", lang), _t("Browse More Stays", lang)], navigate=url,
        properties=[property_selected]
    )

def _exec_booking_search(e, session_id):
    lang = e.get("_lang", "en")
    destination = e["cities"][0] if e["cities"] else e["countries"][0]
    property_type = next(iter(e["property_types"]))
    result = _find_booking_options(destination, property_type, e["check_in"], e["check_out"])
    if not result.get("success"):
        return _make_response(
            _t("I couldn't check those dates. Please give me a future check-in and check-out date.", lang),
            [_t("Search Stays", lang), _t("My Bookings", lang)],
        )

    options = result["options"]
    for option in options:
        option["booking_label"] = "Продължи към резервацията" if lang == "bg" else "Continue to checkout"
    _store_session_properties(session_id, options)
    if not options:
        if lang == "bg":
            text = f"Не открих свободни {property_type} във {destination} от {result['check_in']} до {result['check_out']}. Може да опитате с други дати или дестинация."
        else:
            text = f"I couldn't find available {property_type}s in {destination} from {result['check_in']} to {result['check_out']}. Try different dates or another destination."
        return _make_response(text, [_t("Change dates", lang), _t("Search Stays", lang)])

    if lang == "bg":
        count_text = "1 свободен вариант" if len(options) == 1 else f"{len(options)} свободни варианта"
        destination_label = "във Венеция" if destination.lower() == "venice" else f"в {destination}"
        text = f"Намерих {count_text} за {result['nights']} нощувки {destination_label} ({result['check_in']} – {result['check_out']}). Изберете вариант, за да продължите към потвърждение и плащане."
    else:
        text = f"I found {len(options)} available {property_type}(s) in {destination} for {result['nights']} nights ({result['check_in']} to {result['check_out']}). Choose an option to continue to confirmation and payment."
    return _make_response(text, properties=options)


def _exec_booking(e, session_id):
    lang = e.get("_lang", "en")
    if not current_user.is_authenticated:
        return _make_response(
            _t("You need to sign in to access your bookings.", lang),
            [_t("Sign In", lang), _t("Create Account", lang)], navigate="/login"
        )
    info = _get_bookings_info()
    if isinstance(info, dict) and info.get("total", 0) > 0:
        return _make_response(
            _t("You have **{count} active booking(s)** on your account. Need details or changes?", lang).format(count=info['total']),
            [_t("My Bookings", lang), _t("Browse Stays", lang)], navigate="/user/my-reservations"
        )
    return _make_response(
        _t("No active bookings found. Ready to plan your next trip?", lang),
        [_t("Search Hotels", lang), _t("Popular Destinations", lang)], navigate="/user/stays/search"
    )

def _exec_help(e, session_id):
    lang = e.get("_lang", "en")
    return _make_response(
        _t("How can I help you? Try asking about hotels, apartments, or destinations.", lang),
        [_t("Search Hotels", lang), _t("Popular Destinations", lang), _t("My Bookings", lang), _t("Deals", lang)]
    )

def _exec_thanks(e, session_id):
    lang = e.get("_lang", "en")
    return _make_response(
        _t("Happy to help. Let me know if you need anything else.", lang),
        [_t("Search Hotels", lang), _t("My Bookings", lang), _t("Popular Destinations", lang)]
    )

def _exec_count(e, session_id):
    lang = e.get("_lang", "en")
    counts = _get_property_counts()
    if not isinstance(counts, dict) or "total" not in counts:
        return _make_response(_t("Could not retrieve property counts.", lang), [_t("Browse All", lang)])
    all_h = _search_hotels(limit=50)
    prices = [h["price_per_night"] for h in all_h] if isinstance(all_h, list) else []
    price_str = ""
    if prices:
        price_str = f" | EUR{min(prices)}–EUR{max(prices)}/night"
    return _make_response(
        _t("**{total} properties** worldwide: {h} hotels, {a} apartments, {v} villas, {r} resorts across 12 countries.{price}", lang).format(
            total=counts['total'], h=counts['hotels'], a=counts['apartments'],
            v=counts['villas'], r=counts['resorts'], price=price_str) + "\n\n" + _t("Ready to browse?", lang),
        [_t("Browse All", lang), _t("Cheapest First", lang), _t("Search by City", lang)], navigate="/user/stays/search?sort_by=recommended"
    )

def _exec_fallback(e, session_id):
    lang = e.get("_lang", "en")
    all_h = _search_hotels(limit=50)
    counts = _get_property_counts()
    total = counts.get("total", len(all_h)) if isinstance(counts, dict) else len(all_h)
    if isinstance(all_h, list) and all_h:
        cheap_h = min(all_h, key=lambda h: h.get("price_per_night", 0))
        top_h = max(all_h, key=lambda h: h.get("avg_rating", 0))
        return _make_response(
            _t("I'm not sure I understood that. Here's what's happening on StayOra:", lang) +
            f"\n\n✨ **{_t('Best rated', lang)}**: {top_h['name']} in {top_h['city']} (⭐ {top_h['avg_rating']}/5, EUR{top_h['price_per_night']}/night)\n"
            f"💰 **{_t('Best value', lang)}**: {cheap_h['name']} from EUR{cheap_h['price_per_night']}/night\n"
            f"🌍 **{total} {_t('properties', lang)}** {_t('across 12 countries', lang)}\n\n"
            + _t("Try: 'Hotels in Paris', 'cheap apartments', or 'my bookings'", lang),
            [_t("Browse All", lang), _t("Popular Destinations", lang), _t("Search by City", lang), _t("Help", lang)]
        )
    return _make_response(
        _t("I'm Staya. Ask me about hotels, destinations, or your bookings.", lang),
        [_t("Search Hotels", lang), _t("Popular Destinations", lang), _t("Help", lang)]
    )

# ── CONTEXT HELPERS ──────────────────────────────────────────────

def _extract_city_from_context(ctx):
    for msg in reversed(ctx):
        e = _extract_entities(msg.lower())
        if e["cities"]:
            return e["cities"][0]
    return None

def _extract_country_from_context(ctx):
    for msg in reversed(ctx):
        e = _extract_entities(msg.lower())
        if e["countries"]:
            return e["countries"][0]
    return None

def _extract_type_from_context(ctx):
    for msg in reversed(ctx):
        e = _extract_entities(msg.lower())
        if e["property_types"]:
            return next(iter(e["property_types"]))
    return None

def _exec_theme(e, session_id):
    lang = e.get("_lang", "en")
    mode = e.get("_theme_mode") or "dark"
    result = _change_theme(mode)
    if result.get("success"):
        mode_label = _t(mode, lang) if lang != 'en' else mode
        return {"text": _t("Switching to {mode} mode.", lang).format(mode=mode_label), "intent": "db", "theme": mode, "actions": _actions("")}
    return {"text": _t("Could not change theme.", lang), "intent": "db"}

def _exec_language(e, session_id):
    lang = e.get("_lang", "en")
    target = e.get("_language_target") or "en"
    result = _change_language(target)
    if result.get("success"):
        name = LANGUAGES.get(target, target)
        return {"text": _t("Switching language to {name}.", lang).format(name=name), "intent": "db", "language": target, "actions": _actions("")}
    supported = ", ".join(result.get("supported", []))
    return {"text": _t("Unsupported language. Choose from: {list}", lang).format(list=supported), "intent": "db"}

def _exec_rename(e, session_id):
    lang = e.get("_lang", "en")
    new_name = e.get("_rename_target") or ""
    if not new_name:
        return {"text": _t("What username would you like? Say something like 'rename me to John'.", lang), "intent": "db"}
    result = _rename_username(new_name)
    if result.get("success"):
        return {"text": result.get("message", "Username updated."), "intent": "db", "rename_username": result}
    return {"text": result.get("error", "Could not rename."), "intent": "db", "rename_username": result}

def _exec_login(e, session_id):
    lang = e.get("_lang", "en")
    if current_user.is_authenticated:
        return {"text": _t("You are already logged in.", lang), "intent": "db", "navigate": url_for('user.dashboard'),
                "quick_replies": [_t("Dashboard", lang), _t("Browse Stays", lang), _t("My Bookings", lang)]}
    return {"text": _t("Taking you to the login page.", lang), "intent": "db", "navigate": url_for('auth.login'),
            "quick_replies": [_t("Create Account", lang), _t("Browse Stays", lang)]}

def _exec_register(e, session_id):
    lang = e.get("_lang", "en")
    if current_user.is_authenticated:
        return {"text": _t("You already have an account. Would you like to go to your dashboard?", lang), "intent": "db",
                "navigate": url_for('user.dashboard'),
                "quick_replies": [_t("Dashboard", lang), _t("Browse Stays", lang)]}
    return {"text": _t("Taking you to the registration page.", lang), "intent": "db", "navigate": url_for('auth.register'),
            "quick_replies": [_t("Sign In", lang), _t("Browse Stays", lang)]}

# ── MAIN DB RESPONSE ENGINE ──────────────────────────────────────

INTENT_MAP = {
    "greeting": _exec_greeting,
    "search_city": _exec_search_city,
    "search_country": _exec_search_country,
    "search_city_price": _exec_search_city,
    "search_country_budget": _exec_search_country,
    "search_country_luxury": _exec_search_country,
    "search_type": _exec_search_type,
    "search_type_city": _exec_search_type,
    "search_type_country": _exec_search_type,
    "search_type_price": _exec_search_type,
    "search_full": _exec_search_type,
    "budget": _exec_budget,
    "luxury": _exec_luxury,
    "trending": _exec_trending,
    "cheapest_type": _exec_cheapest_type,
    "toprated_type": _exec_toprated_type,
    "booking": _exec_booking,
    "booking_search": _exec_booking_search,
    "availability": _exec_availability,
    "help": _exec_help,
    "thanks": _exec_thanks,
    "count": _exec_count,
    "theme": _exec_theme,
    "language": _exec_language,
    "rename": _exec_rename,
    "login": _exec_login,
    "register": _exec_register,
}

def _db_response(message, session_id=None, lang='en'):
    _save_context(session_id, message)
    m = message.lower().strip()
    e = _extract_entities(m)
    if not e["check_in"] or not e["check_out"]:
        for prior_message in reversed(_load_context(session_id)):
            prior_entities = _extract_entities(prior_message.lower())
            if prior_entities["check_in"] and prior_entities["check_out"]:
                e["check_in"] = prior_entities["check_in"]
                e["check_out"] = prior_entities["check_out"]
                break
    detected = _detect_lang(message)
    e["_lang"] = detected if detected != 'en' else lang

    intents = _score_intents(e)
    if intents:
        intent_name = intents[0][0]
        executor = INTENT_MAP.get(intent_name, _exec_fallback)
        result = executor(e, session_id)
        return result

    return _exec_fallback(e, session_id)

# ── LEGACY HELPERS ───────────────────────────────────────────────

def _make_response(text, quick_replies=None, navigate=None, properties=None):
    resp = {"text": text, "intent": "db", "actions": _actions(text)}
    if quick_replies:
        resp["quick_replies"] = quick_replies
    if navigate:
        resp["navigate"] = navigate
    if properties is not None:
        resp["properties"] = properties
    return resp

def _quick_replies(text):
    t = text.lower()
    if any(w in t for w in ("booking", "reservation")):
        return ["My Bookings", "Browse Stays", "Deals"]
    if any(w in t for w in ("deal", "offer", "promotion")):
        return ["View Deals", "Search Hotels", "Popular Destinations"]
    if any(w in t for w in ("destination", "trending", "place", "city")):
        return ["Hotels", "Apartments", "Villas", "Trending"]
    return ["Search Hotels", "Popular Destinations", "My Bookings", "Deals"]

def _actions(text):
    try:
        t = text.lower()
        acts = [{"label": "Browse Stays", "url": url_for("user.browse_stays"), "primary": False}]
        if any(w in t for w in ("hotel", "apartment", "villa", "resort", "property", "stay")):
            acts.insert(0, {"label": "Search Properties", "url": url_for("user.search_stays"), "primary": True})
        return acts
    except Exception:
        return []


def _props_for(hotels, limit=8):
    if not isinstance(hotels, list):
        return []
    out = []
    for h in hotels[:limit]:
        out.append({
            "id": h.get("id"),
            "name": h.get("name"),
            "city": h.get("city"),
            "country": h.get("country"),
            "property_type": h.get("property_type"),
            "price_per_night": h.get("price_per_night"),
            "avg_rating": h.get("avg_rating")
        })
    return out

def detect_intent(message):
    return "gemini"

def get_response_for_intent(intent, message=None):
    return {"text": "How can I help you?", "intent": "openai"}
