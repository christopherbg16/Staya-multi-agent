"""What page is the person looking at?

The chat widget sends `location.pathname + location.search`.  It is parsed here
into a PageContext.  Everything in it is treated as an untrusted *hint*: ids are
re-validated against the database and nothing in it grants any permission.
"""
import re
from dataclasses import dataclass, field
from datetime import datetime
from urllib.parse import parse_qs, urlsplit

PATTERNS = [
    ('property', re.compile(r'^/user/hotel/(\d+)/?$')),
    ('checkout_room', re.compile(r'^/payments/checkout/room/(\d+)/?$')),
    ('checkout_property', re.compile(r'^/payments/checkout/property/(\d+)/?$')),
    ('thread', re.compile(r'^/messages/(\d+)/?$')),
    ('inbox', re.compile(r'^/messages/?$')),
    ('search', re.compile(r'^/user/(?:stays|hotels)/search/?$')),
    ('bookings', re.compile(r'^/user/my-reservations/?$')),
    ('destination', re.compile(r'^/user/destination/([^/]+)/?$')),
    ('owner_area', re.compile(r'^/admin(?:/.*)?$')),
    ('home', re.compile(r'^/$')),
]


def _iso(value):
    try:
        return datetime.strptime((value or '')[:10], '%Y-%m-%d').date().isoformat()
    except ValueError:
        return None


def _int(value, lo=1, hi=10_000_000):
    try:
        n = int(value)
        return n if lo <= n <= hi else None
    except (TypeError, ValueError):
        return None


@dataclass
class PageContext:
    kind: str = 'other'
    path: str = ''
    property_id: int = None
    room_id: int = None
    thread_id: int = None
    check_in: str = None
    check_out: str = None
    nights: int = None
    guests: int = None
    destination: str = None
    property_type: str = None
    offer_id: int = None
    raw_query: dict = field(default_factory=dict)

    def describe(self):
        """One line for the language model's system prompt."""
        bits = [f'page={self.kind}']
        for name in ('property_id', 'room_id', 'thread_id', 'check_in', 'check_out', 'nights', 'guests',
                     'destination', 'property_type'):
            value = getattr(self, name)
            if value:
                bits.append(f'{name}={value}')
        return ', '.join(bits)


def parse_page(page):
    """`page` is {'path': '/user/hotel/3', 'search': '?check_in=...'} or a URL string."""
    if isinstance(page, str):
        parts = urlsplit(page)
        path, search = parts.path, parts.query
    elif isinstance(page, dict):
        path = str(page.get('path') or '')
        search = str(page.get('search') or '').lstrip('?')
    else:
        return PageContext()
    path = path[:300]
    query = {k: v[0] for k, v in parse_qs(search[:1000]).items() if v}
    ctx = PageContext(path=path, raw_query=query)
    for kind, pattern in PATTERNS:
        m = pattern.match(path)
        if not m:
            continue
        ctx.kind = kind
        if kind == 'property':
            ctx.property_id = _int(m.group(1))
        elif kind == 'checkout_room':
            ctx.room_id = _int(m.group(1))
        elif kind == 'checkout_property':
            ctx.property_id = _int(m.group(1))
        elif kind == 'thread':
            ctx.thread_id = _int(m.group(1))
        elif kind == 'destination':
            ctx.destination = m.group(1)[:80]
        break
    ctx.check_in = _iso(query.get('check_in') or query.get('start_date'))
    ctx.check_out = _iso(query.get('check_out'))
    ctx.nights = _int(query.get('nights'), 1, 365)
    guests = _int(query.get('guests') or query.get('adults'), 1, 30)
    ctx.guests = guests
    ctx.destination = (query.get('destination') or ctx.destination or None)
    ctx.property_type = query.get('property_type') or query.get('type') or None
    ctx.offer_id = _int(query.get('offer_id'))
    return ctx
