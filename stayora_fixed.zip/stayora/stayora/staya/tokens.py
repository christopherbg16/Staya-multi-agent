"""Signed, short-lived, single-use confirmation tokens.

The model can *prepare* an action (booking, offer, review, message, cancel) but
only the person clicking "Confirm" in the chat can execute it.  The token binds
the action to one user and to the exact parameters that were shown to them.
"""
import secrets
import threading
import time

from flask import current_app
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from .errors import ActionError  # noqa: F401  (re-exported)

SALT = 'staya-confirm-v1'
DEFAULT_TTL = 15 * 60

_used = {}
_used_lock = threading.Lock()


def _serializer():
    return URLSafeTimedSerializer(current_app.config['SECRET_KEY'], salt=SALT)


def issue(action, user_id, payload):
    data = {'a': action, 'u': int(user_id), 'p': payload, 'n': secrets.token_hex(8)}
    return _serializer().dumps(data)


def read(token, action, user_id, max_age=DEFAULT_TTL, consume=True):
    if not token or not isinstance(token, str):
        raise ActionError('invalid_token', 'This confirmation is not valid any more. Please ask again.')
    try:
        data = _serializer().loads(token, max_age=max_age)
    except SignatureExpired:
        raise ActionError('expired', 'This confirmation expired. Please ask again to get a fresh one.') from None
    except BadSignature:
        raise ActionError('invalid_token', 'This confirmation is not valid any more. Please ask again.') from None
    if data.get('a') != action:
        raise ActionError('wrong_action', 'This confirmation belongs to a different action.')
    if int(data.get('u', -1)) != int(user_id):
        raise ActionError('wrong_user', 'This confirmation belongs to another account.')
    if consume:
        nonce = data.get('n')
        now = time.time()
        with _used_lock:
            for key in [k for k, ts in _used.items() if now - ts > max_age + 60]:
                _used.pop(key, None)
            if nonce in _used:
                raise ActionError('used', 'This confirmation was already used.')
            _used[nonce] = now
    return data['p']


def use(token, action, user_id, max_age=DEFAULT_TTL):
    """Burn a token (single use).  Raises ActionError if it was already used."""
    return read(token, action, user_id, max_age=max_age, consume=True)
