"""Pricing helpers: exact money maths, effective nightly prices, market comparison
and price-constraint parsing (en / bg / es / de)."""
import re
import statistics
from decimal import Decimal, ROUND_HALF_UP

from models import Hotel, ROOM_TYPES, effective_prices, room_min_prices, supabase  # noqa: F401

CURRENCY = 'EUR'


def price_total(price_per_night, nights):
    """(Decimal total, total in cents). The single source of truth for money maths."""
    try:
        total = (Decimal(str(price_per_night)) * nights).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    except Exception:
        raise ValueError('This property has an invalid nightly price.') from None
    if total < 0:
        raise ValueError('This property has an invalid nightly price.')
    return total, int(total * 100)


def stats_for(prices):
    prices = sorted(p for p in prices if p and p > 0)
    if not prices:
        return None
    return {
        'count': len(prices),
        'min': round(prices[0], 2),
        'max': round(prices[-1], 2),
        'mean': round(statistics.fmean(prices), 2),
        'median': round(statistics.median(prices), 2),
    }


def market_comparison(hotel, price=None):
    """Compare a property's nightly price with similar approved listings."""
    prices = effective_prices([hotel])
    price = price if price is not None else prices.get(hotel.id, 0)
    if not price or price <= 0:
        return {'ok': False, 'reason': 'no_price', 'message': 'This property has no nightly price yet.'}

    def comparables(where):
        q = supabase.table('hotels').select('*').eq('review_status', 'approved').eq('property_type', hotel.property_type)
        for col, val in where:
            q = q.eq(col, val)
        rows = [Hotel(r) for r in (q.execute().data or []) if r['id'] != hotel.id]
        return rows

    scope = 'city'
    peers = comparables([('city', hotel.city)]) if getattr(hotel, 'city', None) else []
    if len(peers) < 3 and getattr(hotel, 'country', None):
        scope = 'country'
        peers = comparables([('country', hotel.country)])
    peer_prices = list(effective_prices(peers).values())
    st = stats_for(peer_prices)
    if not st or st['count'] < 3:
        return {'ok': True, 'enough_data': False, 'price': round(price, 2), 'currency': CURRENCY,
                'message': 'Not enough similar listings yet to judge this price.'}
    median = st['median']
    below = sum(1 for p in peer_prices if p and p < price)
    percentile = round(100 * below / st['count'])
    if price <= median * 0.85:
        verdict = 'below_market'
    elif price >= median * 1.15:
        verdict = 'above_market'
    else:
        verdict = 'in_line'
    return {
        'ok': True, 'enough_data': True, 'price': round(price, 2), 'currency': CURRENCY,
        'scope': scope, 'property_type': hotel.property_type,
        'place': hotel.city if scope == 'city' else hotel.country,
        'market': st, 'verdict': verdict, 'percentile': percentile,
        'difference_vs_median': round(price - median, 2),
        'difference_pct': round(100 * (price - median) / median) if median else 0,
    }


def quote(hotel, nights, unit_price, unit_label=None):
    total, cents = price_total(unit_price, nights)
    return {
        'currency': CURRENCY,
        'price_per_night': round(float(unit_price), 2),
        'nights': nights,
        'total': float(total),
        'total_cents': cents,
        'unit': unit_label or ('entire property' if getattr(hotel, 'property_type', '') not in ROOM_TYPES else 'room'),
        'taxes_note': 'Price shown is what you pay at checkout; no extra platform fee is added.',
    }


# ---------------------------------------------------------------- price parsing

_CUR = r'(?:€|eur(?:os?)?|euro|лв\.?|лева|bgn|usd|\$)'
_NUM = r'(\d{1,5}(?:[.,]\d{1,2})?)'
_MAX_WORDS = (r'under|below|less than|cheaper than|max(?:imum)?|up to|no more than|not more than|at most|within|'
              r'под|до|максимум|не повече от|по-малко от|menos de|hasta|máximo|maximo|por debajo de|unter|bis|höchstens|maximal|weniger als')
_MIN_WORDS = (r'over|above|more than|at least|min(?:imum)?|from|starting at|'
              r'над|поне|минимум|повече от|más de|mas de|al menos|mínimo|minimo|über|ueber|mindestens|ab|mehr als')


def _num(s):
    return float(s.replace(',', '.'))


def parse_price_constraints(text):
    """Extract {'min': float|None, 'max': float|None} price per night from text.

    Handles "under 100", "до 100 евро", "between 50 and 120", "50-120 eur",
    "over 200", "€150". Day numbers in dates and "2 guests / 5 stars / 3 nights"
    are ignored."""
    m = (text or '').lower()
    # remove things that look like numbers but are not prices
    m = re.sub(r'\d{4}-\d{2}-\d{2}', ' ', m)
    m = re.sub(r'\d{1,2}[./]\d{1,2}[./]\d{2,4}', ' ', m)
    m = re.sub(r'\d+\s*(?:-|\s)?\s*(?:stars?|star|звезд\w*|estrellas?|sterne?|nights?|нощ\w*|noches?|nächte|guests?|people|persons?|adults?|гост\w*|души|човека|personas?|gäste|rooms?|bedrooms?|стаи|спални)\b', ' ', m)
    m = re.sub(rf'\b\d{{1,2}}(?:st|nd|rd|th)?\s*(?:{"|".join(["january","february","march","april","may","june","july","august","september","october","november","december","януари","февруари","март","април","май","юни","юли","август","септември","октомври","ноември","декември"])})', ' ', m)

    lo = hi = None
    # explicit range
    rng = re.search(
        rf'(?:between|from|от|между|entre|zwischen|de|von)?\s*{_NUM}\s*{_CUR}?\s*(?:-|–|—|to|and|и|до|a|y|und|bis)\s*{_NUM}\s*({_CUR})?', m)
    if rng:
        a, b, cur = _num(rng.group(1)), _num(rng.group(2)), rng.group(3)
        has_marker = bool(cur) or re.search(r'between|между|entre|zwischen', m) or max(a, b) > 31
        if has_marker and a <= b and a > 0:
            lo, hi = a, b
    if lo is None:
        mx = re.search(rf'(?:{_MAX_WORDS})\s*(?:€|\$)?\s*{_NUM}', m)
        if mx:
            hi = _num(mx.group(1))
        mn = re.search(rf'(?:{_MIN_WORDS})\s*(?:€|\$)?\s*{_NUM}\s*{_CUR}?', m)
        if mn:
            val = _num(mn.group(1))
            # "from 12 to 14" would be dates; require a currency marker or a plausible price
            if val > 31 or re.search(rf'{_NUM}\s*{_CUR}', mn.group(0)):
                lo = val
        if hi is None and lo is None:
            bare = re.search(rf'(?:€\s*{_NUM})|(?:{_NUM}\s*{_CUR})', m)
            if bare:
                hi = _num(bare.group(1) or bare.group(2))
    return {'min': lo, 'max': hi}
