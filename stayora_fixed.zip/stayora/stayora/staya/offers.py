"""Price offers: guest proposes a nightly price, the owner accepts, declines or
counters, and an accepted offer can be booked at the agreed price.

Every offer is checked by the verification agent before it reaches the owner,
and the whole negotiation is visible in the guest <-> owner chat thread."""
from datetime import datetime, timedelta, timezone

from models import Hotel, _parse_dt

from . import availability, messaging, verification
from .db import db
from .errors import ActionError

OFFER_TTL = timedelta(hours=48)
OPEN = ('pending', 'countered', 'accepted')


def _now():
    return datetime.now(timezone.utc)


def _iso(dt=None):
    return (dt or _now()).isoformat()


def _first(res):
    return res.data[0] if res.data else None


def agreed_price(offer):
    """Nightly price the guest will pay if they book this (accepted) offer."""
    if offer.get('counter_price') is not None and offer.get('status') in ('accepted', 'booked'):
        return float(offer['counter_price'])
    return float(offer['offered_price'])


def get_offer(offer_id):
    try:
        offer_id = int(offer_id)
    except (TypeError, ValueError):
        return None
    row = _first(db().table('offers').select('*').eq('id', offer_id).execute())
    return _expire_if_needed(row) if row else None


def _expire_if_needed(row):
    if row['status'] in OPEN:
        try:
            if _parse_dt(row['expires_at']) < _now():
                db().table('offers').update({'status': 'expired', 'updated_at': _iso()}).eq('id', row['id']).execute()
                row = dict(row, status='expired')
        except Exception:
            pass
    return row


def offer_for_user(user, offer_id):
    row = get_offer(offer_id)
    if not row or user.id not in (row['guest_id'], row['owner_id']):
        raise ActionError('not_found', 'Offer not found.')
    return row


def _set_status(offer_id, status, **extra):
    data = {'status': status, 'updated_at': _iso()}
    data.update(extra)
    db().table('offers').update(data).eq('id', offer_id).execute()


def describe(offer):
    start = availability.to_date(offer['check_in'])
    end = start + timedelta(days=int(offer['nights']))
    return (f"€{float(offer['offered_price']):g}/night for {offer['nights']} night(s), "
            f"{start.isoformat()} to {end.isoformat()} (listed €{float(offer['list_price']):g}/night)")


def public_view(offer, viewer):
    """Offer as shown in the UI / chat (never leaks anything about third parties)."""
    start = availability.to_date(offer['check_in'])
    end = start + timedelta(days=int(offer['nights']))
    return {
        'id': offer['id'], 'property_id': offer['property_id'], 'room_id': offer.get('room_id'),
        'status': offer['status'], 'check_in': start.isoformat(), 'check_out': end.isoformat(),
        'nights': offer['nights'], 'list_price': float(offer['list_price']),
        'offered_price': float(offer['offered_price']),
        'counter_price': float(offer['counter_price']) if offer.get('counter_price') is not None else None,
        'agreed_price': agreed_price(offer) if offer['status'] in ('accepted', 'booked') else None,
        'expires_at': offer.get('expires_at'), 'conversation_id': offer.get('conversation_id'),
        'i_am_owner': viewer.id == offer['owner_id'], 'i_am_guest': viewer.id == offer['guest_id'],
        'message': offer.get('message'),
    }


def create_offer(user, hotel_id, check_in, check_out=None, nights=None, price_per_night=None, room_id=None,
                 message=None, today=None):
    verdict = verification.verify_offer(user, hotel_id, check_in, check_out, nights, price_per_night,
                                        room_id=room_id, message=message, today=today)
    if not verdict['valid']:
        first = verdict['issues'][0]
        raise ActionError('invalid_offer', first['message'], issues=verdict['issues'])
    hotel = Hotel.get(hotel_id)
    conv = messaging.get_or_create_conversation(user, hotel)
    row = {
        'property_id': hotel.id, 'room_id': verdict['room_id'], 'guest_id': user.id, 'owner_id': hotel.owner_id,
        'conversation_id': conv['id'], 'check_in': verdict['check_in'], 'nights': verdict['nights'],
        'list_price': verdict['list_price'], 'offered_price': verdict['offered_price'],
        'message': verdict['message'] or None, 'status': 'pending',
        'expires_at': _iso(_now() + OFFER_TTL), 'created_at': _iso(), 'updated_at': _iso(),
    }
    saved = db().table('offers').insert(row).execute().data[0]
    body = f"Price offer: {describe(saved)}."
    if verdict['message']:
        body += f"\n{verdict['message']}"
    messaging.post(conv, user.id, body, kind='offer', offer_id=saved['id'])
    return saved


def owner_respond(user, offer_id, action, counter_price=None, today=None):
    offer = offer_for_user(user, offer_id)
    if user.id != offer['owner_id']:
        raise ActionError('forbidden', 'Only the property owner can answer an offer.')
    if offer['status'] != 'pending':
        raise ActionError('not_open', f"This offer is already {offer['status']}.")
    conv = messaging.get_conversation(offer['conversation_id']) if offer.get('conversation_id') else None

    if action == 'accept':
        start = availability.to_date(offer['check_in'])
        end = start + timedelta(days=int(offer['nights']))
        report = availability.check_availability(offer['property_id'], start.isoformat(), end.isoformat(),
                                                 room_id=offer.get('room_id'), alternatives=False, today=today)
        if not report['available']:
            raise ActionError('unavailable', 'Those dates are no longer free, so the offer cannot be accepted.')
        _set_status(offer['id'], 'accepted', expires_at=_iso(_now() + OFFER_TTL))
        text = (f"Offer accepted at €{float(offer['offered_price']):g}/night. The guest can now book at this price "
                f"within 48 hours (first confirmed booking wins the dates).")
    elif action == 'decline':
        _set_status(offer['id'], 'declined')
        text = 'Offer declined.'
    elif action == 'counter':
        try:
            price = round(float(counter_price), 2)
        except (TypeError, ValueError):
            raise ActionError('bad_price', 'Enter the nightly price you want to counter with.') from None
        if not (float(offer['offered_price']) < price < float(offer['list_price'])):
            raise ActionError('bad_price', f"A counter offer must be above €{float(offer['offered_price']):g} "
                                           f"and below the listed €{float(offer['list_price']):g}.")
        _set_status(offer['id'], 'countered', counter_price=price, expires_at=_iso(_now() + OFFER_TTL))
        text = f'Counter offer: €{price:g}/night. The guest can accept or decline it.'
    else:
        raise ActionError('bad_action', 'Unknown action.')
    if conv:
        messaging.post(conv, user.id, text, kind='system', offer_id=offer['id'], unread_for='guest')
    return get_offer(offer['id'])


def guest_respond(user, offer_id, action):
    offer = offer_for_user(user, offer_id)
    if user.id != offer['guest_id']:
        raise ActionError('forbidden', 'Only the guest who made the offer can do this.')
    conv = messaging.get_conversation(offer['conversation_id']) if offer.get('conversation_id') else None
    status = offer['status']
    if action == 'accept_counter':
        if status != 'countered':
            raise ActionError('not_open', 'There is no counter offer to accept.')
        _set_status(offer['id'], 'accepted', expires_at=_iso(_now() + OFFER_TTL))
        text = f"Counter offer accepted at €{float(offer['counter_price']):g}/night. Booking is open for 48 hours."
    elif action == 'decline_counter':
        if status != 'countered':
            raise ActionError('not_open', 'There is no counter offer to decline.')
        _set_status(offer['id'], 'declined')
        text = 'Counter offer declined.'
    elif action == 'withdraw':
        if status not in ('pending', 'countered', 'accepted'):
            raise ActionError('not_open', f'This offer is already {status}.')
        _set_status(offer['id'], 'withdrawn')
        text = 'Offer withdrawn by the guest.'
    else:
        raise ActionError('bad_action', 'Unknown action.')
    if conv:
        messaging.post(conv, user.id, text, kind='system', offer_id=offer['id'], unread_for='owner')
    return get_offer(offer['id'])


def list_offers(user, limit=30):
    rows = (db().table('offers').select('*')
            .or_(f'guest_id.eq.{int(user.id)},owner_id.eq.{int(user.id)}')
            .order('id', desc=True).limit(limit).execute().data or [])
    return [public_view(_expire_if_needed(r), user) for r in rows]


def validate_for_booking(user, offer_id, property_id, room_id, start, nights):
    """Return the accepted offer row if it can be used for this exact booking."""
    offer = get_offer(offer_id)
    if not offer or offer['guest_id'] != user.id:
        raise ActionError('offer_invalid', 'That offer is not available for your account.')
    if offer['status'] != 'accepted':
        raise ActionError('offer_not_accepted', 'That offer has not been accepted (or has expired).')
    if offer['property_id'] != property_id:
        raise ActionError('offer_invalid', 'That offer is for a different property.')
    if offer.get('room_id') and room_id and offer['room_id'] != room_id:
        raise ActionError('offer_invalid', 'That offer is for a different room.')
    if availability.to_date(offer['check_in']) != start or int(offer['nights']) != int(nights):
        raise ActionError('offer_invalid', 'The dates must match the accepted offer.')
    return offer


def mark_booked(offer_id):
    try:
        _set_status(offer_id, 'booked')
    except Exception:
        pass
