class ActionError(Exception):
    """A problem that can be shown to the person using the chat or the site.

    `code` is machine readable (tests / UI), `message` is user-facing."""

    def __init__(self, code, message, **extra):
        super().__init__(message)
        self.code = code
        self.message = message
        self.extra = extra

    def as_dict(self):
        out = {'ok': False, 'error': self.code, 'message': self.message}
        out.update(self.extra)
        return out
