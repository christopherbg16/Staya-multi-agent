"""Plain-language replies for tool results (used by the rule router and as the
fallback when the language model is unavailable). English and Bulgarian; other
languages fall back to English (the language model answers in the user's own
language when it is enabled)."""

T = {
    'en': {
        'avail_yes': '{name} is free from {ci} to {co} ({n} night(s)). From €{ppn:g}/night, €{total:g} in total.',
        'avail_rooms': ' {free} of {all} rooms are free.',
        'avail_no': 'Sorry, {name} is already booked for {ci} to {co}.',
        'avail_alts': ' Nearby dates that are free: {alts}.',
        'avail_none_alt': ' I could not find free dates of that length in the next 4 months.',
        'not_approved': 'That listing is not open for booking right now.',
        'owner': 'That is your own property.',
        'too_many_guests': 'It sleeps up to {max_guests} guests, so it does not fit your group.',
        'no_price': 'That property has no bookable price yet.',
        'search_found': 'I found {k} free option(s) for {ci} to {co}. Cheapest: {name} at €{ppn:g}/night.',
        'search_none': 'I could not find anything free that matches. Try other dates or a higher budget.',
        'search_price': 'Here are {k} option(s) by price. Cheapest: {name} at €{ppn:g}/night.',
        'search_price_none': 'No properties match that price range.',
        'price_total': '{name}: €{ppn:g}/night, €{total:g} for {n} night(s).',
        'price_only': '{name}: from €{ppn:g}/night.',
        'market_below': ' That is {pct}% below the typical {ptype} price in {place} (median €{median:g}).',
        'market_above': ' That is {pct}% above the typical {ptype} price in {place} (median €{median:g}).',
        'market_in_line': ' That is in line with similar {ptype}s in {place} (median €{median:g}).',
        'market_unknown': ' There are not enough similar listings yet to judge the price.',
        'trust_head': '{headline}',
        'trust_limit': ' {limits}',
        'offer_ok': 'Your offer of €{offered:g}/night passes the checks (listed price €{list:g}).',
        'offer_bad': 'The offer cannot be sent: {reason}',
        'confirm_booking': 'Please check the booking and press Confirm: {name}, {ci} to {co}, €{total:g} in total.',
        'confirm_offer': 'Ready to send your offer of €{offered:g}/night to the owner. Press Confirm to send it.',
        'confirm_review': 'Here is your review ({rating}/5). Press Confirm to publish it.',
        'confirm_message': 'Here is the message for the owner. Press Confirm to send it.',
        'confirm_cancel': 'Cancel the stay at {name} ({ci} to {co})? {terms}',
        'bookings_none': 'You have no bookings yet.',
        'bookings_some': 'You have {k} booking(s). The latest ones are below.',
        'offers_none': 'You have no offers yet.',
        'offers_some': 'You have {k} offer(s); the status of each is below.',
        'messages_none': 'You have no conversations yet.',
        'messages_some': 'You have {k} conversation(s), {u} with new messages.',
        'reviews_none': 'There are no reviews for {name} yet.',
        'reviews_some': '{name} has {count} review(s), average {avg:g}/5.',
        'saved_none': 'You have not saved any properties yet. Tap the heart on a property page to save it.',
        'saved_some': 'Of your {k} saved properties, {a} are free for {ci} to {co}.',
        'login': 'Please log in first, then ask me again.',
        'ask_dates': 'Which dates? For example "12-14 December".',
        'ask_property': 'Which property do you mean? Open its page, or tell me its name.',
        'ask_price': 'What nightly price (in euro) would you like to offer?',
        'ask_text': 'What would you like to tell the owner?',
        'ask_review': 'Tell me your rating from 1 to 5 and a few words about your stay.',
        'error': 'Sorry, I could not do that: {message}',
        'status': {'pending': 'waiting for the owner', 'countered': 'countered', 'accepted': 'accepted',
                   'declined': 'declined', 'withdrawn': 'withdrawn', 'expired': 'expired', 'booked': 'booked'},
    },
    'bg': {
        'avail_yes': '{name} е свободен от {ci} до {co} ({n} нощувки). От €{ppn:g}/нощ, общо €{total:g}.',
        'avail_rooms': ' Свободни са {free} от {all} стаи.',
        'avail_no': 'Съжалявам, {name} е зает за {ci} – {co}.',
        'avail_alts': ' Близки свободни дати: {alts}.',
        'avail_none_alt': ' Не намерих свободни дати със същата продължителност през следващите 4 месеца.',
        'not_approved': 'Тази обява в момента не е отворена за резервации.',
        'owner': 'Това е вашият собствен имот.',
        'too_many_guests': 'Побира до {max_guests} гости, затова не е подходящ за вашата група.',
        'no_price': 'Този имот още няма цена за резервация.',
        'search_found': 'Намерих {k} свободни варианта за {ci} – {co}. Най-евтин: {name} за €{ppn:g}/нощ.',
        'search_none': 'Не намерих свободни имоти по тези критерии. Опитайте други дати или по-голям бюджет.',
        'search_price': 'Ето {k} варианта по цена. Най-евтин: {name} за €{ppn:g}/нощ.',
        'search_price_none': 'Няма имоти в този ценови диапазон.',
        'price_total': '{name}: €{ppn:g}/нощ, общо €{total:g} за {n} нощувки.',
        'price_only': '{name}: от €{ppn:g}/нощ.',
        'market_below': ' Това е с {pct}% под типичната цена за {ptype} в {place} (медиана €{median:g}).',
        'market_above': ' Това е с {pct}% над типичната цена за {ptype} в {place} (медиана €{median:g}).',
        'market_in_line': ' Това е в рамките на цените на подобни имоти в {place} (медиана €{median:g}).',
        'market_unknown': ' Още няма достатъчно подобни обяви, за да оценя цената.',
        'trust_head': '{headline}',
        'trust_limit': ' {limits}',
        'offer_ok': 'Офертата ви от €{offered:g}/нощ преминава проверките (обявена цена €{list:g}).',
        'offer_bad': 'Офертата не може да бъде изпратена: {reason}',
        'confirm_booking': 'Проверете резервацията и натиснете Потвърди: {name}, {ci} – {co}, общо €{total:g}.',
        'confirm_offer': 'Готова съм да изпратя офертата ви от €{offered:g}/нощ до собственика. Натиснете Потвърди.',
        'confirm_review': 'Ето вашия отзив ({rating}/5). Натиснете Потвърди, за да се публикува.',
        'confirm_message': 'Ето съобщението до собственика. Натиснете Потвърди, за да го изпратя.',
        'confirm_cancel': 'Да анулирам ли престоя в {name} ({ci} – {co})? {terms}',
        'bookings_none': 'Все още нямате резервации.',
        'bookings_some': 'Имате {k} резервации. Последните са по-долу.',
        'offers_none': 'Все още нямате оферти.',
        'offers_some': 'Имате {k} оферти; състоянието на всяка е по-долу.',
        'messages_none': 'Все още нямате разговори.',
        'messages_some': 'Имате {k} разговора, {u} с нови съобщения.',
        'reviews_none': 'За {name} още няма отзиви.',
        'reviews_some': '{name} има {count} отзива, средна оценка {avg:g}/5.',
        'saved_none': 'Още нямате запазени имоти. Натиснете сърцето на страницата на имот, за да го запазите.',
        'saved_some': 'От {k} запазени имота {a} са свободни за {ci} – {co}.',
        'login': 'Моля, влезте в профила си и ме попитайте отново.',
        'ask_dates': 'Кои дати? Например „12-14 декември“.',
        'ask_property': 'Кой имот имате предвид? Отворете страницата му или ми кажете името му.',
        'ask_price': 'Каква цена на нощ (в евро) искате да предложите?',
        'ask_text': 'Какво искате да кажете на собственика?',
        'ask_review': 'Кажете ми оценка от 1 до 5 и няколко думи за престоя.',
        'error': 'Съжалявам, не успях: {message}',
        'status': {'pending': 'чака собственика', 'countered': 'има насрещно предложение', 'accepted': 'приета',
                   'declined': 'отказана', 'withdrawn': 'оттеглена', 'expired': 'изтекла', 'booked': 'резервирана'},
    },
}

ASK_KEYS = {'need_dates': 'ask_dates', 'need_property': 'ask_property', 'need_price': 'ask_price',
            'need_text': 'ask_text', 'need_review': 'ask_review', 'login_required': 'login'}


def tr(lang, key, **kw):
    table = T.get(lang) or T['en']
    template = table.get(key) or T['en'][key]
    return template.format(**kw) if kw else template


def _market_sentence(lang, market):
    if not market or not market.get('ok'):
        return ''
    if not market.get('enough_data'):
        return tr(lang, 'market_unknown')
    key = {'below_market': 'market_below', 'above_market': 'market_above'}.get(market['verdict'], 'market_in_line')
    return tr(lang, key, pct=abs(market['difference_pct']), ptype=market['property_type'], place=market['place'],
              median=market['market']['median'])


def render(result, lang='en'):
    """Text for one tool result."""
    if not result.get('ok', True) and result.get('card_type') != 'offer_check':
        code = result.get('error')
        if code in ASK_KEYS:
            return tr(lang, ASK_KEYS[code])
        return tr(lang, 'error', message=result.get('message', ''))
    card = result.get('card_type')
    if result.get('needs_confirmation'):
        s, kind = result['summary'], result['kind']
        if kind == 'booking':
            return tr(lang, 'confirm_booking', name=s['property']['name'], ci=s['check_in'], co=s['check_out'],
                      total=s['total'])
        if kind == 'offer':
            return tr(lang, 'confirm_offer', offered=s['offered_price'])
        if kind == 'review':
            return tr(lang, 'confirm_review', rating=s['rating'])
        if kind == 'message':
            return tr(lang, 'confirm_message')
        if kind == 'cancel':
            return tr(lang, 'confirm_cancel', name=s['property'], ci=s['check_in'], co=s['check_out'],
                      terms=s['terms'])
    if card == 'availability':
        p = result['property']
        if result['available']:
            text = tr(lang, 'avail_yes', name=p['name'], ci=result['check_in'], co=result['check_out'],
                      n=result['nights'], ppn=result['from_price'], total=result['total_from'])
            if result['mode'] == 'rooms' and result['rooms_total'] > 1:
                text += tr(lang, 'avail_rooms', free=result['rooms_free'], all=result['rooms_total'])
            return text
        reason = result['reason']
        if reason == 'fully_booked':
            text = tr(lang, 'avail_no', name=p['name'], ci=result['check_in'], co=result['check_out'])
            alts = result.get('alternatives') or []
            if alts:
                text += tr(lang, 'avail_alts', alts='; '.join(
                    f"{a['check_in']} – {a['check_out']} (€{a['price_per_night']:g}/night)" for a in alts))
            else:
                text += tr(lang, 'avail_none_alt')
            return text
        return tr(lang, reason, **({'max_guests': result.get('max_guests')} if reason == 'too_many_guests' else {}))
    if card == 'search_results':
        options = result.get('options') or []
        if result.get('check_in'):
            if not options:
                return tr(lang, 'search_none')
            first = options[0]
            return tr(lang, 'search_found', k=result['total_available'], ci=result['check_in'],
                      co=result['check_out'], name=first['name'], ppn=first['price_per_night'])
        if not options:
            return tr(lang, 'search_price_none')
        first = options[0]
        return tr(lang, 'search_price', k=result['total_available'], name=first['name'],
                  ppn=first['price_per_night'] or 0)
    if card == 'price':
        name = result['property']['name']
        if result.get('total') is not None:
            text = tr(lang, 'price_total', name=name, ppn=result['price_per_night'], total=result['total'],
                      n=result['nights'])
        elif result.get('price_per_night'):
            text = tr(lang, 'price_only', name=name, ppn=result['price_per_night'])
        else:
            return tr(lang, 'no_price')
        return text + _market_sentence(lang, result.get('market'))
    if card == 'market':
        return result['property']['name'] + ':' + (_market_sentence(lang, result) or tr(lang, 'no_price'))
    if card == 'trust':
        checks = '; '.join(f"{c['name']}: {c['status'].replace('_', ' ')}" for c in result['checks'])
        return tr(lang, 'trust_head', headline=result['headline']) + f' ({checks}).' + tr(lang, 'trust_limit',
                                                                                          limits=result['limits'])
    if card == 'offer_check':
        if result.get('valid'):
            return tr(lang, 'offer_ok', offered=result['offered_price'], list=result['list_price'])
        return tr(lang, 'offer_bad', reason=result['issues'][0]['message'] if result.get('issues') else '')
    if card == 'bookings':
        rows = result.get('bookings') or []
        if result.get('message') and rows:
            return result['message']
        return tr(lang, 'bookings_some', k=result['count']) if rows else tr(lang, 'bookings_none')
    if card == 'offers':
        rows = result.get('offers') or []
        return tr(lang, 'offers_some', k=len(rows)) if rows else tr(lang, 'offers_none')
    if card == 'messages':
        rows = result.get('conversations') or []
        return tr(lang, 'messages_some', k=len(rows), u=result['unread']) if rows else tr(lang, 'messages_none')
    if card == 'reviews':
        if not result['count']:
            return tr(lang, 'reviews_none', name=result['property']['name'])
        return tr(lang, 'reviews_some', name=result['property']['name'], count=result['count'], avg=result['avg_rating'])
    if card == 'saved':
        if not result.get('saved'):
            return tr(lang, 'saved_none')
        return tr(lang, 'saved_some', k=result['saved'], a=result['available_count'], ci=result['check_in'],
                  co=result['check_out'])
    if card == 'review_check':
        return result.get('message', '')
    return result.get('message') or 'OK'
