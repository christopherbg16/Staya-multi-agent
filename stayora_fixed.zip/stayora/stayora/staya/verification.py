"""Verification agent logic.

1. Listing trust report - what Staya's automated checks did (and did not) prove.
2. Re-running the checks for an owner.
3. Offer verification - is a guest's price offer realistic, available and safe?
"""
import os
from datetime import datetime, timedelta, timezone

from models import Hotel, supabase

from . import availability, pricing
from .content_filter import explain, screen_text
from .db import db
from .errors import ActionError

MIN_OFFER_RATIO = float(os.environ.get('STAYA_MIN_OFFER_RATIO', '0.6'))
MAX_OPEN_OFFERS = 5
OPEN_OFFER_STATUSES = ('pending', 'countered', 'accepted')

LIMITS = ('Staya checks the listing text and photos for unsafe content and matches the name and '
          'address with Google Places. This does not prove ownership or where the photos were taken.')


def _checks_from(moderation_status, review_status):
    ms = moderation_status or 'not_checked'
    c = {'content': {'name': 'Content check (text and photos)', 'status': 'not_run'},
         'address': {'name': 'Address check (Google Places)', 'status': 'not_run'}}
    if ms == 'clear':
        c['content']['status'] = c['address']['status'] = 'passed'
    elif ms == 'flagged':
        c['content']['status'] = 'failed'
    elif ms in ('incomplete', 'not_found', 'mismatch'):
        c['content']['status'] = 'passed'
        c['address']['status'] = 'failed'
    elif ms == 'unavailable':
        pass
    elif ms == 'not_checked' and review_status == 'approved':
        c['content']['status'] = c['address']['status'] = 'legacy'
    return list(c.values())


def trust_report_for(hotel):
    review_status = getattr(hotel, 'review_status', None) or 'pending'
    moderation = getattr(hotel, 'moderation_status', None) or 'not_checked'
    if review_status == 'approved' and moderation == 'clear':
        level, headline = 'verified', 'Verified by Staya: content and address checks passed.'
    elif review_status == 'approved':
        level, headline = 'legacy', 'Listed before automated checks existed (not re-verified).'
    elif review_status == 'rejected':
        level, headline = 'rejected', 'This listing did not pass Staya\'s checks.'
    elif review_status == 'action_required':
        level, headline = 'action_required', 'The owner still has to fix something before this can be listed.'
    else:
        level, headline = 'pending', 'This listing is waiting for Staya\'s checks.'
    return {
        'ok': True,
        'property': {'id': hotel.id, 'name': getattr(hotel, 'name', ''), 'city': getattr(hotel, 'city', ''),
                     'country': getattr(hotel, 'country', ''), 'property_type': getattr(hotel, 'property_type', '')},
        'level': level, 'verified': level == 'verified', 'bookable': review_status == 'approved',
        'headline': headline, 'checks': _checks_from(moderation, review_status),
        'notes': getattr(hotel, 'moderation_notes', None),
        'last_checked': getattr(hotel, 'submitted_at', None),
        'review_count': getattr(hotel, 'review_count', 0) or 0,
        'avg_rating': float(getattr(hotel, 'avg_rating', 0) or 0),
        'payments': {'card': bool(getattr(hotel, 'accept_online_payments', 0)), 'cash': True},
        'limits': LIMITS,
    }


def property_trust_report(hotel_id, viewer=None):
    hotel = Hotel.get(hotel_id)
    if not hotel:
        raise ActionError('not_found', 'I could not find that property.')
    is_owner = viewer is not None and getattr(hotel, 'owner_id', None) == getattr(viewer, 'id', None)
    if getattr(hotel, 'review_status', None) != 'approved' and not is_owner:
        raise ActionError('not_found', 'I could not find that property.')
    return trust_report_for(hotel)


def reverify_property(user, hotel_id, consent):
    """Owner re-runs Staya's automated checks (needs Gemini + Google Places keys)."""
    hotel = Hotel.find_by_id_and_owner(hotel_id, user.id)
    if not hotel:
        raise ActionError('forbidden', 'You can only re-verify your own properties.')
    if not consent:
        raise ActionError('consent_required',
                          'To run the checks, your listing text/photos are sent to Gemini and the name/address to '
                          'Google Places. Please confirm you agree.')
    from property_moderation import prepare_stored_property_images, review_property_submission
    stored = [hotel.main_image] + [getattr(i, 'image_data', None) for i in hotel.images]
    try:
        images = prepare_stored_property_images(stored)
    except ValueError as exc:
        raise ActionError('bad_images', str(exc)) from exc
    if not images:
        raise ActionError('no_images', 'Add at least one photo before running the checks.')
    result = review_property_submission(hotel.name, getattr(hotel, 'description', '') or '', hotel.property_type,
                                        getattr(hotel, 'address', '') or '', hotel.city, hotel.country, images)
    hotel.update(review_status=result['review_status'], moderation_status=result['moderation_status'],
                 moderation_notes=result['summary'], submitted_at=datetime.now(timezone.utc).isoformat())
    return trust_report_for(hotel)


# --------------------------------------------------------------- offers

def _issue(code, message):
    return {'code': code, 'message': message}


def verify_offer(user, hotel_id, check_in, check_out=None, nights=None, price_per_night=None,
                 room_id=None, message=None, today=None):
    """Validate a guest's price offer. Never raises for 'bad offer'; returns a verdict."""
    start, end, duration = availability.parse_stay(check_in, check_out, nights, today)
    avail = availability.check_availability(hotel_id, start.isoformat(), end.isoformat(), room_id=room_id,
                                            viewer_id=getattr(user, 'id', None), today=today)
    issues, warnings = [], []

    reason = avail['reason']
    if reason == 'owner':
        issues.append(_issue('own_property', 'You cannot make an offer on your own property.'))
    elif reason == 'not_approved':
        issues.append(_issue('not_listed', 'This property is not currently listed.'))
    elif not avail['available']:
        issues.append(_issue('unavailable', 'The property is not available for those dates.'))

    try:
        offered = round(float(price_per_night), 2)
        if offered <= 0:
            raise ValueError
    except (TypeError, ValueError):
        offered = None
        issues.append(_issue('bad_price', 'Please give a nightly price above zero (in euro).'))

    unit = avail['units'][0] if avail['units'] else None
    if room_id and avail['units']:
        unit = next((u for u in avail['units'] if u['room_id'] == room_id), unit)
    list_price = unit['price_per_night'] if unit else None
    discount_pct = None
    if offered is not None and list_price:
        discount_pct = round(100 * (list_price - offered) / list_price)
        if offered >= list_price:
            issues.append(_issue('not_a_discount', f'The listed price is already €{list_price:g} per night. '
                                                   'You can simply book at that price.'))
        elif offered < list_price * MIN_OFFER_RATIO:
            floor = round(list_price * MIN_OFFER_RATIO, 2)
            issues.append(_issue('too_low', f'That is too far below the listed €{list_price:g} per night. '
                                            f'Offers need to be at least €{floor:g}.'))
        elif discount_pct >= 25:
            warnings.append('This is a big discount, so the owner may decline or counter.')

    market = None
    if unit:
        hotel = Hotel.get(hotel_id)
        if hotel:
            market = pricing.market_comparison(hotel, price=list_price)

    screened = screen_text(message or '', public=False, min_len=0, max_len=500)
    if not screened['ok']:
        issues.append(_issue('bad_text', explain(screened['issues'])))

    if getattr(user, 'id', None) is not None:
        rows = (db().table('offers').select('id,check_in,nights,status,property_id')
                .eq('guest_id', user.id).in_('status', list(OPEN_OFFER_STATUSES)).execute().data or [])
        if len(rows) >= MAX_OPEN_OFFERS:
            issues.append(_issue('too_many_open', f'You already have {MAX_OPEN_OFFERS} open offers. '
                                                  'Wait for answers or withdraw one first.'))
        for r in rows:
            if r['property_id'] != hotel_id:
                continue
            s = availability.to_date(r['check_in'])
            e = s + timedelta(days=int(r['nights'])) if s else None
            if s and e and s < end and e > start:
                issues.append(_issue('duplicate', 'You already have an open offer for this property and these dates.'))
                break

    return {
        'ok': True, 'valid': not issues, 'issues': issues, 'warnings': warnings,
        'availability': avail, 'unit': unit, 'room_id': (unit or {}).get('room_id'),
        'list_price': list_price, 'offered_price': offered, 'discount_pct': discount_pct,
        'check_in': start.isoformat(), 'check_out': end.isoformat(), 'nights': duration,
        'message': screened['text'], 'market': market,
    }
