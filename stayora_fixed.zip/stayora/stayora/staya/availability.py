"""Availability agent logic: is it free, for how much, and what else is free?

Works for both listing kinds used by Stayora:
  * rooms  - hotels / villas / resorts that rent individual rooms
  * whole  - apartments (or any listing with a nightly price and no rooms)
"""
from datetime import date, datetime, timedelta

from models import Hotel, Room, supabase, _parse_date

from . import pricing
from .errors import ActionError

MAX_NIGHTS = 365
ROOM_TYPES = pricing.ROOM_TYPES


def to_date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str) and value.strip():
        try:
            return datetime.strptime(value.strip()[:10], '%Y-%m-%d').date()
        except ValueError:
            return None
    return None


def parse_stay(check_in, check_out=None, nights=None, today=None):
    """Validate a stay and return (start, end, nights)."""
    today = today or date.today()
    start = to_date(check_in)
    if not start:
        raise ActionError('bad_dates', 'Please give me a check-in date.')
    if check_out:
        end = to_date(check_out)
        if not end:
            raise ActionError('bad_dates', 'I could not read the check-out date. Use a format like 2026-12-14.')
    elif nights:
        try:
            end = start + timedelta(days=int(nights))
        except (TypeError, ValueError):
            raise ActionError('bad_dates', 'The number of nights is not valid.') from None
    else:
        raise ActionError('bad_dates', 'Please give me a check-out date or the number of nights.')
    duration = (end - start).days
    if start < today:
        raise ActionError('past_dates', 'That check-in date is in the past. Pick a future date.')
    if duration < 1:
        raise ActionError('bad_dates', 'Check-out must be at least one night after check-in.')
    if duration > MAX_NIGHTS:
        raise ActionError('bad_dates', f'Stays are limited to {MAX_NIGHTS} nights.')
    return start, end, duration


def property_mode(hotel, rooms=None):
    """'rooms' when the guest books a room, 'whole' when they book the property."""
    if getattr(hotel, 'property_type', None) in ROOM_TYPES and rooms:
        return 'rooms'
    if (getattr(hotel, 'price_per_night', None) or 0) > 0:
        return 'whole'
    return 'none'


def _overlaps(a, b, start, end):
    return a < end and b > start


def busy_ranges(table, key, ids, start, end):
    """{id: [(start, end), ...]} reservations blocking any part of [start, end)."""
    ids = list(ids)
    out = {i: [] for i in ids}
    if not ids:
        return out
    rows = (supabase.table(table).select(f'{key},start_date,nights')
            .in_(key, ids)
            .gte('start_date', (start - timedelta(days=MAX_NIGHTS)).isoformat())
            .lt('start_date', end.isoformat())
            .execute().data or [])
    for row in rows:
        s = _parse_date(row.get('start_date'))
        if not s:
            continue
        e = s + timedelta(days=int(row.get('nights') or 0))
        if _overlaps(s, e, start, end):
            out.setdefault(row[key], []).append((s, e))
    return out


def _is_free(ranges, start, end):
    return all(not _overlaps(a, b, start, end) for a, b in ranges)


def rooms_for(hotels):
    """{hotel_id: [Room]} for room-priced hotels, one query."""
    ids = [h.id for h in hotels if getattr(h, 'property_type', None) in ROOM_TYPES]
    out = {i: [] for i in ids}
    if ids:
        for row in supabase.table('rooms').select('*').in_('hotel_id', ids).execute().data or []:
            out.setdefault(row['hotel_id'], []).append(Room(row))
    return out


def availability_for_hotels(hotels, start, end):
    """Batch availability: {hotel_id: {...}} using three queries in total."""
    hotels = list(hotels)
    rooms_by_hotel = rooms_for(hotels)
    modes = {h.id: property_mode(h, rooms_by_hotel.get(h.id)) for h in hotels}
    room_ids = [r.id for rs in rooms_by_hotel.values() for r in rs]
    whole_ids = [h.id for h in hotels if modes[h.id] == 'whole']
    busy_rooms = busy_ranges('reservations', 'room_id', room_ids, start, end)
    busy_props = busy_ranges('property_reservations', 'property_id', whole_ids, start, end)

    result = {}
    for h in hotels:
        mode = modes[h.id]
        info = {'mode': mode, 'available': False, 'price_per_night': None, 'room_id': None,
                'rooms_total': 0, 'rooms_free': 0}
        if mode == 'rooms':
            rooms = rooms_by_hotel[h.id]
            free = [r for r in rooms if r.price and _is_free(busy_rooms.get(r.id, []), start, end)]
            free.sort(key=lambda r: r.price)
            info.update(rooms_total=len(rooms), rooms_free=len(free), available=bool(free))
            if free:
                info.update(price_per_night=float(free[0].price), room_id=free[0].id)
        elif mode == 'whole':
            ok = _is_free(busy_props.get(h.id, []), start, end)
            info.update(rooms_total=1, rooms_free=1 if ok else 0, available=ok,
                        price_per_night=float(h.price_per_night) if ok else None)
        result[h.id] = info
    return result


def _property_summary(hotel):
    return {
        'id': hotel.id, 'name': getattr(hotel, 'name', ''), 'city': getattr(hotel, 'city', ''),
        'country': getattr(hotel, 'country', ''), 'property_type': getattr(hotel, 'property_type', ''),
        'stars': getattr(hotel, 'stars', 0) or 0,
    }


def check_availability(hotel_id, check_in, check_out=None, nights=None, guests=None, room_id=None,
                       viewer_id=None, today=None, alternatives=True):
    """Full availability report for one property."""
    today = today or date.today()
    start, end, duration = parse_stay(check_in, check_out, nights, today)
    hotel = Hotel.get(hotel_id)
    if not hotel:
        raise ActionError('not_found', 'I could not find that property.')

    rooms = Room.find_by_hotel(hotel.id) if getattr(hotel, 'property_type', None) in ROOM_TYPES else []
    mode = property_mode(hotel, rooms)
    report = {
        'ok': True, 'property': _property_summary(hotel), 'mode': mode,
        'check_in': start.isoformat(), 'check_out': end.isoformat(), 'nights': duration,
        'guests': guests, 'available': False, 'bookable': False, 'reason': 'fully_booked',
        'units': [], 'rooms_total': 0, 'rooms_free': 0, 'alternatives': [],
    }
    if getattr(hotel, 'review_status', None) != 'approved':
        report['reason'] = 'not_approved'
        return report
    if viewer_id is not None and getattr(hotel, 'owner_id', None) == viewer_id:
        report['reason'] = 'owner'
        return report
    if mode == 'none':
        report['reason'] = 'no_price'
        return report

    max_guests = getattr(hotel, 'max_guests', None) or 2
    if mode == 'whole' and guests and guests > max_guests:
        report['reason'] = 'too_many_guests'
        report['max_guests'] = max_guests
        return report

    if mode == 'rooms':
        pool = [r for r in rooms if (not room_id or r.id == room_id)]
        busy = busy_ranges('reservations', 'room_id', [r.id for r in pool], start, end)
        free = [r for r in pool if r.price and _is_free(busy.get(r.id, []), start, end)]
        free.sort(key=lambda r: r.price)
        report['rooms_total'], report['rooms_free'] = len(pool), len(free)
        for r in free:
            total, _ = pricing.price_total(r.price, duration)
            report['units'].append({'room_id': r.id, 'number': getattr(r, 'number', None),
                                    'beds': getattr(r, 'beds', None), 'price_per_night': float(r.price),
                                    'total': float(total)})
    else:
        busy = busy_ranges('property_reservations', 'property_id', [hotel.id], start, end)
        if _is_free(busy.get(hotel.id, []), start, end):
            total, _ = pricing.price_total(hotel.price_per_night, duration)
            report['rooms_total'] = report['rooms_free'] = 1
            report['units'].append({'room_id': None, 'number': None, 'beds': getattr(hotel, 'total_rooms', None),
                                    'price_per_night': float(hotel.price_per_night), 'total': float(total)})
        else:
            report['rooms_total'] = 1

    if report['units']:
        report['available'] = report['bookable'] = True
        report['reason'] = 'available'
        report['from_price'] = report['units'][0]['price_per_night']
        report['total_from'] = report['units'][0]['total']
    elif alternatives:
        report['alternatives'] = free_windows(hotel, rooms, mode, start, duration, today)
    return report


def free_windows(hotel, rooms, mode, start, nights, today=None, horizon=120, limit=3):
    """Nearest alternative windows of the same length where something is free."""
    today = today or date.today()
    lo = max(today, start - timedelta(days=30))
    hi = start + timedelta(days=horizon + nights)
    if mode == 'rooms':
        busy = busy_ranges('reservations', 'room_id', [r.id for r in rooms], lo, hi)
        units = [busy.get(r.id, []) for r in rooms]
        price_of = {i: float(r.price) for i, r in enumerate(rooms)}
    else:
        busy = busy_ranges('property_reservations', 'property_id', [hotel.id], lo, hi)
        units = [busy.get(hotel.id, [])]
        price_of = {0: float(getattr(hotel, 'price_per_night', 0) or 0)}

    found = []
    for offset in range(1, horizon + 1):
        for sign in (1, -1):
            s = start + timedelta(days=sign * offset)
            e = s + timedelta(days=nights)
            if s < lo or s < today:
                continue
            free_idx = [i for i, rng in enumerate(units) if _is_free(rng, s, e)]
            if not free_idx:
                continue
            if any(_overlaps(s, e, a, b) for a, b, _ in found):
                continue
            cheapest = min(price_of[i] for i in free_idx)
            found.append((s, e, cheapest))
            if len(found) >= limit:
                break
        if len(found) >= limit:
            break
    found.sort(key=lambda t: t[0])
    return [{'check_in': s.isoformat(), 'check_out': e.isoformat(), 'price_per_night': p} for s, e, p in found]


def search_available(destination=None, property_type=None, check_in=None, check_out=None, nights=None,
                     max_price=None, min_price=None, guests=None, viewer_id=None, limit=8, today=None):
    """Approved properties that are free for the stay, cheapest first."""
    start, end, duration = parse_stay(check_in, check_out, nights, today)
    hotels = Hotel.search(destination=destination or None, property_type=property_type or None)
    hotels = [h for h in hotels if getattr(h, 'owner_id', None) != viewer_id]
    info = availability_for_hotels(hotels, start, end)
    options = []
    for h in hotels:
        a = info[h.id]
        if not a['available']:
            continue
        price = a['price_per_night']
        if max_price is not None and price > max_price:
            continue
        if min_price is not None and price < min_price:
            continue
        if guests and a['mode'] == 'whole' and guests > (getattr(h, 'max_guests', None) or 2):
            continue
        total, _ = pricing.price_total(price, duration)
        row = _property_summary(h)
        row.update({'price_per_night': price, 'total': float(total), 'avg_rating': float(getattr(h, 'avg_rating', 0) or 0),
                    'review_count': getattr(h, 'review_count', 0) or 0, 'room_id': a['room_id'], 'mode': a['mode']})
        options.append(row)
    options.sort(key=lambda o: (o['price_per_night'], -o['avg_rating']))
    return {'ok': True, 'check_in': start.isoformat(), 'check_out': end.isoformat(), 'nights': duration,
            'destination': destination, 'property_type': property_type,
            'checked': len(hotels), 'options': options[:limit], 'total_available': len(options)}
