"""Natural-language stay-date extraction (en / bg / es / de).

`extract_stay("12-14 December")` -> ("2026-12-12", "2026-12-14").
Supported: ISO dates, dd.mm.yyyy, "12 Dec to 14 Dec", "12-14 December",
"December 12-14", "from the 12th to the 14th of December", "3 nights from <date>",
"tomorrow", "this/next weekend".
"""
import re
from datetime import date, timedelta

MONTHS = {
    # en
    'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6, 'july': 7,
    'august': 8, 'september': 9, 'october': 10, 'november': 11, 'december': 12,
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'jun': 6, 'jul': 7, 'aug': 8, 'sep': 9, 'sept': 9,
    'oct': 10, 'nov': 11, 'dec': 12,
    # bg
    'януари': 1, 'февруари': 2, 'март': 3, 'април': 4, 'май': 5, 'юни': 6, 'юли': 7,
    'август': 8, 'септември': 9, 'октомври': 10, 'ноември': 11, 'декември': 12,
    # es
    'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4, 'mayo': 5, 'junio': 6, 'julio': 7,
    'agosto': 8, 'septiembre': 9, 'octubre': 10, 'noviembre': 11, 'diciembre': 12,
    # de
    'januar': 1, 'februar': 2, 'märz': 3, 'juni': 6, 'juli': 7, 'oktober': 10, 'dezember': 12,
}
_MONTH_ALT = '|'.join(sorted((re.escape(m) for m in MONTHS), key=len, reverse=True))
_SEP = r'(?:to|until|till|through|thru|and|до|на|al|a|bis|-|–|—)'
_DAY = r'(\d{1,2})(?:st|nd|rd|th|\.)?'
_OF = r'(?:\s+of|\s+de)?'
_FROM = r'(?:from|from the|от|del|vom|desde)?\s*'


def _build(y, m, d):
    try:
        return date(y, m, d)
    except ValueError:
        return None


def _resolve(day, month, year, today, anchor=None):
    """Build a date; with no explicit year pick the next occurrence."""
    if year:
        return _build(year if year > 99 else 2000 + year, month, day)
    candidate = _build((anchor or today).year, month, day)
    if candidate and candidate < today and anchor is None:
        candidate = _build(today.year + 1, month, day)
    return candidate


def _norm(text):
    return re.sub(r'\s+', ' ', (text or '').lower()).strip()


def _fix_range(start, end):
    if not start or not end:
        return None, None
    if end <= start:
        try:
            end = end.replace(year=end.year + 1)
        except ValueError:
            return None, None
    return start, end


def extract_stay(text, today=None):
    """Return (check_in_iso, check_out_iso) or (None, None)."""
    today = today or date.today()
    m = _norm(text)
    if not m:
        return None, None

    # 1) two ISO dates
    iso = re.findall(r'(\d{4})-(\d{2})-(\d{2})', m)
    if len(iso) >= 2:
        a, b = _build(*map(int, iso[0])), _build(*map(int, iso[1]))
        if a and b:
            return a.isoformat(), b.isoformat()

    # 2) two numeric dates dd.mm.yyyy / dd/mm/yy
    num = re.findall(r'(?<![\d.])(\d{1,2})[./](\d{1,2})[./](\d{2,4})(?![\d])', m)
    if len(num) >= 2:
        a = _build(int(num[0][2]) if int(num[0][2]) > 99 else 2000 + int(num[0][2]), int(num[0][1]), int(num[0][0]))
        b = _build(int(num[1][2]) if int(num[1][2]) > 99 else 2000 + int(num[1][2]), int(num[1][1]), int(num[1][0]))
        if a and b:
            return a.isoformat(), b.isoformat()

    # 3) "12 december to 14 december [2026]"
    mt = re.search(rf'{_FROM}{_DAY}{_OF}\s*({_MONTH_ALT})\s*(\d{{4}})?\s*{_SEP}\s*(?:the\s+)?{_DAY}{_OF}\s*({_MONTH_ALT})\s*(\d{{4}})?', m)
    if mt:
        d1, m1, y1, d2, m2, y2 = mt.groups()
        a = _resolve(int(d1), MONTHS[m1], int(y1) if y1 else None, today)
        b = _resolve(int(d2), MONTHS[m2], int(y2) if y2 else None, today, anchor=a)
        a, b = _fix_range(a, b)
        if a:
            return a.isoformat(), b.isoformat()

    # 4) "12-14 december", "from the 12th to the 14th of december"
    mt = re.search(rf'{_FROM}(?:the\s+)?{_DAY}\s*{_SEP}\s*(?:the\s+)?{_DAY}{_OF}\s*({_MONTH_ALT})\s*(\d{{4}})?', m)
    if mt:
        d1, d2, mon, y = mt.groups()
        a = _resolve(int(d1), MONTHS[mon], int(y) if y else None, today)
        b = _resolve(int(d2), MONTHS[mon], int(y) if y else None, today, anchor=a)
        a, b = _fix_range(a, b)
        if a:
            return a.isoformat(), b.isoformat()

    # 5) "december 12-14", "dec 12 to dec 14"
    mt = re.search(rf'({_MONTH_ALT})\s*{_DAY}\s*(?:{_SEP})\s*(?:({_MONTH_ALT})\s*)?{_DAY}(?:\s*,?\s*(\d{{4}}))?', m)
    if mt:
        m1, d1, m2, d2, y = mt.groups()
        a = _resolve(int(d1), MONTHS[m1], int(y) if y else None, today)
        b = _resolve(int(d2), MONTHS[m2 or m1], int(y) if y else None, today, anchor=a)
        a, b = _fix_range(a, b)
        if a:
            return a.isoformat(), b.isoformat()

    # 6) single date + number of nights
    nights = extract_nights(m)
    if nights:
        start = None
        iso1 = re.search(r'(\d{4})-(\d{2})-(\d{2})', m)
        if iso1:
            start = _build(*map(int, iso1.groups()))
        if not start:
            n1 = re.search(r'(?<![\d.])(\d{1,2})[./](\d{1,2})[./](\d{2,4})(?!\d)', m)
            if n1:
                start = _build(int(n1.group(3)) if int(n1.group(3)) > 99 else 2000 + int(n1.group(3)), int(n1.group(2)), int(n1.group(1)))
        if not start:
            m1 = re.search(rf'{_DAY}{_OF}\s*({_MONTH_ALT})\s*(\d{{4}})?', m) or None
            if m1:
                start = _resolve(int(m1.group(1)), MONTHS[m1.group(2)], int(m1.group(3)) if m1.group(3) else None, today)
            else:
                m2 = re.search(rf'({_MONTH_ALT})\s*{_DAY}(?:\s*,?\s*(\d{{4}}))?', m)
                if m2:
                    start = _resolve(int(m2.group(2)), MONTHS[m2.group(1)], int(m2.group(3)) if m2.group(3) else None, today)
        if start:
            return start.isoformat(), (start + timedelta(days=nights)).isoformat()

    # 7) relative: tomorrow / weekend
    if re.search(r'\b(?:this|next|the coming)?\s*weekend\b|\bуикенд\b|\bfin de semana\b|\bwochenende\b', m):
        days_to_fri = (4 - today.weekday()) % 7
        if re.search(r'\bnext weekend\b|\bследващия уикенд\b', m) or (days_to_fri == 0 and False):
            days_to_fri += 7
        friday = today + timedelta(days=days_to_fri)
        return friday.isoformat(), (friday + timedelta(days=2)).isoformat()
    return None, None


def extract_nights(text):
    m = _norm(text)
    mt = re.search(r'(\d{1,3})\s*(?:nights?|нощувк\w*|нощ\w*|noches?|nächte|naechte|nacht)\b', m)
    if mt:
        n = int(mt.group(1))
        return n if 1 <= n <= 365 else None
    return None


def extract_guests(text):
    m = _norm(text)
    mt = re.search(r'(\d{1,2})\s*(?:guests?|people|persons?|adults?|гост\w*|души|човека|personas?|gäste|personen)\b', m)
    if mt:
        n = int(mt.group(1))
        return n if 1 <= n <= 30 else None
    mt = re.search(r'(?:for|за|para|für)\s+(\d{1,2})\b(?!\s*(?:nights?|нощ|noches|nächte|[./]))', m)
    if mt:
        n = int(mt.group(1))
        return n if 1 <= n <= 30 else None
    return None
