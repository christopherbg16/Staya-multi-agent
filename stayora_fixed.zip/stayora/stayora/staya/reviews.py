"""Guest reviews. Only someone who actually stayed (check-out date in the past)
can review a property, once, on a 1-5 scale."""
from datetime import date, datetime, timedelta, timezone

from models import Hotel, supabase, _parse_date

from .content_filter import explain, screen_text
from .db import db, error_code, insert_with_id
from .errors import ActionError

MIN_TEXT = 10
MAX_TEXT = 1500


def _stays(user, hotel_id):
    """All reservations of `user` at the property as [(start, end, kind, id)]."""
    who = f'user_id.eq.{int(user.id)},guest.eq.{_safe_name(user.username)}'
    out = []
    rooms = supabase.table('rooms').select('id').eq('hotel_id', hotel_id).execute().data or []
    room_ids = [r['id'] for r in rooms]
    if room_ids:
        rows = (supabase.table('reservations').select('id,start_date,nights')
                .in_('room_id', room_ids).or_(who).execute().data or [])
        for r in rows:
            s = _parse_date(r['start_date'])
            out.append((s, s + timedelta(days=int(r.get('nights') or 0)), 'room', r['id']))
    rows = (supabase.table('property_reservations').select('id,start_date,nights')
            .eq('property_id', hotel_id).or_(who).execute().data or [])
    for r in rows:
        s = _parse_date(r['start_date'])
        out.append((s, s + timedelta(days=int(r.get('nights') or 0)), 'property', r['id']))
    return out


def _safe_name(name):
    # PostgREST or_() filter values must not contain separators
    return str(name or '').replace(',', ' ').replace('(', ' ').replace(')', ' ')


def review_eligibility(user, hotel_id, today=None):
    today = today or date.today()
    hotel = Hotel.get(hotel_id)
    if not hotel or getattr(hotel, 'review_status', None) != 'approved':
        raise ActionError('not_found', 'I could not find that property.')
    if getattr(hotel, 'owner_id', None) == user.id:
        return {'eligible': False, 'reason': 'owner', 'message': 'You cannot review your own property.'}
    existing = (db().table('hotel_reviews').select('id,rating,review_text')
                .eq('hotel_id', hotel_id).eq('user_id', user.id).execute().data or [])
    if existing:
        return {'eligible': False, 'reason': 'already_reviewed', 'message': 'You already reviewed this property.',
                'review': existing[0]}
    stays = [s for s in _stays(user, hotel_id) if s[0]]
    done = [s for s in stays if s[1] <= today]
    if done:
        last = max(done, key=lambda s: s[1])
        return {'eligible': True, 'reason': 'ok', 'message': 'You can review this stay.',
                'stay': {'check_in': last[0].isoformat(), 'check_out': last[1].isoformat()}}
    if stays:
        nxt = min(stays, key=lambda s: s[1])
        return {'eligible': False, 'reason': 'stay_not_finished',
                'message': f'You can review after your stay ends on {nxt[1].isoformat()}.'}
    return {'eligible': False, 'reason': 'no_stay', 'message': 'Only guests who stayed here can leave a review.'}


def validate_review(rating, text):
    try:
        value = float(rating)
    except (TypeError, ValueError):
        raise ActionError('bad_rating', 'Please rate the stay from 1 to 5.') from None
    if value != int(value) or not 1 <= value <= 5:
        raise ActionError('bad_rating', 'Please rate the stay with a whole number from 1 to 5.')
    screened = screen_text(text, public=True, min_len=MIN_TEXT, max_len=MAX_TEXT)
    if not screened['ok']:
        if 'too_short' in screened['issues']:
            raise ActionError('bad_text', f'Please write at least {MIN_TEXT} characters about your stay.')
        raise ActionError('bad_text', explain(screened['issues']))
    return int(value), screened['text']


def recalculate_rating(hotel_id):
    rows = db().table('hotel_reviews').select('rating').eq('hotel_id', hotel_id).execute().data or []
    ratings = [float(r['rating']) for r in rows if r.get('rating') is not None]
    avg = round(sum(ratings) / len(ratings), 1) if ratings else 0.0
    supabase.table('hotels').update({'avg_rating': avg, 'review_count': len(ratings)}).eq('id', hotel_id).execute()
    return avg, len(ratings)


def submit_review(user, hotel_id, rating, text, today=None):
    elig = review_eligibility(user, hotel_id, today)
    if not elig['eligible']:
        raise ActionError(elig['reason'], elig['message'])
    rating, text = validate_review(rating, text)
    try:
        saved = insert_with_id('hotel_reviews', {
            'hotel_id': hotel_id, 'user_id': user.id, 'rating': rating, 'review_text': text,
            'created_at': datetime.now(timezone.utc).isoformat()})
    except Exception as exc:
        if error_code(exc) == '23505':
            raise ActionError('already_reviewed', 'You already reviewed this property.') from exc
        raise
    avg, count = recalculate_rating(hotel_id)
    return {'review': saved, 'avg_rating': avg, 'review_count': count}


def list_reviews(hotel_id, limit=20):
    rows = (db().table('hotel_reviews').select('*').eq('hotel_id', hotel_id)
            .order('created_at', desc=True).limit(limit).execute().data or [])
    ids = list({r['user_id'] for r in rows if r.get('user_id')})
    names = {}
    if ids:
        for u in supabase.table('users').select('id,username').in_('id', ids).execute().data or []:
            names[u['id']] = u['username']
    out = []
    for r in rows:
        created = r.get('created_at')
        try:
            created_dt = datetime.fromisoformat(str(created).replace('Z', '+00:00')) if created else None
        except ValueError:
            created_dt = None
        out.append({'id': r['id'], 'rating': float(r['rating']), 'text': r.get('review_text') or '',
                    'author': names.get(r.get('user_id')) or 'Guest', 'created_at': created_dt})
    return out


def review_summary(hotel_id, excerpts=3):
    reviews = list_reviews(hotel_id, limit=50)
    if not reviews:
        return {'ok': True, 'count': 0, 'avg_rating': 0.0, 'distribution': {}, 'excerpts': []}
    dist = {str(n): 0 for n in range(1, 6)}
    for r in reviews:
        dist[str(int(round(r['rating'])))] = dist.get(str(int(round(r['rating']))), 0) + 1
    return {'ok': True, 'count': len(reviews), 'avg_rating': round(sum(r['rating'] for r in reviews) / len(reviews), 1),
            'distribution': dist,
            'excerpts': [{'rating': r['rating'], 'author': r['author'], 'text': r['text'][:200]}
                         for r in reviews[:excerpts]]}
