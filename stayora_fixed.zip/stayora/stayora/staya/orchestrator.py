"""Staya orchestrator: one entry point for the chat widget.

Order of work for every message:
  1. rules      deterministic router (works offline, no quota)
  2. Gemini     tool-calling loop over the specialist agents' tools
  3. legacy     the original keyword chatbot (destinations, trends, theme, language ...)
The page the person is looking at is passed in as a hint and is always re-validated.
"""
import json
import logging
import sys
from collections import OrderedDict
from datetime import date

from . import responses, rules
from .agents import REGISTRY, Call, run_tool
from .context import parse_page

logger = logging.getLogger(__name__)

MAX_SESSIONS = 500
MAX_ROUNDS = 5
_sessions = OrderedDict()


def _session(key):
    if key in _sessions:
        _sessions.move_to_end(key)
    else:
        _sessions[key] = {'memory': {}, 'pending': None}
        while len(_sessions) > MAX_SESSIONS:
            _sessions.popitem(last=False)
    return _sessions[key]


def scoped_session_id(user, session_id):
    """A session never crosses accounts: the user id is part of the key."""
    uid = getattr(user, 'id', None)
    return f"u{uid}:{(session_id or 'default')[:64]}" if uid else f"g:{(session_id or 'default')[:64]}"


def _cards(results):
    """What the widget renders: only the card payloads, never internal fields."""
    out = []
    for r in results:
        if r.get('ok') is False and r.get('card_type') != 'offer_check':
            continue
        if r.get('card_type') or r.get('needs_confirmation'):
            out.append(r)
    return out


def _quick_replies(lang, page, results, has_user):
    bg = lang == 'bg'
    on_property = page.kind == 'property'
    last = results[-1] if results else {}
    if last.get('needs_confirmation'):
        return []
    if last.get('card_type') == 'availability':
        if last.get('available'):
            return ['Резервирай', 'Направи оферта', 'Провери имота'] if bg else ['Book it', 'Make an offer', 'Verify this property']
        return ['Покажи други дати', 'Търси подобни'] if bg else ['Show other dates', 'Find similar stays']
    if on_property:
        return (['Свободно ли е?', 'Колко струва?', 'Проверка на имота', 'Пиши на собственика']
                if bg else ['Is it available?', 'How much is it?', 'Verify this property', 'Message the owner'])
    if has_user:
        return (['Моите резервации', 'Моите оферти', 'Съобщения', 'Запазени имоти']
                if bg else ['My bookings', 'My offers', 'My messages', 'My saved properties'])
    return ['Търси имоти', 'Популярни дестинации'] if bg else ['Search stays', 'Popular destinations']


def _entities(message):
    try:
        import chatbot
        return chatbot._extract_entities(message.lower())
    except Exception:
        logger.debug('entity extraction failed', exc_info=True)
        return {}


def _build_response(text, results, lang, page, user, **extra):
    resp = {'text': text, 'intent': 'staya', 'cards': _cards(results),
            'quick_replies': _quick_replies(lang, page, results, user is not None)}
    for r in results:
        if r.get('needs_confirmation'):
            resp['confirmation'] = {'kind': r['kind'], 'token': r['token'], 'summary': r['summary'],
                                    'methods': r.get('methods')}
        if r.get('error') == 'login_required' and r.get('login_url'):
            resp['actions'] = [{'label': 'Log in' if lang != 'bg' else 'Вход', 'url': r['login_url'], 'primary': True}]
    resp.update(extra)
    return resp


# ------------------------------------------------------------------ Gemini

def _gemini_declarations():
    import chatbot
    from google.genai import types as gt
    tmap = {'string': gt.Type.STRING, 'number': gt.Type.NUMBER, 'integer': gt.Type.INTEGER}
    decls = []
    for t in REGISTRY.values():
        props = {n: gt.Schema(type=tmap.get(spec[0], gt.Type.STRING), description=spec[1])
                 for n, spec in t.params.items()}
        decls.append(gt.FunctionDeclaration(
            name=t.name, description=t.description,
            parameters=gt.Schema(type=gt.Type.OBJECT, properties=props, required=list(t.required))))
    legacy = chatbot._openai_to_gemini_tools()[0].function_declarations
    taken = set(REGISTRY)
    decls.extend(d for d in legacy if d.name not in taken)
    return gt, decls


def _system_prompt(lang, call):
    import chatbot
    base = chatbot._build_system_prompt(lang)
    page = call.page
    extra = f"""

STAYA AGENTS (use these tools, never guess):
- The person is looking at: {page.describe()}. When they say "this property", "it", "here", use that page (omit property_id).
- Availability and prices: ALWAYS call check_availability / get_price_quote / search_available / search_by_price; never state availability or a price from memory.
- Booking, offers, reviews, messages: call the prepare_* tool. It returns a confirmation card; the person must press Confirm. NEVER say something is booked, sent or published before they confirm.
- Reviews are only for people who completed a stay. Offers must be realistic; the verification tool checks them.
- Verification means Staya checked the content and the address. It does NOT prove ownership. Say that plainly when asked.
- If a date, price or text is missing, ask one short question. Dates today: {date.today().isoformat()}.
"""
    return base + extra


def _try_gemini(message, call, session, lang):
    try:
        import chatbot
    except Exception:
        return None
    if not getattr(chatbot, '_gemini_available', False):
        return None
    try:
        gt, decls = _gemini_declarations()
    except Exception:
        logger.debug('gemini declarations failed', exc_info=True)
        return None
    history = session.setdefault('history', [])
    contents = list(history) + [{'role': 'user', 'parts': [{'text': message}]}]
    config = gt.GenerateContentConfig(
        system_instruction=_system_prompt(lang, call), tools=[gt.Tool(function_declarations=decls)],
        temperature=0.4, max_output_tokens=800,
        thinking_config=gt.ThinkingConfig(thinking_budget=0))
    results, extra = [], {}
    for _ in range(MAX_ROUNDS):
        try:
            response = chatbot._gemini_client.models.generate_content(
                model=chatbot.GEMINI_MODEL_NAME, contents=contents, config=config)
            candidate = response.candidates[0]
            parts = list(candidate.content.parts or [])
        except Exception as exc:
            print(f'[Staya Gemini] {type(exc).__name__}: {exc}', file=sys.stderr)
            return None
        calls = [p.function_call for p in parts if getattr(p, 'function_call', None)]
        if not calls:
            text = ''.join(p.text for p in parts if getattr(p, 'text', None)).strip()
            if not text:
                return None
            history.extend([{'role': 'user', 'parts': [{'text': message}]}, {'role': 'model', 'parts': [{'text': text}]}])
            del history[:-12]
            if any(r.get('needs_confirmation') for r in results):
                # never let the model's words claim success for a pending action
                text = responses.render(next(r for r in results if r.get('needs_confirmation')), lang)
            return _build_response(text, results, lang, call.page, call.user, **extra)
        contents.append(candidate.content)
        response_parts = []
        for fc in calls:
            name, args = fc.name, dict(fc.args or {})
            if name in REGISTRY:
                result = run_tool(call, name, args)
                results.append(result)
                payload = json.loads(json.dumps(result, default=str))
            else:
                payload = _legacy_tool(name, args, extra)
            response_parts.append({'function_response': {'name': name, 'response': payload}})
        contents.append({'role': 'user', 'parts': response_parts})
    return None


def _legacy_tool(name, args, extra):
    import chatbot
    if name == 'navigate_to':
        extra['navigate'] = args.get('url', '/')
        return {'success': True, 'url': extra['navigate']}
    impl = chatbot.TOOL_IMPL.get(name)
    if not impl:
        return {'success': False, 'error': 'unknown function'}
    try:
        result = impl(**args)
    except Exception as exc:
        return {'success': False, 'error': str(exc)}
    if name == 'change_language' and result.get('success'):
        extra['navigate'], extra['language'] = result.get('redirect'), result.get('lang')
    if name == 'change_theme' and result.get('success'):
        extra['theme'] = result.get('theme')
    if name == 'rename_username':
        extra['rename_username'] = result
    if name == 'find_booking_options' and result.get('success'):
        extra['properties'] = result.get('options', [])
    return result


# ------------------------------------------------------------------ entry point

def handle(message, session_id=None, lang='en', page=None, user=None):
    message = (message or '').strip()[:1500]
    if not message:
        return {'text': '', 'intent': 'empty'}
    ctx = parse_page(page)
    key = scoped_session_id(user, session_id)
    session = _session(key)
    call = Call(user=user, page=ctx, memory=session['memory'], lang=lang, session_id=key)
    entities = _entities(message)

    decision = rules.route(message, call, entities=entities, pending=session.get('pending'))
    session['pending'] = None

    if decision and decision.get('ask'):
        session['pending'] = decision.get('pending')
        return _build_response(responses.tr(lang, responses.ASK_KEYS[decision['ask']]), [], lang, ctx, user)
    if decision and decision.get('tool'):
        result = run_tool(call, decision['tool'], decision.get('args') or {})
        if decision.get('tool') == 'prepare_offer' and result.get('error') == 'need_dates':
            session['pending'] = {'intent': 'offer', 'args': decision['args']}
        elif result.get('error') in ('need_dates',):
            intent = {'check_availability': 'availability', 'prepare_booking': 'booking',
                      'get_price_quote': 'price'}.get(decision['tool'])
            if intent:
                session['pending'] = {'intent': intent, 'args': decision.get('args') or {}}
        extra = {}
        if decision.get('cancel_flow') and result.get('ok'):
            extra['cancel_hint'] = True
        text = responses.render(result, lang)
        return _build_response(text, [result], lang, ctx, user, **extra)

    result = _try_gemini(message, call, session, lang)
    if result is not None:
        return result

    import chatbot
    legacy = chatbot._db_response(message, key, lang)
    legacy.setdefault('quick_replies', _quick_replies(lang, ctx, [], user is not None))
    legacy.setdefault('cards', [])
    return legacy
