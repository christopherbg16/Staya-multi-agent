"""Web routes for Staya: chat confirmations, page briefing, messaging, offers,
favorites and reviews. CSRF protection is global (the JS fetch wrapper in
static/js/main.js sends the token); every endpoint requires login except the
page brief, which only returns public facts for guests."""
import logging

from flask import Blueprint, abort, jsonify, redirect, render_template, request, url_for, flash
from flask_login import current_user, login_required

from . import favorites, messaging, offers, reviews
from . import agents
from .context import parse_page
from .errors import ActionError

logger = logging.getLogger(__name__)
staya_bp = Blueprint('staya', __name__)


def _err(exc, status=400):
    return jsonify({'ok': False, 'error': exc.code, 'message': exc.message, **(exc.extra or {})}), status


def _json():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def _guarded(fn):
    """JSON endpoints: ActionError -> 4xx with a readable message, never a stack trace."""
    def wrapper(*a, **kw):
        try:
            return fn(*a, **kw)
        except ActionError as exc:
            status = 404 if exc.code in ('not_found',) else 403 if exc.code in ('forbidden',) else 429 if exc.code == 'rate_limited' else 400
            return _err(exc, status)
        except Exception:
            logger.exception('Staya route %s failed', fn.__name__)
            return jsonify({'ok': False, 'error': 'internal', 'message': 'Something went wrong. Please try again.'}), 500
    wrapper.__name__ = fn.__name__
    return wrapper


# ------------------------------------------------------------ chat confirmation

@staya_bp.route('/api/staya/confirm', methods=['POST'])
@login_required
@_guarded
def confirm():
    data = _json()
    result = agents.confirm_action(current_user, str(data.get('kind') or ''), str(data.get('token') or ''),
                                   data.get('method'))
    bg = request.cookies.get('site_lang') == 'bg'
    action = result.get('action')
    if action == 'checkout':
        result['checkout_url'] = result.get('url')
    msg = {
        'booked': ('Резервацията е потвърдена. Плащане на място.', 'Booking confirmed. You pay at the property.'),
        'checkout': ('Пренасочвам ви към плащане…', 'Taking you to payment…'),
        'offer_sent': ('Офертата е изпратена до собственика.', 'Your offer was sent to the owner.'),
        'review_saved': ('Отзивът е публикуван. Благодаря!', 'Your review is published. Thank you!'),
        'message_sent': ('Съобщението е изпратено.', 'Message sent.'),
    }.get(action)
    if msg:
        result['message'] = msg[0] if bg else msg[1]
    elif action:
        result.setdefault('message', result.get('summary') or ('Готово.' if bg else 'Done.'))
    return jsonify(result)


@staya_bp.route('/api/staya/page-brief', methods=['GET'])
@_guarded
def page_brief():
    """What the agents know about the property page the person is on: availability,
    price (with market comparison), verification and reviews. Powers the Staya
    panel on the property page and the chat's contextual hints."""
    ctx = parse_page({'path': request.args.get('path', ''), 'search': request.args.get('search', '')})
    if ctx.kind != 'property' or not ctx.property_id:
        return jsonify({'ok': True, 'applicable': False})
    user = current_user if current_user.is_authenticated else None
    call = agents.Call(user=user, page=ctx, lang=request.cookies.get('site_lang', 'en'))
    out = {'ok': True, 'applicable': True, 'property_id': ctx.property_id}
    if ctx.check_in and (ctx.check_out or ctx.nights):
        out['availability'] = agents.run_tool(call, 'check_availability', {})
        out['price'] = agents.run_tool(call, 'get_price_quote', {})
    else:
        out['price'] = agents.run_tool(call, 'compare_price', {})
    out['verification'] = agents.run_tool(call, 'verify_property', {})
    out['reviews'] = agents.run_tool(call, 'get_reviews', {})
    return jsonify(out)


# ------------------------------------------------------------ messages

@staya_bp.route('/messages')
@login_required
def inbox():
    return render_template('messages/inbox.html', conversations=messaging.list_conversations(current_user))


@staya_bp.route('/messages/<int:conv_id>')
@login_required
def thread(conv_id):
    try:
        data = messaging.get_thread(current_user, conv_id)
    except ActionError:
        abort(404)
    return render_template('messages/thread.html', conversation=data['conversation'], messages=data['messages'],
                           offers_by_id={o['id']: o for o in offers.list_offers(current_user)
                                         if o.get('conversation_id') == conv_id})


@staya_bp.route('/messages/start', methods=['POST'])
@login_required
def start():
    try:
        conv, _msg = messaging.start_conversation(current_user, request.form.get('property_id', type=int),
                                                  request.form.get('body', ''))
    except ActionError as exc:
        flash(exc.message, 'error')
        return redirect(request.referrer or url_for('user.browse_stays'))
    return redirect(url_for('staya.thread', conv_id=conv['id']))


@staya_bp.route('/api/messages/<int:conv_id>/send', methods=['POST'])
@login_required
@_guarded
def send(conv_id):
    msg = messaging.send_message(current_user, conv_id, str(_json().get('body') or ''))
    return jsonify({'ok': True, 'id': msg['id']})


@staya_bp.route('/api/messages/<int:conv_id>', methods=['GET'])
@login_required
@_guarded
def poll(conv_id):
    data = messaging.get_thread(current_user, conv_id, after_id=request.args.get('after', type=int))
    return jsonify({'ok': True, **data})


@staya_bp.route('/api/messages/unread', methods=['GET'])
@login_required
def unread():
    try:
        return jsonify({'ok': True, 'unread': messaging.unread_count(current_user)})
    except Exception:
        return jsonify({'ok': True, 'unread': 0})


# ------------------------------------------------------------ offers

@staya_bp.route('/api/offers', methods=['POST'])
@login_required
@_guarded
def create_offer():
    d = _json()
    saved = offers.create_offer(current_user, int(d.get('property_id') or 0), str(d.get('check_in') or ''),
                                d.get('check_out'), d.get('nights'), float(d.get('price_per_night') or 0),
                                room_id=d.get('room_id'), message=d.get('message'))
    return jsonify({'ok': True, 'offer': offers.public_view(saved, current_user),
                    'conversation_url': url_for('staya.thread', conv_id=saved['conversation_id'])})


@staya_bp.route('/api/offers/<int:offer_id>/respond', methods=['POST'])
@login_required
@_guarded
def respond_offer(offer_id):
    d = _json()
    action = str(d.get('action') or '')
    if action in ('accept', 'decline', 'counter'):
        row = offers.owner_respond(current_user, offer_id, action, counter_price=d.get('counter_price'))
    else:
        row = offers.guest_respond(current_user, offer_id, action)
    return jsonify({'ok': True, 'offer': offers.public_view(row, current_user)})


# ------------------------------------------------------------ favorites & reviews

@staya_bp.route('/api/favorites/<int:property_id>', methods=['POST'])
@login_required
@_guarded
def toggle_favorite(property_id):
    saved = favorites.toggle(current_user, property_id, _json().get('saved'))
    return jsonify({'ok': True, 'saved': saved})


@staya_bp.route('/reviews/<int:property_id>', methods=['POST'])
@login_required
def submit_review(property_id):
    try:
        reviews.submit_review(current_user, property_id, request.form.get('rating', type=int),
                              request.form.get('text', ''))
        flash('Thank you! Your review was published.', 'success')
    except ActionError as exc:
        flash(exc.message, 'error')
    return redirect(url_for('user.hotel_detail', hotel_id=property_id) + '#reviews')
