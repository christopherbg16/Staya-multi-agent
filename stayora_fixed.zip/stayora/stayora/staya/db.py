"""Database access for the Staya agents.

Private data (messages, offers, audit log) should only be reachable with the
server-side service-role key.  When that key is not configured the regular
client is used so the project still runs in development.
"""
import os
import threading

from supabase_client import supabase, supabase_url

_service_client = None
_lock = threading.Lock()


def db():
    """Return the Supabase client to use for Staya tables."""
    global _service_client
    key = os.environ.get('SUPABASE_SERVICE_ROLE_KEY', '').strip()
    if key and supabase_url:
        with _lock:
            if _service_client is None:
                from supabase import create_client
                _service_client = create_client(supabase_url, key)
        return _service_client
    return supabase


def error_code(exc):
    """Postgres/PostgREST error code of an exception, if any (e.g. 23P01, 23505)."""
    code = getattr(exc, 'code', None)
    if code:
        return str(code)
    details = getattr(exc, 'json', None)
    if isinstance(details, dict):
        return details.get('code') or (details.get('details') or {}).get('code')
    if exc.args and isinstance(exc.args[0], dict):
        return exc.args[0].get('code')
    return None


def next_id(table, client=None):
    """max(id)+1, the same strategy the rest of the project uses for tables
    whose id has no default.  Callers should retry on a duplicate-key error."""
    client = client or db()
    rows = client.table(table).select('id').order('id', desc=True).limit(1).execute()
    return (rows.data[0]['id'] + 1) if (rows.data and rows.data[0].get('id')) else 1


def insert_with_id(table, row, client=None, attempts=4):
    """Insert a row into a table whose primary key has no default."""
    client = client or db()
    last = None
    for _ in range(attempts):
        payload = dict(row)
        payload['id'] = next_id(table, client)
        try:
            res = client.table(table).insert(payload).execute()
            return res.data[0] if res.data else payload
        except Exception as exc:  # duplicate key from a concurrent insert -> retry
            last = exc
            if error_code(exc) != '23505':
                raise
    raise last
