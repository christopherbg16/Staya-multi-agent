"""Guest <-> owner chat.

One conversation per (property, guest).  The owner is always the property's
owner, so a guest can never be paired with an arbitrary account, and only the
two participants can read or write a conversation.
"""
from datetime import datetime, timedelta, timezone

from models import Hotel, supabase, _parse_dt

from .content_filter import explain, screen_text
from .db import db
from .errors import ActionError

MAX_MESSAGE_LEN = 2000
RATE_LIMIT_COUNT = 40
RATE_LIMIT_WINDOW = timedelta(minutes=10)


def _now():
    return datetime.now(timezone.utc)


def _iso(dt=None):
    return (dt or _now()).isoformat()


def _first(res):
    return res.data[0] if res.data else None


def is_owner_account(user):
    return getattr(user, 'role', None) == 'admin'


def get_conversation(conv_id):
    return _first(db().table('staya_conversations').select('*').eq('id', conv_id).execute())


def conversation_for_user(user, conv_id):
    """Conversation row if `user` is a participant, otherwise ActionError."""
    try:
        conv_id = int(conv_id)
    except (TypeError, ValueError):
        raise ActionError('not_found', 'Conversation not found.') from None
    conv = get_conversation(conv_id)
    if not conv or user.id not in (conv['guest_id'], conv['owner_id']):
        # same answer for "missing" and "not yours": do not leak which ids exist
        raise ActionError('not_found', 'Conversation not found.')
    return conv


def get_or_create_conversation(guest, hotel, require_approved=True):
    if getattr(hotel, 'owner_id', None) is None:
        raise ActionError('no_owner', 'This property has no owner to message.')
    if guest.id == hotel.owner_id:
        raise ActionError('own_property', 'This is your own property.')
    if require_approved and getattr(hotel, 'review_status', None) != 'approved':
        raise ActionError('not_available', 'This property is not currently listed.')
    found = _first(db().table('staya_conversations').select('*')
                   .eq('property_id', hotel.id).eq('guest_id', guest.id).execute())
    if found:
        return found
    row = {'property_id': hotel.id, 'guest_id': guest.id, 'owner_id': hotel.owner_id,
           'created_at': _iso(), 'last_message_at': _iso()}
    try:
        res = db().table('staya_conversations').insert(row).execute()
        return res.data[0]
    except Exception:
        # unique (property_id, guest_id): another request created it first
        found = _first(db().table('staya_conversations').select('*')
                       .eq('property_id', hotel.id).eq('guest_id', guest.id).execute())
        if found:
            return found
        raise


def _check_rate_limit(user):
    since = _iso(_now() - RATE_LIMIT_WINDOW)
    res = (db().table('staya_messages').select('id', count='exact')
           .eq('sender_id', user.id).gte('created_at', since).execute())
    count = res.count if res.count is not None else len(res.data or [])
    if count >= RATE_LIMIT_COUNT:
        raise ActionError('rate_limited', 'You are sending messages very quickly. Please wait a few minutes.')


def post(conv, sender_id, body, kind='text', offer_id=None, unread_for='other'):
    """Insert a message and update the conversation bookkeeping.

    unread_for: 'other' (the participant who is not the sender), 'owner', 'guest' or 'both'."""
    now = _iso()
    msg = {'conversation_id': conv['id'], 'sender_id': sender_id, 'kind': kind, 'body': body[:MAX_MESSAGE_LEN],
           'offer_id': offer_id, 'created_at': now}
    res = db().table('staya_messages').insert(msg).execute()
    saved = res.data[0] if res.data else msg
    update = {'last_message_at': now, 'last_sender_id': sender_id}
    if unread_for == 'other':
        unread_for = 'owner' if sender_id == conv['guest_id'] else 'guest'
    # the side that should NOT see an unread badge is considered up to date
    if unread_for == 'owner':
        update['guest_last_read_at'] = now
    elif unread_for == 'guest':
        update['owner_last_read_at'] = now
    db().table('staya_conversations').update(update).eq('id', conv['id']).execute()
    return saved


def send_message(user, conv_id, body):
    conv = conversation_for_user(user, conv_id)
    screened = screen_text(body, public=False, max_len=MAX_MESSAGE_LEN)
    if not screened['ok']:
        raise ActionError('bad_text', explain(screened['issues']) or 'That message cannot be sent.')
    _check_rate_limit(user)
    return post(conv, user.id, screened['text'])


def start_conversation(user, property_id, body):
    """Guest writes to the owner of `property_id` (creates the thread if needed)."""
    hotel = Hotel.get(property_id)
    if not hotel:
        raise ActionError('not_found', 'I could not find that property.')
    screened = screen_text(body, public=False, max_len=MAX_MESSAGE_LEN)
    if not screened['ok']:
        raise ActionError('bad_text', explain(screened['issues']) or 'That message cannot be sent.')
    conv = get_conversation_for_property(user, hotel)
    _check_rate_limit(user)
    msg = post(conv, user.id, screened['text'])
    return conv, msg


def get_conversation_for_property(user, hotel):
    return get_or_create_conversation(user, hotel)


def notify_owner(hotel, guest, text):
    """System note in the guest<->owner thread (booking, cancellation, ...).

    Best effort: a failure here must never break a booking."""
    try:
        conv = get_or_create_conversation(guest, hotel, require_approved=False)
        post(conv, None, text, kind='system', unread_for='owner')
        return conv
    except Exception:
        return None


def _users_by_id(ids):
    ids = list({i for i in ids if i is not None})
    if not ids:
        return {}
    rows = supabase.table('users').select('id,username,profile_image').in_('id', ids).execute().data or []
    return {r['id']: r for r in rows}


def _hotels_by_id(ids):
    ids = list({i for i in ids if i is not None})
    if not ids:
        return {}
    rows = supabase.table('hotels').select('id,name,city,country,main_image').in_('id', ids).execute().data or []
    return {r['id']: r for r in rows}


def _unread(conv, user_id):
    last_read = conv.get('guest_last_read_at') if user_id == conv['guest_id'] else conv.get('owner_last_read_at')
    if conv.get('last_sender_id') == user_id:
        return False
    if not last_read:
        return bool(conv.get('last_message_at'))
    try:
        return _parse_dt(conv['last_message_at']) > _parse_dt(last_read)
    except Exception:
        return False


def list_conversations(user, limit=50):
    convs = (db().table('staya_conversations').select('*')
             .or_(f'owner_id.eq.{int(user.id)},guest_id.eq.{int(user.id)}')
             .order('last_message_at', desc=True).limit(limit).execute().data or [])
    people = _users_by_id([c['guest_id'] if user.id == c['owner_id'] else c['owner_id'] for c in convs])
    hotels = _hotels_by_id([c['property_id'] for c in convs])
    out = []
    for c in convs:
        other_id = c['guest_id'] if user.id == c['owner_id'] else c['owner_id']
        last = _first(db().table('staya_messages').select('body,kind,created_at,sender_id')
                      .eq('conversation_id', c['id']).order('id', desc=True).limit(1).execute())
        hotel = hotels.get(c['property_id'], {})
        out.append({
            'id': c['id'], 'property_id': c['property_id'], 'property_name': hotel.get('name', 'Property'),
            'property_city': hotel.get('city'), 'other_name': (people.get(other_id) or {}).get('username', 'User'),
            'last_message': (last or {}).get('body', ''), 'last_kind': (last or {}).get('kind'),
            'last_at': c.get('last_message_at'), 'unread': _unread(c, user.id),
        })
    return out


def get_thread(user, conv_id, after_id=None, mark_read=True, limit=200):
    conv = conversation_for_user(user, conv_id)
    q = db().table('staya_messages').select('*').eq('conversation_id', conv['id'])
    if after_id:
        q = q.gt('id', int(after_id))
    rows = q.order('id').limit(limit).execute().data or []
    if mark_read:
        col = 'guest_last_read_at' if user.id == conv['guest_id'] else 'owner_last_read_at'
        db().table('staya_conversations').update({col: _iso()}).eq('id', conv['id']).execute()
    people = _users_by_id([conv['guest_id'], conv['owner_id']])
    hotel = _hotels_by_id([conv['property_id']]).get(conv['property_id'], {})
    messages = [{
        'id': m['id'], 'sender_id': m.get('sender_id'), 'kind': m.get('kind', 'text'), 'body': m['body'],
        'offer_id': m.get('offer_id'), 'created_at': m.get('created_at'), 'mine': m.get('sender_id') == user.id,
        'sender_name': (people.get(m.get('sender_id')) or {}).get('username') if m.get('sender_id') else 'Staya',
    } for m in rows]
    return {
        'conversation': {
            'id': conv['id'], 'property_id': conv['property_id'], 'property_name': hotel.get('name', 'Property'),
            'guest': (people.get(conv['guest_id']) or {}).get('username', 'Guest'),
            'owner': (people.get(conv['owner_id']) or {}).get('username', 'Owner'),
            'i_am_owner': user.id == conv['owner_id'],
        },
        'messages': messages,
    }


def unread_count(user):
    convs = (db().table('staya_conversations').select('*')
             .or_(f'owner_id.eq.{int(user.id)},guest_id.eq.{int(user.id)}').execute().data or [])
    return sum(1 for c in convs if _unread(c, user.id))
