"""Saved ("liked") properties; lets Staya watch availability of what you like."""
from models import Hotel, supabase

from .db import db
from .errors import ActionError


def list_ids(user):
    rows = db().table('favorites').select('property_id,created_at').eq('user_id', user.id).execute().data or []
    return [r['property_id'] for r in rows]


def list_hotels(user):
    ids = list_ids(user)
    if not ids:
        return []
    rows = (supabase.table('hotels').select('*').in_('id', ids).eq('review_status', 'approved').execute().data or [])
    return [Hotel(r) for r in rows]


def is_saved(user, property_id):
    rows = (db().table('favorites').select('property_id').eq('user_id', user.id)
            .eq('property_id', property_id).execute().data or [])
    return bool(rows)


def toggle(user, property_id, saved=None):
    """Save/unsave. `saved=None` flips the current state. Returns the new state."""
    hotel = Hotel.get(property_id)
    if not hotel or getattr(hotel, 'review_status', None) != 'approved':
        raise ActionError('not_found', 'I could not find that property.')
    current = is_saved(user, property_id)
    want = (not current) if saved is None else bool(saved)
    if want and not current:
        try:
            db().table('favorites').insert({'user_id': user.id, 'property_id': property_id}).execute()
        except Exception:
            pass  # already saved by a concurrent request
    elif not want and current:
        db().table('favorites').delete().eq('user_id', user.id).eq('property_id', property_id).execute()
    return want
