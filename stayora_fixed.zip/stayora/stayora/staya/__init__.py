"""Staya: the multi-agent assistant of Stayora.

Staya is one assistant for the user, but internally it is an orchestrator that
routes each request to specialist agents:

    availability  - is a property free for these dates? what else is free?
    pricing       - quotes, price filters, comparison with the local market
    verification  - is this listing verified? is this price offer sane?
    reservation   - prepare / confirm / cancel bookings
    offer         - guest price offers to property owners (and owner replies)
    review        - guest reviews, only after a completed stay
    messaging     - guest <-> owner chat
    discovery     - search, trending, account helpers (legacy engine)

Agents never change data on their own: every write is a two-step action
(prepare -> user confirms with a signed, short-lived token).
"""
