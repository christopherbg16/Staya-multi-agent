"""Reservation agent logic: prepare -> confirm -> (cancel).

`prepare_booking` re-checks availability and price on the server and returns a
signed token.  Only `confirm_booking` (called from the Confirm button, never by
the language model) can create a reservation or hand over to card checkout.
"""
import os
import uuid
from datetime import date, datetime, time, timedelta

from flask import url_for

from models import (Hotel, PropertyReservation, Reservation, Room, log_activity, supabase, _parse_date)

from . import availability, messaging, offers, pricing, tokens
from .db import error_code
from .errors import ActionError

FREE_CANCELLATION_HOURS = int(os.environ.get('STAYA_FREE_CANCELLATION_HOURS', '48'))

REASON_MESSAGES = {
    'fully_booked': 'It is already booked for those dates.',
    'not_approved': 'This property is not currently listed.',
    'owner': 'This is your own property.',
    'no_price': 'This property has no bookable price yet.',
    'too_many_guests': 'It does not sleep that many guests.',
}


def stripe_enabled():
    try:
        from payments import _stripe_enabled
        return _stripe_enabled()
    except Exception:
        return False


def _checkout_url(mode, hotel_id, room_id, start, end, nights, offer_id=None):
    params = dict(check_in=start.isoformat(), check_out=end.isoformat(), nights=nights)
    if offer_id:
        params['offer_id'] = offer_id
    if mode == 'rooms':
        return url_for('payments.checkout_room', room_id=room_id, **params)
    return url_for('payments.checkout_property', property_id=hotel_id, **params)


def prepare_booking(user, property_id, check_in, check_out=None, nights=None, room_id=None, guests=None,
                    offer_id=None, today=None):
    """Validate everything and return a confirmation card + signed token."""
    report = availability.check_availability(property_id, check_in, check_out, nights, guests=guests,
                                             room_id=room_id, viewer_id=user.id, today=today)
    if not report['available']:
        raise ActionError('unavailable', REASON_MESSAGES.get(report['reason'], 'It is not available.'),
                          report=report)
    start = availability.to_date(report['check_in'])
    end = availability.to_date(report['check_out'])
    unit = report['units'][0]
    if room_id:
        unit = next((u for u in report['units'] if u['room_id'] == room_id), None)
        if not unit:
            raise ActionError('unavailable', 'That room is not free for those dates.', report=report)

    price_per_night = unit['price_per_night']
    if offer_id:
        offer = offers.validate_for_booking(user, offer_id, property_id, unit['room_id'], start, report['nights'])
        price_per_night = offers.agreed_price(offer)
    total, cents = pricing.price_total(price_per_night, report['nights'])
    if cents <= 0:
        raise ActionError('no_price', 'This property has no bookable price yet.')

    methods = ['cash'] + (['card'] if stripe_enabled() else [])
    payload = {'pid': property_id, 'rid': unit['room_id'], 'ci': start.isoformat(), 'co': end.isoformat(),
               'cents': cents, 'oid': offer_id, 'mode': report['mode']}
    token = tokens.issue('booking', user.id, payload)
    return {
        'ok': True, 'needs_confirmation': True, 'kind': 'booking', 'token': token, 'methods': methods,
        'summary': {
            'property': report['property'], 'room_number': unit.get('number'), 'room_id': unit['room_id'],
            'check_in': start.isoformat(), 'check_out': end.isoformat(), 'nights': report['nights'],
            'price_per_night': price_per_night, 'total': float(total), 'currency': pricing.CURRENCY,
            'offer_id': offer_id, 'guests': guests,
            'cancellation': f'Free cancellation until {FREE_CANCELLATION_HOURS} hours before check-in for paid '
                            f'bookings; unpaid cash bookings can be cancelled before check-in.',
        },
    }


def confirm_booking(user, token, method, today=None):
    p = tokens.read(token, 'booking', user.id, consume=False)
    if method not in ('cash', 'card'):
        raise ActionError('bad_method', 'Choose card or cash.')
    start, end = availability.to_date(p['ci']), availability.to_date(p['co'])
    nights = (end - start).days

    # re-check: someone may have booked it, or the price may have changed
    report = availability.check_availability(p['pid'], p['ci'], p['co'], room_id=p['rid'], viewer_id=user.id,
                                             alternatives=False, today=today)
    if not report['available']:
        raise ActionError('unavailable', 'Sorry, it was just booked by someone else.')
    unit = report['units'][0]
    price_per_night = unit['price_per_night']
    if p.get('oid'):
        offer = offers.validate_for_booking(user, p['oid'], p['pid'], unit['room_id'], start, nights)
        price_per_night = offers.agreed_price(offer)
    total, cents = pricing.price_total(price_per_night, nights)
    if cents != p['cents']:
        raise ActionError('price_changed', 'The price changed since you asked. Please request the booking again.')

    if method == 'card':
        if not stripe_enabled():
            raise ActionError('card_unavailable', 'Card payments are not enabled yet. Please choose cash.')
        return {'ok': True, 'action': 'checkout',
                'url': _checkout_url(report['mode'], p['pid'], unit['room_id'], start, end, nights, p.get('oid'))}

    tokens.use(token, 'booking', user.id)          # single use: a double click cannot book twice
    hotel = Hotel.get(p['pid'])
    row = dict(guest=user.username, user_id=user.id, start_date=start.isoformat(), nights=nights,
               total_price=float(total), payment_status='pending', payment_id=f'CASH-{uuid.uuid4()}')
    try:
        if report['mode'] == 'rooms':
            created = Reservation.create(room_id=unit['room_id'], **row)
            label = f"Room #{unit.get('number')} at {hotel.name}"
            kind = 'room'
        else:
            created = _create_property_reservation(property_id=p['pid'], **row)
            label = hotel.name
            kind = 'property'
    except Exception as exc:
        if error_code(exc) == '23P01':
            raise ActionError('unavailable', 'Sorry, it was just booked by someone else.') from exc
        raise
    if not created:
        raise ActionError('failed', 'The reservation could not be saved. Please try again.')
    log_activity(f"User '{user.username}' booked {label} (Cash payment, via Staya)")
    messaging.notify_owner(hotel, user, f"New booking from {user.username}: {start.isoformat()} to "
                                        f"{end.isoformat()} ({nights} night(s)), €{float(total):.2f}, pay in cash at the property.")
    if p.get('oid'):
        offers.mark_booked(p['oid'])
    return {'ok': True, 'action': 'booked', 'booking': {
        'type': kind, 'id': getattr(created, 'id', None), 'property': hotel.name, 'check_in': start.isoformat(),
        'check_out': end.isoformat(), 'nights': nights, 'total': float(total), 'payment': 'cash_on_arrival'}}


def _create_property_reservation(**row):
    last = None
    for _ in range(3):
        try:
            return PropertyReservation.create(**row)
        except Exception as exc:
            last = exc
            if error_code(exc) != '23505':       # only retry id collisions
                raise
    raise last


# ---------------------------------------------------------------- listing / cancel

def _owned(res, user):
    return getattr(res, 'user_id', None) == user.id or getattr(res, 'guest', None) == user.username


def list_bookings(user, today=None):
    today = today or date.today()
    rows = []
    for res in Reservation.find_by_guest(user.username):
        room = res.room
        hotel = room.hotel if room else None
        rows.append(('room', res, hotel, f"Room #{room.number}" if room else 'Room',
                     res.total_price or ((room.price or 0) * (res.nights or 0) if room else 0)))
    for res in PropertyReservation.find_by_guest(user.username):
        rows.append(('property', res, res.hotel, 'Entire property', res.total_price or 0))
    out = []
    for kind, res, hotel, unit, total in rows:
        start = _parse_date(res.start_date)
        end = start + timedelta(days=int(res.nights or 0))
        out.append({
            'type': kind, 'id': res.id, 'property_id': getattr(hotel, 'id', None),
            'property': getattr(hotel, 'name', 'Property'), 'city': getattr(hotel, 'city', ''), 'unit': unit,
            'check_in': start.isoformat(), 'check_out': end.isoformat(), 'nights': res.nights,
            'total': float(total or 0), 'payment_status': getattr(res, 'payment_status', None),
            'upcoming': start >= today, 'can_review': end <= today,
        })
    out.sort(key=lambda b: b['check_in'])
    return out


def _load(kind, reservation_id):
    if kind == 'room':
        return Reservation.get(reservation_id)
    if kind == 'property':
        return PropertyReservation.get(reservation_id)
    raise ActionError('bad_type', 'Unknown booking type.')


def cancellation_terms(res, now=None):
    """(allowed, refund, message) for a reservation, without changing anything."""
    now = now or datetime.now()
    start = _parse_date(res.start_date)
    pid = getattr(res, 'payment_id', '') or ''
    paid_by_card = pid.startswith('cs_') and getattr(res, 'payment_status', None) == 'paid'
    check_in_at = datetime.combine(start, time.min)   # start of check-in day
    if now >= check_in_at:
        return False, False, 'This stay has already started or is over, so it cannot be cancelled online.'
    if not paid_by_card:
        return True, False, 'Nothing was charged online, so you can cancel for free.'
    hours_left = (check_in_at - now).total_seconds() / 3600
    if hours_left >= FREE_CANCELLATION_HOURS:
        return True, True, 'You will get a full refund to your card.'
    return False, False, (f'Paid bookings can only be cancelled online until {FREE_CANCELLATION_HOURS} hours before '
                          f'check-in. Please message the owner to arrange a change.')


def prepare_cancellation(user, kind, reservation_id, now=None):
    res = _load(kind, reservation_id)
    if not res or not _owned(res, user):
        raise ActionError('not_found', 'I could not find that booking in your account.')
    allowed, refund, message = cancellation_terms(res, now)
    if not allowed:
        raise ActionError('not_cancellable', message)
    hotel = res.room.hotel if kind == 'room' else res.hotel
    start = _parse_date(res.start_date)
    token = tokens.issue('cancel', user.id, {'k': kind, 'id': int(reservation_id)})
    return {'ok': True, 'needs_confirmation': True, 'kind': 'cancel', 'token': token, 'summary': {
        'property': getattr(hotel, 'name', 'Property'), 'check_in': start.isoformat(),
        'check_out': (start + timedelta(days=int(res.nights or 0))).isoformat(), 'refund': refund, 'terms': message}}


def confirm_cancellation(user, token, now=None):
    p = tokens.use(token, 'cancel', user.id)
    return cancel_booking(user, p['k'], p['id'], now=now)


def cancel_booking(user, kind, reservation_id, now=None):
    res = _load(kind, reservation_id)
    if not res or not _owned(res, user):
        raise ActionError('not_found', 'I could not find that booking in your account.')
    allowed, refund, message = cancellation_terms(res, now)
    if not allowed:
        raise ActionError('not_cancellable', message)
    hotel = res.room.hotel if kind == 'room' else res.hotel
    if refund:
        try:
            from payments import refund_paid_booking
            refund_paid_booking(res.payment_id)
        except Exception as exc:
            raise ActionError('refund_failed', 'The refund could not be processed, so the booking was NOT cancelled. '
                                               'Please try again or message the owner.') from exc
    res.delete()
    start = _parse_date(res.start_date)
    name = getattr(hotel, 'name', 'Property')
    log_activity(f"User '{user.username}' cancelled reservation for '{name}'")
    if hotel is not None:
        messaging.notify_owner(hotel, user, f"{user.username} cancelled the booking for {start.isoformat()} "
                                            f"({res.nights} night(s)).")
    return {'ok': True, 'action': 'cancelled', 'property': name, 'refunded': refund, 'message': message}
