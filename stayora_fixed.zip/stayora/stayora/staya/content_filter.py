"""Small, dependency-free text screening for reviews, offers and chat messages.

It is a safety net, not a moderation system: it blocks payment-card and IBAN
numbers everywhere, and in *public* text (reviews) it also blocks contact
details, links and common abusive words so a review cannot be used to advertise
or to harass.
"""
import re

EMAIL_RE = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
URL_RE = re.compile(r'(?:https?://|www\.)\S+', re.I)
PHONE_RE = re.compile(r'(?<!\w)(?:\+|00)?\d[\d\s().-]{7,}\d(?!\w)')
IBAN_RE = re.compile(r'\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){3,7}(?:\s?[A-Z0-9]{1,4})?\b')
CARD_RE = re.compile(r'(?<!\d)(?:\d[ -]?){13,19}(?!\d)')

ABUSE_RE = re.compile(
    r'\b(?:fuck\w*|shit\w*|bitch\w*|cunt\w*|asshole\w*|nigg\w+|fagg?ot\w*|'
    r'путк\w*|курв\w*|мамка\s+ти|копеле\w*|педал\w*)\b',
    re.I,
)


def _luhn(number):
    digits = [int(c) for c in number if c.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def screen_text(text, *, public=False, min_len=1, max_len=2000):
    """Return {'ok': bool, 'text': cleaned text, 'issues': [codes]}."""
    cleaned = re.sub(r'[ \t]+', ' ', (text or '').replace('\r', '')).strip()
    cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)
    issues = []
    if len(cleaned) < min_len:
        issues.append('too_short')
    if len(cleaned) > max_len:
        issues.append('too_long')
    if IBAN_RE.search(cleaned):
        issues.append('iban')
    if any(_luhn(m.group(0)) for m in CARD_RE.finditer(cleaned)):
        issues.append('card_number')
    if public:
        if EMAIL_RE.search(cleaned):
            issues.append('email')
        if URL_RE.search(cleaned):
            issues.append('link')
        if PHONE_RE.search(cleaned):
            issues.append('phone')
        if ABUSE_RE.search(cleaned):
            issues.append('abusive')
    return {'ok': not issues, 'text': cleaned, 'issues': issues}


ISSUE_MESSAGES = {
    'too_short': 'The text is too short.',
    'too_long': 'The text is too long.',
    'iban': 'Please do not share bank account numbers in Stayora.',
    'card_number': 'Please do not share card numbers in Stayora. Pay through the secure checkout.',
    'email': 'Please remove e-mail addresses from public text.',
    'link': 'Please remove links from public text.',
    'phone': 'Please remove phone numbers from public text.',
    'abusive': 'Please keep the language respectful.',
}


def explain(issues):
    return ' '.join(ISSUE_MESSAGES.get(i, i) for i in issues)
