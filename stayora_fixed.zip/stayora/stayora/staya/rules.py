"""Deterministic intent router (en/bg/es/de).

It handles the unambiguous, high-value requests without a language model so
availability, price and booking questions work even when Gemini is down or over
quota. Returns one of:
    {'tool': name, 'args': {...}}          run a tool
    {'ask': 'need_price'|..., 'pending': {...}}   ask a follow-up, remember what we have
    None                                    let the language model handle it
"""
import re
from datetime import date

from . import dates as D
from .pricing import parse_price_constraints

W = lambda *words: re.compile(r'(?:' + '|'.join(words) + r')', re.I)

CANCEL = W(r'\bcancel', r'отказ\w* (?:на )?(?:моята )?(?:резерв|престо)', r'анулир', r'cancelar', r'stornier')
BOOK = W(r'\bbook\b', r'\breserve\b', r'\bbook it\b', r'резервир', r'запази\w* (?:го|я|ми|стая)', r'reservar', r'buchen')
MY_BOOKINGS = W(r'my (?:bookings?|reservations?|trips?|stays?)', r'моите (?:резервации|престои)', r'mis reservas',
                r'meine buchungen')
MY_OFFERS = W(r'my offers?', r'моите оферти', r'mis ofertas', r'meine angebote')
MY_MESSAGES = W(r'my (?:messages?|inbox|chats?|conversations?)', r'моите съобщения', r'inbox', r'mis mensajes',
                r'meine nachrichten')
SAVED = W(r'\b(?:saved|liked|favou?rites?|wishlist)\b', r'запазени', r'харесани', r'любими', r'favoritos', r'favoriten')
REVIEW_WRITE = W(r'(?:write|leave|add|post|submit|give)\w* (?:a |an |my )?review', r'review (?:this|the|my) (?:stay|place|property)',
                 r'оставя\w* (?:един )?отзив', r'напиша\w* отзив', r'dejar una reseña', r'bewertung schreiben')
REVIEWS = W(r'\breviews?\b', r'отзиви', r'ревюта', r'reseñas', r'bewertungen')
VERIFY = W(r'verif', r'\blegit', r'\bscam', r'\btrust', r'\bsafe\b', r'is (?:it|this) real', r'проверк', r'проверен', r'истинск',
           r'сигурен', r'измама', r'fiable', r'verificad', r'vertrauens')
OFFER = W(r'\boffer\b', r'\bnegotiat', r'\bbid\b', r'\bcounter', r'оферт', r'предлож', r'договар', r'oferta', r'angebot')
MESSAGE_OWNER = W(r'(?:message|write to|contact|ask|text|tell|chat with)\w* (?:the )?(?:owner|host|landlord)',
                  r'(?:пиш|свърж|питай|кажи)\w* (?:на |с )?(?:собственик|домакин)', r'escribir al (?:propietario|anfitri)',
                  r'(?:vermieter|gastgeber) (?:schreiben|kontakt)')
PRICE_COMPARE = W(r'\b(?:cheap|expensive|overpriced|fair price|good (?:price|deal)|worth)\b',
                  r'евтин', r'скъп', r'добра цена', r'струва ли', r'barato', r'caro', r'günstig', r'teuer')
PRICE = W(r'\bprice\b', r'\bcost\b', r'how much', r'\brate\b', r'цена', r'цени', r'колко (?:струва|е)', r'precio',
          r'cuánto', r'preis', r'wie viel')
AVAIL = W(r'availab', r'\bfree\b', r'\bvacan', r'is it (?:open|taken|booked)', r'свободн', r'наличн', r'заето',
          r'disponib', r'verfügbar', r'frei')
SEARCH = W(r'\b(?:find|search|show|look for|looking for|need|want|any)\b', r'търс', r'покаж', r'намери', r'искам',
           r'buscar', r'suche')

REVIEW_RATING = re.compile(r'(?<![\d.])([1-5])(?:\s*/\s*5|\s*(?:stars?|звезд\w*|estrellas?|sterne?))?(?![\d.])')
PRICE_NUMBER = re.compile(r'(?:€|eur(?:o|os)?|евро|лв\.?)?\s*(\d{1,5}(?:[.,]\d{1,2})?)\s*(?:€|eur(?:o|os)?|евро)?', re.I)
QUOTED = re.compile(r'["“„«](.+?)["”“»]', re.S)


def _stay(text, today=None):
    ci, co = D.extract_stay(text, today or date.today())
    nights = None if co else D.extract_nights(text)
    return ci, co, nights


def _dates_args(text, today=None):
    ci, co, nights = _stay(text, today)
    args = {}
    if ci:
        args['check_in'] = ci
    if co:
        args['check_out'] = co
    elif nights:
        args['nights'] = nights
    g = D.extract_guests(text)
    if g:
        args['guests'] = g
    return args


def _offered_price(text):
    """The euro amount the person offers. Ignores dates, nights and guest counts."""
    cleaned = re.sub(r'\d{4}-\d{2}-\d{2}', ' ', text)
    cleaned = re.sub(r'\d{1,2}[./]\d{1,2}[./]\d{2,4}', ' ', cleaned)
    cleaned = re.sub(r'\d+\s*(?:nights?|нощ\w*|noches?|nächte|guests?|people|гост\w*|души|човека|personas?|gäste)', ' ',
                     cleaned, flags=re.I)
    cleaned = re.sub(r'\b\d{1,2}(?:st|nd|rd|th)?\s*(?:-|to|до|–)\s*\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-zА-Яа-я]{3,}', ' ',
                     cleaned)
    cleaned = re.sub(r'\b\d{1,2}(?:st|nd|rd|th)?\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|яну|фев|мар|апр|май|юни|юли|авг|сеп|окт|ное|дек)\w*',
                     ' ', cleaned, flags=re.I)
    best = None
    for m in PRICE_NUMBER.finditer(cleaned):
        raw = m.group(0)
        value = float(m.group(1).replace(',', '.'))
        has_currency = bool(re.search(r'€|eur|евро|лв', raw, re.I))
        if has_currency and 5 <= value <= 100000:
            return value
        if best is None and 5 <= value <= 100000:
            best = value
    return best


def _text_for_owner(text):
    q = QUOTED.search(text)
    if q:
        return q.group(1).strip()
    if ':' in text:
        tail = text.split(':', 1)[1].strip()
        if len(tail) >= 2:
            return tail
    return None


def route(message, call, entities=None, pending=None, today=None):
    """`entities` comes from chatbot._extract_entities (cities, countries, property_types...)."""
    text = (message or '').strip()
    if not text:
        return None
    entities = entities or {}
    dates = _dates_args(text, today)
    on_property = bool(call.page.property_id or call.page.room_id or call.memory.get('property_id'))

    # ---- follow-up to a question we asked
    if pending:
        intent, have = pending.get('intent'), dict(pending.get('args') or {})
        if intent == 'offer' and 'price_per_night' not in have:
            price = _offered_price(text)
            if price:
                have['price_per_night'] = price
                have.update({k: v for k, v in dates.items() if k not in have})
                return {'tool': 'prepare_offer', 'args': have}
        elif intent in ('offer', 'availability', 'booking', 'price') and not (have.get('check_in')) and dates:
            have.update(dates)
            tool = {'offer': 'prepare_offer', 'availability': 'check_availability', 'booking': 'prepare_booking',
                    'price': 'get_price_quote'}[intent]
            if tool == 'prepare_offer' and 'price_per_night' not in have:
                return {'ask': 'need_price', 'pending': {'intent': 'offer', 'args': have}}
            return {'tool': tool, 'args': have}
        elif intent == 'message' and not have.get('text'):
            return {'tool': 'prepare_message_to_owner', 'args': {**have, 'text': text}}
        elif intent == 'review':
            m = REVIEW_RATING.search(text)
            if m:
                body = text.replace(m.group(0), '', 1).strip(' .,:-')
                have['rating'] = int(m.group(1))
                if len(body) >= 10:
                    have['text'] = body
                return {'tool': 'prepare_review', 'args': have} if have.get('text') else \
                    {'ask': 'need_review', 'pending': {'intent': 'review', 'args': have}}
            if have.get('rating') and len(text) >= 10:
                return {'tool': 'prepare_review', 'args': {**have, 'text': text}}

    # ---- account lookups (no property needed)
    if CANCEL.search(text):
        m = re.search(r'\b(room|property)\s*#?\s*(\d+)', text, re.I)
        if m:
            return {'tool': 'prepare_cancellation', 'args': {'booking_type': m.group(1).lower(), 'booking_id': int(m.group(2))}}
        return {'tool': 'prepare_cancellation', 'args': {}}
    if MY_BOOKINGS.search(text):
        return {'tool': 'list_my_bookings', 'args': {}}
    if MY_OFFERS.search(text):
        return {'tool': 'list_my_offers', 'args': {}}
    if MY_MESSAGES.search(text):
        return {'tool': 'get_my_messages', 'args': {}}
    if SAVED.search(text) and not REVIEWS.search(text):
        return {'tool': 'check_saved_properties', 'args': dates}

    # ---- property-bound intents: need a property from the page / memory / name
    if REVIEW_WRITE.search(text):
        args = {}
        m = REVIEW_RATING.search(text)
        if m:
            args['rating'] = int(m.group(1))
        body = _text_for_owner(text)
        if body:
            args['text'] = body
        if args.get('rating') and args.get('text'):
            return {'tool': 'prepare_review', 'args': args}
        return {'ask': 'need_review', 'pending': {'intent': 'review', 'args': args}}
    if MESSAGE_OWNER.search(text):
        body = _text_for_owner(text)
        if body:
            return {'tool': 'prepare_message_to_owner', 'args': {'text': body}}
        return {'ask': 'need_text', 'pending': {'intent': 'message', 'args': {}}}
    if OFFER.search(text) and (on_property or entities.get('cities') is not None):
        args = dict(dates)
        price = _offered_price(text)
        if price:
            args['price_per_night'] = price
            if not (args.get('check_in') or call.page.check_in or call.memory.get('check_in')):
                return {'ask': 'need_dates', 'pending': {'intent': 'offer', 'args': args}}
            return {'tool': 'prepare_offer', 'args': args}
        return {'ask': 'need_price', 'pending': {'intent': 'offer', 'args': args}}
    if VERIFY.search(text) and on_property:
        return {'tool': 'verify_property', 'args': {}}
    if REVIEWS.search(text) and on_property:
        return {'tool': 'get_reviews', 'args': {}}
    if BOOK.search(text) and on_property:
        args = dict(dates)
        if not (args.get('check_in') or call.page.check_in or call.memory.get('check_in')):
            return {'ask': 'need_dates', 'pending': {'intent': 'booking', 'args': args}}
        return {'tool': 'prepare_booking', 'args': args}
    if on_property and PRICE_COMPARE.search(text):
        return {'tool': 'compare_price', 'args': {}}
    if on_property and AVAIL.search(text):
        args = dict(dates)
        if not (args.get('check_in') or call.page.check_in or call.memory.get('check_in')):
            return {'ask': 'need_dates', 'pending': {'intent': 'availability', 'args': args}}
        return {'tool': 'check_availability', 'args': args}
    if on_property and PRICE.search(text):
        return {'tool': 'get_price_quote', 'args': dict(dates)}

    # ---- discovery: where + when and/or price
    where = (entities.get('cities') or entities.get('countries') or [None])[0]
    ptypes = entities.get('property_types') or set()
    ptype = sorted(ptypes)[0] if len(ptypes) == 1 else None
    limits = parse_price_constraints(text)
    has_price = limits.get('min') is not None or limits.get('max') is not None
    discovery = SEARCH.search(text) or where or has_price
    if dates.get('check_in') and discovery and (where or ptype or SEARCH.search(text)):
        args = {k: v for k, v in dates.items() if k != 'guests'} | ({'guests': dates['guests']} if dates.get('guests') else {})
        if where:
            args['destination'] = where
        if ptype:
            args['property_type'] = ptype
        if limits.get('min') is not None:
            args['min_price'] = limits['min']
        if limits.get('max') is not None:
            args['max_price'] = limits['max']
        return {'tool': 'search_available', 'args': args}
    if has_price and (where or ptype or SEARCH.search(text)):
        args = {}
        if where:
            args['destination'] = where
        if ptype:
            args['property_type'] = ptype
        if limits.get('min') is not None:
            args['min_price'] = limits['min']
        if limits.get('max') is not None:
            args['max_price'] = limits['max']
        return {'tool': 'search_by_price', 'args': args}
    return None
