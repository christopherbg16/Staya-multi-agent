from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, Room, Reservation, Activity, Hotel, HotelImage, log_activity
from forms import RoomForm, ReservationForm, HotelForm
from datetime import datetime, timedelta
from supabase_client import supabase
from property_moderation import (
    prepare_property_images,
    prepare_stored_property_images,
    review_property_submission,
)
from functools import wraps
from storage import upload_image

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('Access denied. Admin only area.', 'danger')
            return redirect(url_for('user.dashboard'))
        return f(*args, **kwargs)
    return decorated_function


class _OwnerBooking:
    """One row for the owner's booking views: room reservations and whole-property reservations alike."""

    def __init__(self, res, label, revenue, nights):
        self.guest = res.guest
        self.user = None
        self.start_date = _to_date(res.start_date)
        self.nights = int(nights or 0)
        self.end_date = self.start_date + timedelta(days=self.nights) if self.start_date else None
        self.label = label
        self.revenue = float(revenue or 0)


def _to_date(value):
    from datetime import date as _date
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, _date):
        return value
    try:
        return datetime.strptime(str(value)[:10], '%Y-%m-%d').date()
    except ValueError:
        return None


def _owner_bookings(hotels):
    """Room reservations plus whole-property reservations for the owner's hotels (newest first)."""
    from models import PropertyReservation
    ids = [h.id for h in hotels]
    if not ids:
        return []
    by_id = {h.id: h for h in hotels}
    rows = []
    rooms = Room.find_by_hotel_ids(ids)
    room_by_id = {r.id: r for r in rooms}
    if room_by_id:
        data = supabase.table('reservations').select('*').in_('room_id', list(room_by_id)).execute().data or []
        for r in data:
            res = Reservation(r)
            room = room_by_id.get(r['room_id'])
            total = r.get('total_price') or ((room.price or 0) * (r.get('nights') or 0))
            rows.append(_OwnerBooking(res, f"{by_id[room.hotel_id].name} \u2014 Room #{room.number}", total, r.get('nights')))
    data = supabase.table('property_reservations').select('*').in_('property_id', ids).execute().data or []
    for r in data:
        res = PropertyReservation(r)
        rows.append(_OwnerBooking(res, f"{by_id[r['property_id']].name} \u2014 Entire property", r.get('total_price') or 0,
                                  r.get('nights')))
    rows = [r for r in rows if r.start_date]
    rows.sort(key=lambda r: r.start_date, reverse=True)
    return rows


@admin_bp.route('/')
@admin_bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    my_hotels = Hotel.find_by_owner(current_user.id)
    my_hotel_ids = [h.id for h in my_hotels]

    total_my_hotels = len(my_hotels)
    total_my_rooms = Room.count_by_hotel_ids(my_hotel_ids)

    rows = _owner_bookings(my_hotels)
    total_my_reservations = len(rows)
    revenue = sum(r.revenue for r in rows)

    return render_template('admin/dashboard.html',
                           my_hotels=my_hotels,
                           total_my_hotels=total_my_hotels,
                           total_my_rooms=total_my_rooms,
                           total_my_reservations=total_my_reservations,
                           revenue=revenue,
                           now=datetime.now())


@admin_bp.route('/my-properties')
@login_required
@admin_required
def my_properties():
    hotels = Hotel.find_by_owner(current_user.id)
    return render_template('admin/my_properties.html', hotels=hotels, now=datetime.now())


@admin_bp.route('/my-properties/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_property():
    if request.method == 'GET':
        return render_template('admin/add_property.html', now=datetime.now())

    name = request.form.get('name')
    property_type = request.form.get('property_type')
    description = request.form.get('description')
    address = request.form.get('address')
    city = request.form.get('city')
    country = request.form.get('country')
    stars = request.form.get('stars', 3)
    total_rooms = request.form.get('total_rooms', 1)
    max_guests = request.form.get('max_guests', 2)
    price_per_night = request.form.get('price_per_night')

    if not name:
        flash('Property name is required!', 'danger')
        return redirect(url_for('admin.add_property'))

    image_uploads = []
    main_upload = request.files.get('main_image')
    if main_upload and main_upload.filename:
        image_uploads.append(main_upload)
    image_uploads.extend(request.files.getlist('gallery_images'))
    try:
        images = prepare_property_images(image_uploads)
    except ValueError as exc:
        flash(str(exc), 'danger')
        return redirect(url_for('admin.add_property'))
    if not images:
        flash('Upload at least one property photo for review.', 'danger')
        return redirect(url_for('admin.add_property'))

    if request.form.get('ai_moderation_consent') == 'yes':
        moderation = review_property_submission(
            name, description or '', property_type or '', address or '', city or '', country or '', images
        )
    else:
        moderation = {
            'review_status': 'action_required',
            'moderation_status': 'not_requested',
            'summary': 'Allow Staya to check this listing before it can be published.',
        }

    hotel_data = {
        'name': name,
        'property_type': property_type,
        'description': description,
        'address': address,
        'city': city,
        'country': country,
        'stars': int(stars),
        'owner_id': current_user.id,
        'total_rooms': int(total_rooms) if total_rooms else 1,
        'max_guests': int(max_guests) if max_guests else 2,
        'price_per_night': float(price_per_night) if price_per_night and property_type == 'apartment' else None,
        'review_status': moderation['review_status'],
        'moderation_status': moderation['moderation_status'],
        'moderation_notes': moderation['summary'],
        'submitted_at': datetime.utcnow().isoformat()
    }

    amenities_list = request.form.getlist('amenities')
    custom_amenities = request.form.get('custom_amenities', '').strip()
    if custom_amenities:
        for a in [a.strip() for a in custom_amenities.split(',') if a.strip()]:
            if a not in amenities_list:
                amenities_list.append(a)
    hotel_data['amenities'] = ','.join(amenities_list) if amenities_list else None

    try:
        stored_images = [
            upload_image(image['bytes'], image['mime_type'], 'properties')
            for image in images
        ]
        hotel_data['main_image'] = stored_images[0]
        hotel = Hotel.create(**hotel_data)

        for image_url in stored_images[1:]:
            HotelImage.create(hotel_id=hotel.id, image_data=image_url)

        log_activity(f"Property owner '{current_user.username}' submitted property '{name}' for automated review")
        if moderation['review_status'] == 'approved':
            flash('Staya verified the listing checks and published the property.', 'success')
        elif moderation['review_status'] == 'rejected':
            flash(f"Staya rejected this submission: {moderation['summary']}", 'danger')
        else:
            flash(f"Staya needs changes before publishing: {moderation['summary']}", 'warning')
        return redirect(url_for('admin.my_properties'))

    except Exception as e:
        flash(f'Error adding property: {str(e)}', 'danger')
        return redirect(url_for('admin.add_property'))


@admin_bp.route('/my-properties/edit/<int:property_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_property(property_id):
    hotel = Hotel.find_by_id_and_owner(property_id, current_user.id)
    if not hotel:
        flash('Property not found or access denied', 'danger')
        return redirect(url_for('admin.my_properties'))

    if request.method == 'GET':
        return render_template('admin/edit_property.html', hotel=hotel, now=datetime.now())

    update_data = {}
    for field in ['name', 'property_type', 'description', 'address', 'city', 'country']:
        val = request.form.get(field)
        if val is not None:
            update_data[field] = val
    update_data['stars'] = int(request.form.get('stars', hotel.stars))
    new_type = update_data.get('property_type', hotel.property_type)
    if new_type not in ('hotel', 'villa', 'resort'):
        try:
            if request.form.get('price_per_night'):
                price = round(float(request.form['price_per_night']), 2)
                if not 1 <= price <= 100000:
                    raise ValueError
                update_data['price_per_night'] = price
            for field, hi in (('max_guests', 50), ('total_rooms', 50)):
                if request.form.get(field):
                    value = int(request.form[field])
                    if not 1 <= value <= hi:
                        raise ValueError
                    update_data[field] = value
        except ValueError:
            flash('Price, guests and bedrooms must be valid positive numbers.', 'danger')
            return redirect(url_for('admin.edit_property', property_id=property_id))

    amenities_list = request.form.getlist('amenities')
    custom_amenities = request.form.get('custom_amenities', '').strip()
    if custom_amenities:
        for a in [a.strip() for a in custom_amenities.split(',') if a.strip()]:
            if a not in amenities_list:
                amenities_list.append(a)
    update_data['amenities'] = ','.join(amenities_list) if amenities_list else None
    update_data['accept_online_payments'] = 1 if request.form.get('accept_online_payments') else 0
    changed_images = []
    if 'main_image' in request.files:
        image = request.files['main_image']
        if image and image.filename:
            try:
                changed_images = prepare_property_images([image])
            except ValueError as exc:
                flash(str(exc), 'danger')
                return redirect(url_for('admin.edit_property', property_id=property_id))
            update_data['main_image'] = changed_images[0]['base64']

    if request.form.get('ai_moderation_consent') == 'yes':
        image_data = [hotel.main_image]
        if changed_images:
            image_data[0] = changed_images[0]['base64']
        image_data.extend(
            getattr(image, 'image_data', None) for image in hotel.images
        )
        try:
            images_for_review = prepare_stored_property_images(image_data)
        except ValueError as exc:
            flash(str(exc), 'danger')
            return redirect(url_for('admin.edit_property', property_id=property_id))
        moderation = review_property_submission(
            update_data.get('name', hotel.name),
            update_data.get('description', getattr(hotel, 'description', '') or ''),
            update_data.get('property_type', hotel.property_type),
            update_data.get('address', getattr(hotel, 'address', '') or ''),
            update_data.get('city', hotel.city),
            update_data.get('country', hotel.country),
            images_for_review,
        )
    else:
        moderation = {
            'review_status': 'action_required',
            'moderation_status': 'not_requested',
            'summary': 'Allow Staya to check this listing before it can be published.',
        }
    update_data['review_status'] = moderation['review_status']
    update_data['moderation_status'] = moderation['moderation_status']
    update_data['moderation_notes'] = moderation['summary']
    update_data['submitted_at'] = datetime.utcnow().isoformat()

    try:
        if changed_images:
            update_data['main_image'] = upload_image(
                changed_images[0]['bytes'], changed_images[0]['mime_type'], 'properties'
            )
        hotel.update(**update_data)
        log_activity(f"Admin '{current_user.username}' edited property '{hotel.name}'")
        if moderation['review_status'] == 'approved':
            flash(f'Property "{hotel.name}" updated and approved by Staya.', 'success')
        elif moderation['review_status'] == 'rejected':
            flash(f"Staya rejected this update: {moderation['summary']}", 'danger')
        else:
            flash(f"Staya needs changes before publishing: {moderation['summary']}", 'warning')
    except Exception as e:
        flash(f'Error updating property: {str(e)}', 'danger')

    return redirect(url_for('admin.my_properties'))


@admin_bp.route('/my-properties/delete/<int:property_id>', methods=['POST'])
@login_required
@admin_required
def delete_property(property_id):
    hotel = Hotel.find_by_id_and_owner(property_id, current_user.id)
    if not hotel:
        flash('Property not found or access denied', 'danger')
        return redirect(url_for('admin.my_properties'))

    hotel_rooms = Room.find_by_hotel(property_id)
    if hotel_rooms:
        flash(f'Cannot delete "{hotel.name}" because it has rooms!', 'danger')
        return redirect(url_for('admin.my_properties'))

    try:
        hotel_name = hotel.name
        hotel.delete()
        log_activity(f"Admin '{current_user.username}' deleted property '{hotel_name}'")
        flash(f'Property "{hotel_name}" deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting property: {str(e)}', 'danger')

    return redirect(url_for('admin.my_properties'))


@admin_bp.route('/my-rooms')
@login_required
@admin_required
def my_rooms():
    my_hotels = Hotel.find_by_owner(current_user.id)
    my_hotel_ids = [h.id for h in my_hotels]
    rooms = Room.find_by_hotel_ids(my_hotel_ids)
    room_hotels = [h for h in my_hotels if h.property_type in ('hotel', 'villa', 'resort')]
    return render_template('admin/my_rooms.html', rooms=rooms, hotels=room_hotels, now=datetime.now())


@admin_bp.route('/my-rooms/add', methods=['POST'])
@login_required
@admin_required
def add_room():
    hotel_id = request.form.get('hotel_id')
    number = request.form.get('number')
    price = request.form.get('price')
    beds = request.form.get('beds')

    hotel = Hotel.find_by_id_and_owner(hotel_id, current_user.id)
    if not hotel:
        flash('Hotel not found or you do not have permission!', 'danger')
        return redirect(url_for('admin.my_rooms'))

    try:
        room_data = {
            'hotel_id': int(hotel_id),
            'number': int(number),
            'price': float(price),
            'type': 'Standard',
            'beds': int(beds) if beds else 1
        }
        if 'room_image' in request.files:
            img = request.files['room_image']
            if img and img.filename:
                image = prepare_property_images([img])[0]
                room_data['image_data'] = upload_image(image['bytes'], image['mime_type'], 'rooms')
        Room.create(**room_data)
        log_activity(f"Admin '{current_user.username}' added Room #{number} to {hotel.name}")
        flash(f'Room #{number} added successfully!', 'success')
    except Exception as e:
        flash(f'Error adding room: {str(e)}', 'danger')

    return redirect(url_for('admin.my_rooms'))


@admin_bp.route('/my-rooms/delete/<int:room_id>', methods=['POST'])
@login_required
@admin_required
def delete_room(room_id):
    room = Room.get(room_id)
    if not room:
        flash('Room not found', 'danger')
        return redirect(url_for('admin.my_rooms'))

    room_hotel = room.hotel
    if not room_hotel or room_hotel.owner_id != current_user.id:
        flash('You do not have permission to delete this room!', 'danger')
        return redirect(url_for('admin.my_rooms'))

    if room.has_active_reservations:
        flash(f'Cannot delete Room #{room.number} because it has active reservations!', 'danger')
        return redirect(url_for('admin.my_rooms'))

    try:
        room_number = room.number
        hotel_name = room_hotel.name
        room.delete()
        log_activity(f"Admin '{current_user.username}' deleted Room #{room_number} from {hotel_name}")
        flash(f'Room #{room_number} deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting room: {str(e)}', 'danger')

    return redirect(url_for('admin.my_rooms'))


@admin_bp.route('/property/<int:property_id>/rooms')
@login_required
@admin_required
def property_rooms(property_id):
    hotel = Hotel.find_by_id_and_owner(property_id, current_user.id)
    if not hotel:
        flash('Property not found!', 'danger')
        return redirect(url_for('admin.my_properties'))
    rooms = Room.find_by_hotel(property_id)
    return render_template('admin/property_rooms.html', hotel=hotel, rooms=rooms)


@admin_bp.route('/property/<int:property_id>/rooms/add', methods=['POST'])
@login_required
@admin_required
def add_property_room(property_id):
    hotel = Hotel.find_by_id_and_owner(property_id, current_user.id)
    if not hotel:
        flash('Property not found!', 'danger')
        return redirect(url_for('admin.my_properties'))

    number = request.form.get('number')
    price = request.form.get('price')
    beds = request.form.get('beds')

    try:
        room_data = {
            'hotel_id': property_id,
            'number': int(number),
            'price': float(price),
            'type': 'Standard',
            'beds': int(beds) if beds else 1
        }
        if 'room_image' in request.files:
            img = request.files['room_image']
            if img and img.filename:
                image = prepare_property_images([img])[0]
                room_data['image_data'] = upload_image(image['bytes'], image['mime_type'], 'rooms')
        Room.create(**room_data)
        log_activity(f"Admin '{current_user.username}' added Room #{number} to {hotel.name}")
        flash(f'Room #{number} added successfully!', 'success')
    except Exception as e:
        flash(f'Error adding room: {str(e)}', 'danger')

    return redirect(url_for('admin.property_rooms', property_id=property_id))


@admin_bp.route('/property/<int:property_id>/rooms/<int:room_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_property_room(property_id, room_id):
    hotel = Hotel.find_by_id_and_owner(property_id, current_user.id)
    if not hotel:
        flash('Property not found!', 'danger')
        return redirect(url_for('admin.my_properties'))

    room = Room.get(room_id)
    if not room or room.hotel_id != property_id:
        flash('Room not found!', 'danger')
        return redirect(url_for('admin.property_rooms', property_id=property_id))

    if room.has_active_reservations:
        flash(f'Cannot delete Room #{room.number} — it has active reservations!', 'danger')
        return redirect(url_for('admin.property_rooms', property_id=property_id))

    try:
        room_number = room.number
        room.delete()
        log_activity(f"Admin '{current_user.username}' deleted Room #{room_number} from {hotel.name}")
        flash(f'Room #{room_number} deleted!', 'success')
    except Exception as e:
        flash(f'Error deleting room: {str(e)}', 'danger')

    return redirect(url_for('admin.property_rooms', property_id=property_id))


@admin_bp.route('/profile', methods=['GET', 'POST'])
@login_required
@admin_required
def profile():
    from forms import ProfileForm
    form = ProfileForm()

    if request.method == 'GET':
        form.email.data = current_user.email
        form.phone.data = current_user.phone
        form.address.data = current_user.address

    if form.validate_on_submit():
        changes_made = False
        update_data = {}

        if form.current_password.data:
            if not check_password_hash(current_user.password_hash, form.current_password.data):
                flash('Current password is incorrect', 'danger')
                return render_template('admin/profile.html', form=form)

            if form.new_password.data:
                update_data['password_hash'] = generate_password_hash(form.new_password.data)
                changes_made = True

        if form.email.data != current_user.email:
            update_data['email'] = form.email.data or None
            changes_made = True
        if form.phone.data != current_user.phone:
            update_data['phone'] = form.phone.data or None
            changes_made = True
        if form.address.data != current_user.address:
            update_data['address'] = form.address.data or None
            changes_made = True
        if form.profile_image.data:
            image = prepare_property_images([form.profile_image.data])[0]
            update_data['profile_image'] = upload_image(image['bytes'], image['mime_type'], 'profiles')
            changes_made = True

        payment_fields = ['stripe_account_id', 'bank_name', 'bank_iban', 'bank_holder']
        for field in payment_fields:
            val = request.form.get(field, '').strip()
            if val != getattr(current_user, field, ''):
                update_data[field] = val or None
                changes_made = True

        if changes_made:
            try:
                current_user.update(**update_data)
                log_activity(f"Admin '{current_user.username}' updated their profile")
                flash('Profile updated successfully!', 'success')
            except Exception as e:
                flash(f'Error updating profile: {str(e)}', 'danger')
        else:
            flash('No changes were made', 'info')

        return redirect(url_for('admin.profile'))

    return render_template('admin/profile.html', form=form)


@admin_bp.route('/profile/remove-image', methods=['POST'])
@login_required
@admin_required
def remove_profile_image():
    try:
        current_user.update(profile_image=None)
        log_activity(f"Admin '{current_user.username}' removed their profile image")
        flash('Profile photo removed!', 'success')
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
    return redirect(url_for('admin.profile'))


@admin_bp.route('/my-reservations')
@login_required
@admin_required
def my_reservations():
    rows = _owner_bookings(Hotel.find_by_owner(current_user.id))
    return render_template('admin/my_reservations.html', reservations=rows, now=datetime.now())
