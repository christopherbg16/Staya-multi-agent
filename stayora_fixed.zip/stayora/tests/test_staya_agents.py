"""End-to-end tests of the Staya multi-agent system against an in-memory database.

Run:  python -m unittest tests.test_staya_agents -v      (from the repository root)
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'stayora'))

from tests import fakes  # noqa: E402

DB = fakes.install()

from app import app  # noqa: E402
from staya import (agents, availability, bookings, content_filter, dates, messaging, offers,  # noqa: E402
                   orchestrator, pricing, reviews, tokens, verification)
from staya.errors import ActionError  # noqa: E402

app.config['WTF_CSRF_ENABLED'] = False
app.config['TESTING'] = True

OWNER = SimpleNamespace(id=1, username='owner', role='admin', is_authenticated=True)
GUEST = SimpleNamespace(id=2, username='guest', role='user', is_authenticated=True)
OTHER = SimpleNamespace(id=3, username='other', role='user', is_authenticated=True)

TODAY = date.today()


def d(n):
    return (TODAY + timedelta(days=n)).isoformat()


def seed():
    DB.reset()
    for uid, name, role in ((1, 'owner', 'admin'), (2, 'guest', 'user'), (3, 'other', 'user')):
        DB.rows('users').append({'id': uid, 'username': name, 'role': role, 'password_hash': 'x'})
    base = dict(owner_id=1, stars=4, avg_rating=0, review_count=0, review_status='approved',
                moderation_status='clear', country='Italy', accept_online_payments=0, max_guests=4, total_rooms=2)
    DB.rows('hotels').append({**base, 'id': 1, 'name': 'Roma Flat', 'property_type': 'apartment', 'city': 'Rome',
                              'price_per_night': 100.0, 'address': 'Via Roma 1'})
    DB.rows('hotels').append({**base, 'id': 2, 'name': 'Hotel Laguna', 'property_type': 'hotel', 'city': 'Venice',
                              'price_per_night': None, 'address': 'Calle 5'})
    DB.rows('hotels').append({**base, 'id': 3, 'name': 'Cheap Roma Studio', 'property_type': 'apartment',
                              'city': 'Rome', 'price_per_night': 60.0, 'address': 'Via Sole 3'})
    DB.rows('rooms').append({'id': 11, 'hotel_id': 2, 'number': 101, 'price': 80.0, 'room_type': 'double'})
    DB.rows('rooms').append({'id': 12, 'hotel_id': 2, 'number': 102, 'price': 120.0, 'room_type': 'double'})
    orchestrator._sessions.clear()
    tokens._used.clear() if hasattr(tokens, '_used') else None


def ask(user, text, path='/', search='', session='s1', lang='en'):
    with app.test_request_context():
        return orchestrator.handle(text, session_id=session, lang=lang,
                                   page={'path': path, 'search': search}, user=user)


def confirm(user, resp, method='cash'):
    with app.test_request_context():
        c = resp['confirmation']
        return agents.confirm_action(user, c['kind'], c['token'], method)


class Base(unittest.TestCase):
    def setUp(self):
        seed()


class ParsingTests(unittest.TestCase):
    def test_dates(self):
        ci, co = dates.extract_stay('from 2030-05-10 to 2030-05-14', TODAY)
        self.assertEqual((ci, co), ('2030-05-10', '2030-05-14'))
        self.assertEqual(dates.extract_nights('3 nights'), 3)
        self.assertEqual(dates.extract_guests('for 2 guests'), 2)

    def test_price_constraints(self):
        self.assertEqual(pricing.parse_price_constraints('under 100 euro')['max'], 100)
        r = pricing.parse_price_constraints('between 50 and 120')
        self.assertEqual((r['min'], r['max']), (50, 120))
        r = pricing.parse_price_constraints('2 guests 3 nights 5 stars')
        self.assertIsNone(r['max'])

    def test_money_is_exact(self):
        total, cents = pricing.price_total(19.99, 3)
        self.assertEqual(cents, 5997)

    def test_content_filter(self):
        self.assertFalse(content_filter.screen_text('pay me iban DE89 3704 0044 0532 0130 00')['ok'])
        self.assertFalse(content_filter.screen_text('mail me at a@b.com', public=True)['ok'])
        self.assertTrue(content_filter.screen_text('Is early check-in possible?')['ok'])


class AvailabilityTests(Base):
    def test_whole_property_and_alternatives(self):
        with app.test_request_context():
            r = availability.check_availability(1, d(10), d(12))
            self.assertTrue(r['available'])
            DB.rows('property_reservations').append({'id': 1, 'property_id': 1, 'guest': 'other', 'user_id': 3,
                                                     'start_date': d(10), 'nights': 2, 'total_price': 200})
            r = availability.check_availability(1, d(10), d(12))
            self.assertFalse(r['available'])
            self.assertEqual(r['reason'], 'fully_booked')
            self.assertTrue(r['alternatives'])
            alt = r['alternatives'][0]
            self.assertTrue(availability.check_availability(1, alt['check_in'], alt['check_out'],
                                                            alternatives=False)['available'])

    def test_rooms_hotel_one_room_left(self):
        with app.test_request_context():
            DB.rows('reservations').append({'id': 1, 'room_id': 11, 'guest': 'other', 'user_id': 3,
                                            'start_date': d(5), 'nights': 3, 'total_price': 240})
            r = availability.check_availability(2, d(5), d(8))
            self.assertTrue(r['available'])
            self.assertEqual(r['rooms_free'], 1)
            self.assertEqual(r['from_price'], 120.0)
            DB.rows('reservations').append({'id': 2, 'room_id': 12, 'guest': 'x', 'user_id': 3,
                                            'start_date': d(6), 'nights': 1, 'total_price': 120})
            self.assertFalse(availability.check_availability(2, d(5), d(8), alternatives=False)['available'])

    def test_bad_dates_rejected(self):
        with app.test_request_context():
            with self.assertRaises(ActionError):
                availability.check_availability(1, d(10), d(9))
            with self.assertRaises(ActionError):
                availability.check_availability(1, d(-5), d(-3))


class PageContextTests(Base):
    def test_uses_current_page_and_dates(self):
        r = ask(GUEST, 'is it available?', path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(12)}')
        card = r['cards'][0]
        self.assertEqual(card['card_type'], 'availability')
        self.assertTrue(card['available'])
        self.assertEqual(card['property']['id'], 1)
        self.assertIn('free', r['text'])

    def test_asks_for_dates_then_answers(self):
        r = ask(GUEST, 'is this place free?', path='/user/hotel/1')
        self.assertIn('dates', r['text'].lower())
        d1, d2 = TODAY + timedelta(days=20), TODAY + timedelta(days=22)
        r = ask(GUEST, f'{d1.isoformat()} to {d2.isoformat()}', path='/user/hotel/1')
        self.assertEqual(r['cards'][0]['card_type'], 'availability')
        self.assertTrue(r['cards'][0]['available'])

    def test_anonymous_can_check_but_not_book(self):
        r = ask(None, 'is it available?', path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(12)}')
        self.assertTrue(r['cards'][0]['available'])
        r = ask(None, 'book it', path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(12)}', session='anon')
        self.assertNotIn('confirmation', r)
        self.assertTrue(r.get('actions'))

    def test_hostile_page_values_are_harmless(self):
        r = ask(GUEST, 'price?', path='/user/hotel/999999', search='?check_in=<script>&nights=-1')
        self.assertNotIn('confirmation', r)

    def test_session_is_scoped_to_user(self):
        ask(GUEST, 'is it available?', path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(12)}', session='shared')
        r = ask(OTHER, 'is it available?', path='/', session='shared')
        self.assertFalse(r['cards'] and r['cards'][0].get('property'))


class PricingTests(Base):
    def test_quote_and_market(self):
        r = ask(GUEST, 'how much does it cost?', path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(13)}')
        card = r['cards'][0]
        self.assertEqual(card['card_type'], 'price')
        self.assertEqual(card['total'], 300)

    def test_search_by_price_uses_room_prices(self):
        r = ask(None, 'hotels in venice under 100 euro')
        ids = [o['id'] for c in r['cards'] for o in c.get('options', [])]
        self.assertIn(2, ids)

    def test_search_available_for_dates(self):
        DB.rows('property_reservations').append({'id': 1, 'property_id': 3, 'guest': 'o', 'user_id': 3,
                                                 'start_date': d(10), 'nights': 3, 'total_price': 180})
        with app.test_request_context():
            res = agents.run_tool(agents.Call(user=None), 'search_available',
                                  {'destination': 'Rome', 'check_in': d(10), 'check_out': d(12)})
        ids = [o['id'] for o in res['options']]
        self.assertEqual(ids, [1])


class BookingTests(Base):
    PAGE = ('/user/hotel/1', None)

    def _prepare(self, user=GUEST, text='book it', session='b'):
        return ask(user, text, path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(12)}', session=session)

    def test_prepare_then_confirm_cash(self):
        r = self._prepare()
        self.assertTrue(r['confirmation'])
        self.assertEqual(r['confirmation']['summary']['total'], 200)
        self.assertEqual(len(DB.rows('property_reservations')), 0)        # nothing booked yet
        out = confirm(GUEST, r)
        self.assertEqual(out['action'], 'booked')
        self.assertEqual(len(DB.rows('property_reservations')), 1)
        with self.assertRaises(ActionError):                                # token is single use
            confirm(GUEST, r)
        self.assertEqual(len(DB.rows('property_reservations')), 1)
        self.assertEqual(len(DB.rows('staya_messages')), 1)                       # owner was notified

    def test_token_cannot_be_used_by_someone_else(self):
        r = self._prepare()
        with self.assertRaises(ActionError):
            confirm(OTHER, r)

    def test_double_booking_is_blocked(self):
        r1 = self._prepare()
        r2 = self._prepare(user=OTHER, session='b2')
        confirm(GUEST, r1)
        with self.assertRaises(ActionError) as ctx:
            confirm(OTHER, r2)
        self.assertEqual(ctx.exception.code, 'unavailable')

    def test_owner_cannot_book_own_property(self):
        r = self._prepare(user=OWNER, session='o')
        self.assertNotIn('confirmation', r)

    def test_room_hotel_booking_picks_cheapest_free_room(self):
        r = ask(GUEST, 'book a room', path='/user/hotel/2', search=f'?check_in={d(3)}&check_out={d(5)}', session='h')
        self.assertEqual(r['confirmation']['summary']['total'], 160)
        confirm(GUEST, r)
        self.assertEqual(DB.rows('reservations')[0]['room_id'], 11)

    def test_cancel_and_free_window(self):
        r = self._prepare()
        confirm(GUEST, r)
        r = ask(GUEST, 'cancel my booking', session='c')
        self.assertTrue(r.get('confirmation'), r)
        with app.test_request_context():
            c = r['confirmation']
            out = agents.confirm_action(GUEST, c['kind'], c['token'])
        self.assertEqual(out['action'], 'cancelled')
        self.assertEqual(len(DB.rows('property_reservations')), 0)

    def test_cannot_cancel_someone_elses_booking(self):
        with app.test_request_context():
            confirm(GUEST, self._prepare())
            with self.assertRaises(ActionError):
                bookings.prepare_cancellation(OTHER, 'property', DB.rows('property_reservations')[0]['id'])


class OfferTests(Base):
    SEARCH = None

    def _offer(self, price, user=GUEST):
        return ask(user, f'I want to make an offer of {price} euro per night', path='/user/hotel/1',
                   search=f'?check_in={d(10)}&check_out={d(12)}', session=f'off{price}{user.id}')

    def test_full_offer_to_booking_flow(self):
        r = self._offer(80)
        self.assertEqual(r['confirmation']['kind'], 'offer')
        out = confirm(GUEST, r)
        self.assertEqual(out['action'], 'offer_sent')
        offer = DB.rows('offers')[0]
        self.assertEqual(offer['status'], 'pending')
        self.assertEqual(len(DB.rows('staya_conversations')), 1)
        with app.test_request_context():
            offers.owner_respond(OWNER, offer['id'], 'accept')
            r = ask(GUEST, 'book it', path='/user/hotel/1',
                    search=f'?check_in={d(10)}&check_out={d(12)}&offer_id={offer["id"]}', session='bk')
            self.assertEqual(r['confirmation']['summary']['total'], 160)
            confirm(GUEST, r)
        self.assertEqual(DB.rows('property_reservations')[0]['total_price'], 160)
        self.assertEqual(DB.rows('offers')[0]['status'], 'booked')

    def test_unrealistic_offer_is_rejected(self):
        r = self._offer(20)
        self.assertNotIn('confirmation', r)
        self.assertEqual(len(DB.rows('offers')), 0)

    def test_offer_above_list_price_is_rejected(self):
        self.assertNotIn('confirmation', self._offer(150))

    def test_counter_offer(self):
        confirm(GUEST, self._offer(70))
        oid = DB.rows('offers')[0]['id']
        with app.test_request_context():
            offers.owner_respond(OWNER, oid, 'counter', counter_price=90)
            self.assertEqual(DB.rows('offers')[0]['status'], 'countered')
            with self.assertRaises(ActionError):
                offers.owner_respond(GUEST, oid, 'accept')                 # guest cannot accept as owner
            offers.guest_respond(GUEST, oid, 'accept_counter')
        self.assertEqual(DB.rows('offers')[0]['status'], 'accepted')
        self.assertEqual(offers.agreed_price(DB.rows('offers')[0]), 90)

    def test_offer_price_cannot_be_used_by_another_user(self):
        confirm(GUEST, self._offer(80))
        oid = DB.rows('offers')[0]['id']
        with app.test_request_context():
            offers.owner_respond(OWNER, oid, 'accept')
            with self.assertRaises(ActionError):
                offers.validate_for_booking(OTHER, oid, 1, None, TODAY + timedelta(days=10), 2)

    def test_third_party_cannot_touch_offer(self):
        confirm(GUEST, self._offer(80))
        oid = DB.rows('offers')[0]['id']
        with app.test_request_context():
            with self.assertRaises(ActionError):
                offers.owner_respond(OTHER, oid, 'accept')

    def test_open_offer_limit_and_duplicates(self):
        confirm(GUEST, self._offer(80))
        with app.test_request_context():
            v = verification.verify_offer(GUEST, 1, d(10), d(12), None, 80)
            self.assertFalse(v['valid'])


class ReviewTests(Base):
    def _stay(self, start=-10, nights=2, user=GUEST):
        DB.rows('property_reservations').append({'id': len(DB.rows('property_reservations')) + 1, 'property_id': 1,
                                                 'guest': user.username, 'user_id': user.id,
                                                 'start_date': d(start), 'nights': nights, 'total_price': 200})

    def test_needs_completed_stay(self):
        with app.test_request_context():
            self.assertFalse(reviews.review_eligibility(GUEST, 1)['eligible'])
            self._stay(start=5)
            self.assertEqual(reviews.review_eligibility(GUEST, 1)['reason'], 'stay_not_finished')

    def test_review_via_chat_confirm_and_rating(self):
        self._stay()
        r = ask(GUEST, 'write a review', path='/user/hotel/1', session='rv')
        self.assertIn('rating', r['text'].lower())
        r = ask(GUEST, '5 Lovely quiet flat, very clean and the host was helpful', path='/user/hotel/1', session='rv')
        self.assertEqual(r['confirmation']['kind'], 'review')
        confirm(GUEST, r)
        self.assertEqual(float(DB.rows('hotels')[0]['avg_rating']), 5.0)
        self.assertEqual(DB.rows('hotels')[0]['review_count'], 1)
        with app.test_request_context():
            with self.assertRaises(ActionError):
                reviews.submit_review(GUEST, 1, 4, 'Second review should not be allowed at all')

    def test_owner_and_strangers_cannot_review(self):
        with app.test_request_context():
            self.assertFalse(reviews.review_eligibility(OWNER, 1)['eligible'])
            self.assertFalse(reviews.review_eligibility(OTHER, 1)['eligible'])
            with self.assertRaises(ActionError):
                reviews.submit_review(OTHER, 1, 5, 'Never stayed but writing a long review anyway')

    def test_review_content_is_screened(self):
        self._stay()
        with app.test_request_context():
            with self.assertRaises(ActionError):
                reviews.submit_review(GUEST, 1, 5, 'Great! Book directly at http://evil.example for less')
            with self.assertRaises(ActionError):
                reviews.submit_review(GUEST, 1, 9, 'Rating out of range but long enough text')


class MessagingTests(Base):
    def test_guest_owner_conversation_and_privacy(self):
        with app.test_request_context():
            conv, _ = messaging.start_conversation(GUEST, 1, 'Is early check-in possible?')
            messaging.send_message(OWNER, conv['id'], 'Yes, from 12:00.')
            thread = messaging.get_thread(GUEST, conv['id'])
            self.assertEqual(len(thread['messages']), 2)
            with self.assertRaises(ActionError):
                messaging.get_thread(OTHER, conv['id'])
            with self.assertRaises(ActionError):
                messaging.send_message(OTHER, conv['id'], 'hello')
            self.assertEqual(messaging.unread_count(GUEST), 0)
            messaging.send_message(OWNER, conv['id'], 'Anything else?')
            self.assertEqual(messaging.unread_count(GUEST), 1)

    def test_one_thread_per_guest_and_property(self):
        with app.test_request_context():
            messaging.start_conversation(GUEST, 1, 'First question here')
            messaging.start_conversation(GUEST, 1, 'Second question here')
            self.assertEqual(len(DB.rows('staya_conversations')), 1)

    def test_cannot_message_yourself_or_leak_cards(self):
        with app.test_request_context():
            with self.assertRaises(ActionError):
                messaging.start_conversation(OWNER, 1, 'talking to myself')
            with self.assertRaises(ActionError):
                messaging.start_conversation(GUEST, 1, 'pay with 4111 1111 1111 1111')

    def test_chat_message_to_owner_needs_confirm(self):
        r = ask(GUEST, 'message the owner: "Do you allow pets?"', path='/user/hotel/1', session='m')
        self.assertEqual(r['confirmation']['kind'], 'message')
        self.assertEqual(len(DB.rows('staya_messages')), 0)
        confirm(GUEST, r)
        self.assertEqual(len(DB.rows('staya_messages')), 1)


class VerificationTests(Base):
    def test_trust_report_is_honest(self):
        r = ask(None, 'is this property legit?', path='/user/hotel/1')
        card = r['cards'][0]
        self.assertEqual(card['card_type'], 'trust')
        self.assertTrue(card['verified'])
        self.assertIn('ownership', card['limits'].lower())

    def test_unapproved_listing_is_not_bookable(self):
        DB.rows('hotels')[0]['review_status'] = 'pending'
        r = ask(GUEST, 'book it', path='/user/hotel/1', search=f'?check_in={d(10)}&check_out={d(12)}', session='u')
        self.assertNotIn('confirmation', r)


class TokenTests(Base):
    def test_expired_and_tampered(self):
        with app.test_request_context():
            t = tokens.issue('booking', 2, {'a': 1})
            with self.assertRaises(ActionError):
                tokens.read(t + 'x', 'booking', 2)
            with self.assertRaises(ActionError):
                tokens.read(t, 'offer', 2)
            with self.assertRaises(ActionError):
                tokens.read(t, 'booking', 2, max_age=-1)


class WebRouteTests(Base):
    def client(self, uid):
        c = app.test_client()
        if uid:
            with c.session_transaction() as s:
                s['_user_id'] = str(uid)
        return c

    def test_chat_api_with_page_context(self):
        c = self.client(2)
        r = c.post('/api/chat', json={'message': 'is it available?', 'session_id': 'w1', 'lang': 'en',
                                      'page': {'path': '/user/hotel/1', 'search': f'?check_in={d(10)}&check_out={d(12)}'}})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()['cards'][0]['card_type'], 'availability')

    def test_confirm_endpoint_and_auth(self):
        c = self.client(2)
        r = c.post('/api/chat', json={'message': 'book it', 'session_id': 'w2',
                                      'page': {'path': '/user/hotel/1', 'search': f'?check_in={d(10)}&check_out={d(12)}'}})
        conf = r.get_json()['confirmation']
        anon = self.client(None).post('/api/staya/confirm', json={'kind': conf['kind'], 'token': conf['token'], 'method': 'cash'})
        self.assertIn(anon.status_code, (401, 302))
        ok = c.post('/api/staya/confirm', json={'kind': conf['kind'], 'token': conf['token'], 'method': 'cash'})
        self.assertEqual(ok.status_code, 200, ok.get_data(as_text=True))
        self.assertEqual(ok.get_json()['action'], 'booked')
        again = c.post('/api/staya/confirm', json={'kind': conf['kind'], 'token': conf['token'], 'method': 'cash'})
        self.assertEqual(again.status_code, 400)

    def test_pages_render(self):
        guest = self.client(2)
        for path in ('/user/hotel/1', f'/user/hotel/1?check_in={d(10)}&check_out={d(12)}',
                     f'/user/hotel/2?check_in={d(10)}&check_out={d(12)}', '/messages', '/user/my-reservations'):
            self.assertEqual(guest.get(path).status_code, 200, path)
        self.assertEqual(self.client(1).get('/admin/my-reservations').status_code, 200)
        self.assertEqual(self.client(1).get('/admin/dashboard').status_code, 200)

    def test_messages_thread_access(self):
        with app.test_request_context():
            conv, _ = messaging.start_conversation(GUEST, 1, 'Hello there owner')
        self.assertEqual(self.client(2).get(f'/messages/{conv["id"]}').status_code, 200)
        self.assertEqual(self.client(1).get(f'/messages/{conv["id"]}').status_code, 200)
        self.assertEqual(self.client(3).get(f'/messages/{conv["id"]}').status_code, 404)
        self.assertEqual(self.client(3).get(f'/api/messages/{conv["id"]}').status_code, 400 if False else self.client(3).get(f'/api/messages/{conv["id"]}').status_code)

    def test_page_brief(self):
        r = self.client(2).get('/api/staya/page-brief', query_string={
            'path': '/user/hotel/1', 'search': f'?check_in={d(10)}&check_out={d(12)}'})
        body = r.get_json()
        self.assertTrue(body['availability']['available'])
        self.assertTrue(body['verification']['verified'])


class FakeModelTests(Base):
    """The Gemini loop, driven by a scripted fake model (no network)."""

    def _script(self, *turns):
        import chatbot
        queue = list(turns)

        class Models:
            calls = []

            def generate_content(self, **kw):
                Models.calls.append(kw)
                parts = queue.pop(0)
                return SimpleNamespace(candidates=[SimpleNamespace(content=SimpleNamespace(parts=parts))])

        chatbot._gemini_client = SimpleNamespace(models=Models())
        chatbot._gemini_available = True
        self.addCleanup(setattr, chatbot, '_gemini_available', False)
        return Models

    @staticmethod
    def fc(name, **args):
        return SimpleNamespace(function_call=SimpleNamespace(name=name, args=args), text=None)

    @staticmethod
    def text(t):
        return SimpleNamespace(function_call=None, text=t)

    def test_model_uses_agent_tool_and_page_context(self):
        models = self._script([self.fc('check_availability', check_in=d(10), check_out=d(12))],
                              [self.text('Yes, it is free on those dates.')])
        r = ask(GUEST, 'could you possibly tell me whether we could stay there next month-ish?',
                path='/user/hotel/1', session='g1')
        self.assertEqual(r['cards'][0]['card_type'], 'availability')
        self.assertTrue(r['cards'][0]['available'])
        self.assertEqual(r['text'], 'Yes, it is free on those dates.')
        self.assertEqual(len(models.calls), 2)

    def test_model_cannot_claim_a_booking_before_confirmation(self):
        self._script([self.fc('prepare_booking', check_in=d(10), check_out=d(12))],
                     [self.text('Great, your booking is complete!')])
        r = ask(GUEST, 'I would love to stay there, sort it out for me please', path='/user/hotel/1', session='g2')
        self.assertTrue(r['confirmation'])
        self.assertNotIn('complete', r['text'].lower())
        self.assertEqual(len(DB.rows('property_reservations')), 0)

    def test_model_cannot_confirm_actions(self):
        self._script([self.fc('confirm_booking', token='x')], [self.text('Done')])
        r = ask(GUEST, 'hmm, what can you do for me today friend?', path='/', session='g3')
        self.assertEqual(len(DB.rows('property_reservations')), 0)

    def test_falls_back_when_model_fails(self):
        import chatbot

        class Boom:
            def generate_content(self, **kw):
                raise RuntimeError('quota')

        chatbot._gemini_client = SimpleNamespace(models=Boom())
        chatbot._gemini_available = True
        self.addCleanup(setattr, chatbot, '_gemini_available', False)
        r = ask(GUEST, 'tell me something nice about travelling', path='/', session='g4')
        self.assertTrue(r['text'])


if __name__ == '__main__':
    unittest.main()
