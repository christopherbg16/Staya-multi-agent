"""In-memory stand-in for supabase-py so the Staya tests run without a database.
Call `install()` BEFORE importing the app. Emulates the exclusion constraints on reservations
(error 23P01) and the unique indexes the migrations add (error 23505)."""
import os, sys, types
import copy, re, itertools

class APIError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message); self.code = code; self.message = message

class Resp:
    def __init__(self, data, count=None):
        self.data = data; self.count = count

_IDENTITY = {'reservations', 'offers', 'staya_conversations', 'staya_messages', 'favorites', 'review_helpful'}

class FakeDB:
    def __init__(self):
        self.tables = {}
        self.seq = {}
    def reset(self):
        self.tables.clear(); self.seq.clear()
    def rows(self, name):
        return self.tables.setdefault(name, [])
    def next_id(self, name):
        rows = self.rows(name)
        cur = max([r.get('id', 0) or 0 for r in rows] + [self.seq.get(name, 0)])
        self.seq[name] = cur + 1
        return cur + 1

DB = FakeDB()

def _cmp_key(v):
    return (v is None, v)

class Query:
    def __init__(self, name):
        self.name = name; self.filters = []; self.mode = 'select'; self.payload = None
        self._order = []; self._limit = None; self._count = None; self._or = []
    # ---- builders
    def select(self, cols='*', count=None):
        self.mode = 'select'; self._count = count; return self
    def insert(self, payload):
        self.mode = 'insert'; self.payload = payload; return self
    def update(self, payload):
        self.mode = 'update'; self.payload = payload; return self
    def delete(self):
        self.mode = 'delete'; return self
    def upsert(self, payload, **kw):
        self.mode = 'upsert'; self.payload = payload; return self
    def eq(self, c, v): self.filters.append(lambda r, c=c, v=v: r.get(c) == v); return self
    def neq(self, c, v): self.filters.append(lambda r, c=c, v=v: r.get(c) != v); return self
    def gt(self, c, v): self.filters.append(lambda r, c=c, v=v: r.get(c) is not None and r.get(c) > v); return self
    def gte(self, c, v): self.filters.append(lambda r, c=c, v=v: r.get(c) is not None and r.get(c) >= v); return self
    def lt(self, c, v): self.filters.append(lambda r, c=c, v=v: r.get(c) is not None and r.get(c) < v); return self
    def lte(self, c, v): self.filters.append(lambda r, c=c, v=v: r.get(c) is not None and r.get(c) <= v); return self
    def in_(self, c, vs): vs = list(vs); self.filters.append(lambda r, c=c, vs=vs: r.get(c) in vs); return self
    def is_(self, c, v):
        v = None if v in ('null', None) else v
        self.filters.append(lambda r, c=c, v=v: r.get(c) is v); return self
    def ilike(self, c, pat):
        rx = re.compile('^' + re.escape(pat).replace('%', '.*').replace(r'\%', '.*') + '$', re.I)
        self.filters.append(lambda r, c=c, rx=rx: bool(rx.match(str(r.get(c) or '')))); return self
    def or_(self, expr):
        conds = []
        for part in expr.split(','):
            col, op, val = part.split('.', 2)
            if op == 'ilike':
                rx = re.compile('^' + re.escape(val).replace('%', '.*').replace(r'\%', '.*') + '$', re.I)
                conds.append(lambda r, col=col, rx=rx: bool(rx.match(str(r.get(col) or ''))))
            elif op == 'eq':
                conds.append(lambda r, col=col, val=val: str(r.get(col)) == val)
            else:
                raise NotImplementedError(op)
        self.filters.append(lambda r, conds=conds: any(c(r) for c in conds)); return self
    def order(self, c, desc=False): self._order.append((c, desc)); return self
    def limit(self, n): self._limit = n; return self
    def range(self, a, b): self._limit = b - a + 1; return self
    # ---- exec
    def _match(self):
        return [r for r in DB.rows(self.name) if all(f(r) for f in self.filters)]
    def execute(self):
        rows = DB.rows(self.name)
        if self.mode == 'select':
            out = [copy.deepcopy(r) for r in self._match()]
            for c, desc in reversed(self._order):
                out.sort(key=lambda r, c=c: _cmp_key(r.get(c)), reverse=desc)
            total = len(out)
            if self._limit is not None: out = out[: self._limit]
            return Resp(out, total if self._count else None)
        if self.mode in ('insert', 'upsert'):
            items = self.payload if isinstance(self.payload, list) else [self.payload]
            created = []
            for it in items:
                it = copy.deepcopy(it)
                if 'id' not in it or it['id'] is None:
                    it['id'] = DB.next_id(self.name)
                self._constraints(it)
                rows.append(it); created.append(copy.deepcopy(it))
            return Resp(created)
        if self.mode == 'update':
            hit = self._match()
            for r in hit: r.update(copy.deepcopy(self.payload))
            return Resp([copy.deepcopy(r) for r in hit])
        if self.mode == 'delete':
            hit = self._match()
            DB.tables[self.name] = [r for r in rows if r not in hit]
            return Resp(hit)
    def _constraints(self, new):
        from datetime import date, timedelta
        def rng(r):
            s = date.fromisoformat(str(r['start_date'])[:10]); return s, s + timedelta(days=int(r['nights']))
        key = {'reservations': 'room_id', 'property_reservations': 'property_id'}.get(self.name)
        if key:
            ns, ne = rng(new)
            for r in DB.rows(self.name):
                if r.get(key) == new.get(key):
                    s, e = rng(r)
                    if s < ne and e > ns:
                        raise APIError('conflicting key value violates exclusion constraint', code='23P01')
            pid = new.get('payment_id')
            if pid and str(pid).startswith('cs_') and any(r.get('payment_id') == pid for r in DB.rows(self.name)):
                raise APIError('duplicate key', code='23505')
        if self.name == 'favorites':
            if any(r['user_id'] == new['user_id'] and r['property_id'] == new['property_id'] for r in DB.rows('favorites')):
                raise APIError('duplicate key', code='23505')
        if self.name == 'staya_conversations':
            if any(r['property_id'] == new['property_id'] and r['guest_id'] == new['guest_id'] for r in DB.rows('staya_conversations')):
                raise APIError('duplicate key', code='23505')

class Client:
    def table(self, name): return Query(name)
    def rpc(self, *a, **k): raise NotImplementedError
    storage = None

def create_client(url, key, *a, **k): return Client()


def install():
    """Register the fake as the `supabase` package and set the env the app expects."""
    os.environ.update(SUPABASE_URL='https://fake.supabase.co', SUPABASE_KEY='fake-key',
                      SECRET_KEY='unit-test-only-secret-value-at-least-32-chars')
    sys.modules['supabase'] = sys.modules[__name__]
    try:
        import dotenv
        dotenv.load_dotenv = lambda *a, **k: None
    except ImportError:
        pass
    DB.reset()
    return DB
